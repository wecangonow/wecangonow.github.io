<?php
namespace app\plb;

use Yii;

class CommonLib
{
    public static function signVerify($arr)
    {
        foreach ($arr as $k => $v) {
            if ($k != "sign")
                $signdata .= $v;
        }
        $newSign = $signdata . Yii::$app->params["upcleanerKey"];

        if (md5($newSign) == $arr["sign"])
            return true;
        else
            return false;
    }

    public static function uuid()
    {
        return md5(uniqid());
    }

    public static function createFolder($path)
    {
        if (file_exists($path))
            return true;
        elseif (!file_exists($path)) {
            mkdir($path, 0777,recursive);
            return true;
        } else
            return false;
    }

    public static function versionInt($version)
    {
        $versionArr = explode(".", $version);
        foreach ($versionArr as $k => $v) {
            $versionArr[$k] = intval($versionArr[$k]);
            $final .= $versionArr[$k] . ".";
        }

        return substr($final, 0, -1);
    }

    public static function formatVersion($version)
    {
        $versionArr = explode(".", $version);
        foreach ($versionArr as $k => $v) {
            if ($k != 0) {
                $versionArr[$k] = str_pad($v, 4, "0", STR_PAD_LEFT);
            }
            $final .= $versionArr[$k];
        }
        return $final;
    }

    public function compareVersion($v1, $v2)
    {
        if (empty ($v1)) {
            return false;
        }

        if (empty ($v2)) {
            return false;
        }

        $l1 = explode('.', $v1);
        $l2 = explode('.', $v2);
        $len = count($l1) > count($l2) ? count($l1) : count($l2);
        for ($i = 0; $i < $len; $i++) {
            $n1 = $l1 [$i];
            $n2 = $l2 [$i];
            if ($n1 > $n2) {
                return true;
            } else if ($n1 < $n2) {
                return false;
            }
        }

        return false;
    }
}