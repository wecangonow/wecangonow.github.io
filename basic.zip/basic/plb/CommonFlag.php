<?php

namespace app\plb;

/**
 * Class CommonFlag
 * @package app\plb
 */
class CommonFlag
{
    /**
     * SAMPLES
     */
    const SAMPLES = 0x1000;
    /**
     * UPLOAD
     */
    const UPLOAD = 0x0100;

    /**
     * UPLOAD_SUCCESS
     */
    const UPLOAD_SUCCESS = 0x0000;

    /**
     * ERROR_EXTENSION
     */
    const ERROR_EXTENSION = 0x0001;

    /**
     * ERROR_CONTENT_TYPE
     */
    const ERROR_CONTENT_TYPE = 0x0002;

    /**
     * CREATE_DIR_FAIL
     */
    const CREATE_DIR_FAIL = 0x0003;

    /**
     * UPLOAD_SUCCESS
     */
    const SAVE_DB_ERROR = 0x0004;

    /**
     * FILE_GET_CONTENTS_FAIL
     */
    const FILE_GET_CONTENTS_FAIL = 0x0005;

    /**
     * SIGN_FAIL
     */
    const SIGN_FAIL = 0x0006;

    /**
     * SIGN_FAIL
     */
    const UPLOAD_TOO_BIG = 0x0007;

    /**
     * API
     */
    const API = 0x2000;

    /**
     * CHECK_UPDATE
     */
    const CHECK_UPDATE = 0x0100;

    /**
     * UPDATE_SUCCESS
     */
    const UPDATE_SUCCESS = 0x0000;

    /**
     * NO_NEED_UPDATE
     */
    const NO_NEED_UPDATE = 0x0001;

    /**
     * FORCE_TOP_VERSION
     */

    const FORCE_TOP_VERSION = 0x0002;

    /**
     * WRONG_DATA_FORMAT
     */

    const WRONG_DATA_FORMAT = 0x0003;

    /**
     * API_SIGN_FAIL
     */

    const API_SIGN_FAIL = 0x0004;
}