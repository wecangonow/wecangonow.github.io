<?php

namespace app\models\ARext;

use app\models\ARbase\UpUser;

class LUpUser extends UpUser
{
    public static function findByUsername($username)
    {
        $result = UpUser::find()->select(["id", "password"])->where(["username" => $username])->one();
        return $result;
    }

    public static function getUserInfo($id)
    {
        $result = UpUser::find()->select(["id","username"])->where(["id" => $id])->one();
        return $result;
    }
    public static function getall(){

        $result = UpUser::find()->select(["id","username"])->asArray()->all();
        foreach($result as  $val){
            $data[$val['id']]=$val['username'];
        }
        return $data;
    }
}