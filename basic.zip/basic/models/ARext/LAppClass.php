<?php

namespace app\models\ARext;

use app\models\ARbase\AppClass;
use app\models\SCform\AppClassSearch;

class LAppClass extends AppClass
{
    /**
     * 处理分类属性
     * @return array
     */
    public static function deployTopClass(){
        $classSearchModel = new AppClassSearch();
        $topClassData = $classSearchModel->getTopClass();
        $topClassList = ['0'=>'顶级分类'];
        foreach($topClassData as $key=>$value){
            $topClassList[$value['id']] = $value['name'];

        }
        return $topClassList;
    }
    public static function deployDbData($model,$config){
        if($model->sort=='') $model->sort = 100;
        if($model->pt_name=='') $model->pt_name = $model->name;
        if($model->en_name=='') $model->en_name = $model->name;
        $lang = $model->attributes['lang'];
        if($lang[0]==1){
            unset($lang[0]);
        }
        $langStr = implode(',',$lang);
        $model->lang = $langStr;
        $model->update_time = time();
        return $model;
    }
    public static function getTopClass(){
        $classSearchModel = new AppClassSearch();
        $otherClassData = $classSearchModel->getTopClass();

        foreach($otherClassData as $key=>$value){
            $otherClassList[$value['id']] = $value['name'];

        }
        return $otherClassList;
    }

    public static function getOtherClass(){
        $classSearchModel = new AppClassSearch();
        $topClassData = $classSearchModel->getOtherClass();

        foreach($topClassData as $key=>$value){
            $topClassList[$value['id']] = $value['name'];

        }
        return $topClassList;
    }
    public static function getClassByPClass($p_class){
        $classSearchModel = new AppClassSearch();
        $class = $classSearchModel->getClassByPClass($p_class);
        return $class;
    }
    public static function returnSelHtml($class){
        $html = '<option value="">请选择子级分类</option>';
        foreach($class as $key=>$value){
            $html .='<option value="'.$value['id'].'">'.$value['name'].'</option>';
        }
        return $html;
    }

}