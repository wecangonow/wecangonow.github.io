<?php

namespace app\models\ARext;

use app\models\ARbase\App;
use app\models\SCform\AppSearch;

class LApp extends App
{
    /**
     * 处理分类属性
     * @return array
     */
    public static function deployDbData($model,$config){
        if($model->pt_name=='') $model->pt_name = $model->name;
        if($model->en_name=='') $model->en_name = $model->name;
        $lang = $model->attributes['lang'];
        if($lang[0]==="1"){
            unset($lang[0]);
        }
        $langStr = implode(',',$lang);
        $model->lang = $langStr;
        if($model->recommend_sort=='') $model->recommend_sort = 100;
        if($model->hot_sort=='') $model->hot_sort = 100;
        return $model;
    }

}