<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "auth_user".
 *
 * @property integer $id
 * @property integer $uid
 * @property string $value
 * @property integer $create_time
 * @property integer $update_time
 */
class AuthUser extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'auth_user';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['uid', 'value'], 'required'],
            [['uid', 'create_time', 'update_time'], 'integer'],
            [['value'], 'string', 'max' => 30]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'uid' => 'Uid',
            'value' => 'Value',
            'create_time' => 'Create Time',
            'update_time' => 'Update Time',
        ];
    }

    //获取权限列表
    public static function getall($id){
        $rows= AuthUser::find()->where(['uid'=>$id])->asArray()->all();
        $arr=[];
        foreach($rows as $val){
            $arr[]=$val['value'];
        }
        return $arr;
    }


}
