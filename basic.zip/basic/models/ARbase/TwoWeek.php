<?php

namespace app\models\ARbase;

use Yii;

/**
 * This is the model class for table "app".
 *
 * @property integer $id
 * @property string  $name
 * @property string  $pt_name
 * @property string  $en_name
 * @property integer $class
 * @property string  $size
 * @property integer $is_recommend
 * @property integer $is_hot
 * @property string  $lang
 * @property integer $tag
 * @property integer $level
 * @property integer $sort
 * @property integer $recommend_sort
 * @property integer $hot_sort
 * @property string  $img
 * @property string  $link
 */
class TwoWeek extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName() {

        //return 'app';
    }

    /**
     * @inheritdoc
     */
    public function rules() {

        return [
        ];
    }





    /**
     * @inheritdoc
     */
    public function attributeLabels() {

        return [
            'datetime'   => '日期',
            'dau'        => '日活跃(DAU)',
            'dru'        => '日存量(DRU)',
            'dnu'        => '日新增(DNU)',
            'd2a/dnu'    => '次日活跃率(D2A/DNU)',
            'd2r/dnu'    => '次日留存率(D2R/DNU)',
            'nuu/dnu'    => '当日新用户卸载(NUU/DNU)',
        ];
    }
}
