<?php

namespace app\models\ARbase;

use Yii;

/**
 * This is the model class for table "app_foreg".
 *
 * @property integer $id
 * @property string $package
 * @property string $os
 * @property string $adid
 * @property string $time
 * @property string $locale
 * @property string $imei
 * @property string $appid
 * @property string $mac
 * @property string $uuid
 * @property string $aid
 * @property string $vm_version
 * @property string $channel
 * @property string $os_version
 * @property string $create_time
 */
class AppForeg extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'app_foreg';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['create_time'], 'safe'],
            [['package', 'os', 'adid', 'time', 'locale', 'imei', 'appid', 'mac', 'uuid', 'aid', 'vm_version', 'channel', 'os_version'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'package' => 'Package',
            'os' => 'Os',
            'adid' => 'Adid',
            'time' => 'Time',
            'locale' => 'Locale',
            'imei' => 'Imei',
            'appid' => 'Appid',
            'mac' => 'Mac',
            'uuid' => 'Uuid',
            'aid' => 'Aid',
            'vm_version' => 'Vm Version',
            'channel' => 'Channel',
            'os_version' => 'Os Version',
            'create_time' => 'Create Time',
        ];
    }
}
