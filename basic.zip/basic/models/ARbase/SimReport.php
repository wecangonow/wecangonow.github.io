<?php

namespace app\models\ARbase;

use Yii;

/**
 * This is the model class for table "sim_report".
 *
 * @property integer $id
 * @property string $event
 * @property string $channel
 * @property string $subchannel
 * @property string $version
 * @property string $locale
 * @property string $uuid
 * @property string $Appid
 * @property string $params
 * @property string $create_time
 */
class SimReport extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'sim_report';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['event', 'channel', 'subchannel', 'version', 'locale', 'uuid', 'appid', 'params', 'create_time'], 'required'],
            [['params'], 'string'],
            [['event','create_time', 'appid', 'locale', 'version', 'channel', 'subchannel', 'uuid'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'event' => 'Event',
            'channel' => 'Channel',
            'subchannel' => 'Subchannel',
            'version' => 'Version',
            'locale' => 'Locale',
            'uuid' => 'Uuid',
            'Appid' => 'Appid',
            'params' => 'Params',
            'create_time' => 'Create Time',
        ];
    }
}
