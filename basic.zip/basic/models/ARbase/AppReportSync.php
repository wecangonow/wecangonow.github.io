<?php

namespace app\models\ARbase;

use Yii;

/**
 * This is the model class for table "app_report_sync".
 *
 * @property integer $id
 * @property integer $r_id
 * @property string $appName
 * @property string $packageName
 * @property string $versionName
 * @property integer $versionCode
 * @property integer $update_time
 * @property integer $create_time
 */
class AppReportSync extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'app_report_sync';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['r_id', 'versionCode'], 'integer'],
            [['appName', 'packageName', 'versionName'], 'string', 'max' => 255],
            [['create_time','update_time'],'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'r_id' => 'R ID',
            'appName' => 'App Name',
            'packageName' => 'Package Name',
            'versionName' => 'Version Name',
            'versionCode' => 'Version Code',
            'update_time' => 'Update Time',
            'create_time' => 'Create Time',
        ];
    }
}
