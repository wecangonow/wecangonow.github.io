<?php

namespace app\models\ARbase;

use Yii;

/**
 * This is the model class for table "up_user".
 *
 * @property integer $id
 * @property string $username
 * @property string $password
 * @property string $create_time
 * @property string $update_time
 */
class UpUser extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'up_user';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['username', 'password', 'create_time', 'update_time'], 'required'],
            [['create_time', 'update_time'], 'safe'],
            [['username', 'password'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'username' => 'Username',
            'password' => 'Password',
            'create_time' => 'Create Time',
            'update_time' => 'Update Time',
        ];
    }
}
