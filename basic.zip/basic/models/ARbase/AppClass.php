<?php

namespace app\models\ARbase;

use Yii;

/**
 * This is the model class for table "app_class".
 *
 * @property integer $id
 * @property string $name
 * @property string $pt_name
 * @property string $en_name
 * @property string $lang
 * @property integer $type
 * @property integer $sort
 * @property string $link
 * @property integer $update_time
 * @property integer $create_time
 */
class AppClass extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'app_class';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name','lang'], 'required'],
            [['type', 'sort', 'update_time', 'create_time'], 'integer'],
            [['link'], 'url'],
            [['name', 'pt_name', 'en_name'], 'string', 'max' => 255],
            [['lang'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'pt_name' => 'Pt Name',
            'en_name' => 'En Name',
            'lang' => 'Lang',
            'type' => 'Type',
            'sort' => 'Sort',
            'link' => 'Link',
            'update_time' => 'Update Time',
            'create_time' => 'Create Time',
        ];
    }
}
