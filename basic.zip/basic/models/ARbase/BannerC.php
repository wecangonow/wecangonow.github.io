<?php

namespace app\models\ARbase;

use Yii;

/**
 * This is the model class for table "banner".
 *
 * @property integer $id
 * @property string  $name
 * @property string  $size
 * @property integer $sort
 * @property string  $img
 * @property string  $link
 */
class BannerC extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName() {

        return 'banner';
    }

    /**
     * @inheritdoc
     */
    public function rules() {

        return [
            [['name', 'size', 'sort', 'img', 'link','lang'], 'required'],
            [['sort'], 'integer'],
            [['link'], 'safe'],
        ];
    }


    /**
     * @inheritdoc
     */
    public function attributeLabels() {

        return [
            'id'   => 'ID',
            'name' => 'Banner名称',
            'size' => '类型',
            'sort' => '排序',
            'img'  => '图片',
            'link' => '链接地址',
        ];
    }
}
