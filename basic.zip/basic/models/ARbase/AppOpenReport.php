<?php

namespace app\models\ARbase;

use Yii;

/**
 * This is the model class for table "app_open_report".
 *
 * @property integer $id
 * @property string $name
 * @property integer $num
 * @property string $create_time
 */
class AppOpenReport extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'app_open_report';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['num','unum'], 'integer'],
            [['create_time'], 'safe'],
            [['name'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'num' => 'Num',
            'unum' => 'Unum',
            'create_time' => 'Create Time',
        ];
    }
}
