<?php

namespace app\models\ARbase;

use Yii;

/**
 * This is the model class for table "app_time_long".
 *
 * @property integer $id
 * @property string $package
 * @property string $uuid
 * @property integer $time
 * @property integer $long
 * @property string $create_time
 */
class AppTimeLong extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'app_time_long';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['time', 'long'], 'integer'],
            [['create_time'], 'safe'],
            [['package', 'uuid'], 'string', 'max' => 255]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'package' => 'Package',
            'uuid' => 'Uuid',
            'time' => 'Time',
            'long' => 'Long',
            'create_time' => 'Create Time',
        ];
    }
}
