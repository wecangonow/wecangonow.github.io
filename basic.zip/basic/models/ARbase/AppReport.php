<?php

namespace app\models\ARbase;

use Yii;

/**
 * This is the model class for table "app_report".
 *
 * @property integer $id
 * @property string $os
 * @property string $adid
 * @property string $time
 * @property string $locale
 * @property string $imei
 * @property string $appid
 * @property string $mac
 * @property string $aid
 * @property string $uuid
 * @property string $vm_version
 * @property string $channel
 * @property string $os_version
 * @property integer $create_time
 */
class AppReport extends \yii\db\ActiveRecord
{
    public $type;
    public $date;
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'app_report';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['os', 'adid', 'mac', 'aid', 'uuid','time', 'locale', 'imei', 'appid'], 'string', 'max' => 255],
            [['vm_version'], 'string', 'max' => 100],
            [['channel', 'os_version'], 'string', 'max' => 50],
            [['create_time','type','date'],'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'os' => 'Os',
            'adid' => 'Adid',
            'time' => 'Time',
            'locale' => 'Locale',
            'imei' => 'Imei',
            'appid' => 'Appid',
            'mac' => 'Mac',
            'aid' => 'Aid',
            'type' => 'Type',
            'date' => 'Date',
            'uuid' => 'Uuid',
            'vm_version' => 'Vm Version',
            'channel' => 'Channel',
            'os_version' => 'Os Version',
            'create_time' => 'Create Time',
        ];
    }
}
