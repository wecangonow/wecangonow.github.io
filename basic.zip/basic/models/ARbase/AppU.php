<?php

namespace app\models\ARbase;

use Yii;

/**
 * This is the model class for table "app".
 *
 * @property integer $id
 * @property string $name
 * @property string $pt_name
 * @property string $en_name
 * @property integer $class
 * @property string $size
 * @property integer $is_recommend
 * @property integer $is_hot
 * @property string $lang
 * @property integer $tag
 * @property integer $level
 * @property integer $sort
 * @property integer $recommend_sort
 * @property integer $hot_sort
 * @property string $img
 * @property string $link
 */
class AppU extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'app';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'tag', 'sort','link','lang','level','p_class','class'], 'required'],
            [['class', 'is_recommend', 'is_hot','create_time','update_time', 'tag', 'sort', 'recommend_sort', 'hot_sort'], 'integer'],
            [['name'], 'string', 'max' => 50],
            [['pt_name', 'en_name', 'size'], 'string', 'max' => 255],
            [['lang'], 'string', 'max' => 45],
            [['link'], 'string', 'max' => 500],
            ['img', 'image'],
            ['level','number','min'=>0,'max'=>5]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => '应用名称',
            'pt_name' => '葡语应用名称',
            'en_name' => '英语应用名称',
            'p_class' => '父级分类',
            'class' => '子级分类',
            'size' => '应用大小',
            'is_recommend' => '精品推荐',
            'is_hot' => '热门排行',
            'lang' => '语言',
            'tag' => '标签',
            'level' => '星级',
            'sort' => '排序',
            'recommend_sort' => '排序',
            'hot_sort' => '排序',
            'img' => '图片',
            'link' => '链接',
        ];
    }
}
