<?php

namespace app\models\VLform;

use Yii;
use app\models\ARbase\Hwmconf;

/**
 * This is the model class for table "Hwmconf".
 *
 * @property integer $id
 * @property string $name
 * @property string $value
 */
class HwmconfForm extends Hwmconf
{


    public $up_lock;
    public $up_ver;
    public $up_dlurl;
    public $up_md5;

    public $reup_lock;
    public $reup_ver;
    public $reup_dlurl;
    public $reup_md5;

    public $new_ver;
    public $new_dlurl;


    public function rules()
    {
        return [
            [['up_lock', 'up_ver','up_dlurl','up_md5','new_ver','new_dlurl',], 'required'],
            [['up_dlurl','new_dlurl'], 'url'],
            [['up_md5'], 'string','length' => 32]
        ];
    }




}
