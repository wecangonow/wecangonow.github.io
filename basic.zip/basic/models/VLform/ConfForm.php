<?php

namespace app\models\VLform;

use Yii;
use app\models\ARbase\Conf;

/**
 * This is the model class for table "conf".
 *
 * @property integer $id
 * @property string $name
 * @property string $value
 */
class ConfForm extends Conf
{


    public $up_lock;
    public $up_ver;
    public $up_dlurl;
    public $up_md5;

    public $reup_lock;
    public $reup_ver;
    public $reup_dlurl;
    public $reup_md5;

    public $new_ver;
    public $new_dlurl;
    public $new_uninclude_ver;
    public $new_uninclude_dlurl;


    public function rules()
    {
        return [
            [['up_lock', 'up_ver', 'up_dlurl', 'up_md5', 'reup_lock', 'reup_ver', 'reup_dlurl', 'reup_md5', 'new_ver', 'new_dlurl', 'new_uninclude_ver', 'new_uninclude_dlurl'], 'required'],
            [['up_dlurl', 'reup_dlurl', 'new_dlurl', 'new_uninclude_dlurl'], 'url'],
            [['up_md5', 'reup_md5'], 'string', 'length' => 32]
        ];
    }


}
