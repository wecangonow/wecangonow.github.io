<?php

namespace app\models\VLform;

use app\models\ARbase\AppClass;
use Yii;

/**
 * UploadForm is the model behind the upload form.
 */
class AppclassForm extends AppClass
{

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name','lang'], 'required'],
            [['type', 'sort', 'update_time', 'create_time'], 'integer'],
            [['link'], 'url'],
            [['name', 'pt_name', 'en_name'], 'string', 'max' => 255],
            [['lang'], 'string', 'max' => 255]
        ];
    }
    public function checksort(){
        if ($this->sort<0) {
            echo $this->addError('sort', "排序不能有空,或者为负数");
        }
    }
}
?>
