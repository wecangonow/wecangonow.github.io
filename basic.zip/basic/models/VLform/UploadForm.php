<?php

namespace app\models\VLform;

use Yii;
use yii\base\Model;

use yii\web\UploadedFile;

/**
 * UploadForm is the model behind the upload form.
 */
class UploadForm extends Model
{
    /**
     * @var UploadedFile|Null file attribute
     */
    public $file;

    public $sign;

    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            [['file'], 'file', 'maxSize' => 4194304],
            [['sign'], 'safe'],
        ];
    }
}
