<?php

namespace app\models\VLform;

use Yii;
use app\models\ARbase\UpUser;

/**
 * User represents the model behind the valid form about `app\models\ARbase\UpUser`.
 */
class UserSubForm extends UpUser
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['password'], 'required'],
        ];
    }
}
