<?php

namespace app\models\SCform;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\ARbase\App;
use yii\db\Query;

/**
 * Appsearch represents the model behind the search form about `app\models\ARbase\App`.
 */
class Appsearch extends App
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['class', 'is_recommend', 'is_hot', 'create_time', 'update_time', 'tag', 'level', 'sort', 'recommend_sort', 'hot_sort'], 'integer'],
            [['name'], 'string', 'max' => 50],
            [['pt_name', 'en_name', 'size'], 'string', 'max' => 255],
            [['lang'], 'string', 'max' => 45],
            [['link'], 'string', 'max' => 500],
            [['name', 'tag', 'sort', 'link', 'lang', 'level', 'p_class', 'class'], 'safe'],
            ['img', 'image'],
            ['level', 'number', 'min' => 0, 'max' => 5]
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = App::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [
                    'sort' => SORT_ASC,
                ],]
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'id' => $this->id,
            'tag' => $this->tag,
            'level' => $this->level,
            'p_class' => $this->p_class,
            'class' => $this->class,
            'sort' => $this->sort,
        ]);

        $query->andFilterWhere(['like', 'name', $this->name])
            ->andFilterWhere(['=', 'tag', $this->tag])
            ->andFilterWhere(['like', 'lang', $this->lang]);

        return $dataProvider;
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function searchRecommend($params)
    {
        $query = App::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [
                    'recommend_sort' => SORT_ASC,
                ],]
        ]);

        $this->load($params);

//        if (!$this->validate()) {
        // uncomment the following line if you do not want to return any records when validation fails
        $query->where('is_recommend=1');
//        }

        $query->andFilterWhere([
            'id' => $this->id,
            'tag' => $this->tag,
            'level' => $this->level,
            'p_class' => $this->p_class,
            'class' => $this->class,
            'sort' => $this->sort,
        ]);

        $query->andFilterWhere(['like', 'name', $this->name])
            ->andFilterWhere(['=', 'tag', $this->tag])
            ->andFilterWhere(['like', 'lang', $this->lang]);

        return $dataProvider;
    }
    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function searchHot($params)
    {
        $query = App::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                'defaultOrder' => [
                    'hot_sort' => SORT_ASC,
                ],]
        ]);

        $this->load($params);

//        if (!$this->validate()) {
        // uncomment the following line if you do not want to return any records when validation fails
        $query->where('is_hot=1');
//        }

        $query->andFilterWhere([
            'id' => $this->id,
            'tag' => $this->tag,
            'level' => $this->level,
            'p_class' => $this->p_class,
            'class' => $this->class,
            'sort' => $this->sort,
        ]);

        $query->andFilterWhere(['like', 'name', $this->name])
            ->andFilterWhere(['=', 'tag', $this->tag])
            ->andFilterWhere(['like', 'lang', $this->lang]);

        return $dataProvider;
    }
    public function checkapp($name){
        $query = new Query();
        $data = $query->select(['*'])->from(['app'])->where(['name'=>$name])->one();
        return $data;
    }
    public function checkClassIsHaveApp($id){
        $sql = 'select `id` from `app` where (p_class = '.$id.' or class='.$id.')';
        $data = Yii::$app->db->createCommand($sql)->queryOne();
        return $data;
    }

}
