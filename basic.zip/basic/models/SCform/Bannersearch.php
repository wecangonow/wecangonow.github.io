<?php

namespace app\models\SCform;

use app\models\ARbase\Banner;
use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\ARbase\App;

/**
 * Appsearch represents the model behind the search form about `app\models\ARbase\App`.
 */
class Bannersearch extends Banner
{
    /**
     * @inheritdoc
     */
   

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Banner::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort'=>[
                'defaultOrder' => [
                    'sort' => SORT_ASC,
                ],]
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'id' => $this->id,
            'sort' => $this->sort,
        ]);


        return $dataProvider;
    }
}
