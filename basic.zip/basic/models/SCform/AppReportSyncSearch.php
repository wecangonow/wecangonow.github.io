<?php

namespace app\models\SCform;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\ARbase\AppReportSync;
use yii\db\Query;

/**
 * AppReportSyncSearch represents the model behind the search form about `app\models\ARbase\AppReportSync`.
 */
class AppReportSyncSearch extends AppReportSync
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'r_id', 'versionCode'], 'integer'],
            [['appName', 'packageName', 'versionName', 'update_time', 'create_time'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = AppReportSync::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'id' => $this->id,
            'r_id' => $this->r_id,
            'versionCode' => $this->versionCode,
            'update_time' => $this->update_time,
            'create_time' => $this->create_time,
        ]);

        $query->andFilterWhere(['like', 'appName', $this->appName])
            ->andFilterWhere(['like', 'packageName', $this->packageName])
            ->andFilterWhere(['like', 'versionName', $this->versionName]);

        return $dataProvider;
    }

    /**
     * @param $r_id
     * @param $uuid
     * @param $imei
     * @param $appName
     * @param $packageName
     */
    public function checkUuidAppIsExist($r_id,$appName,$packageName,$date){
        $query = new Query();
        $query->select(['*'])->from('app_report_sync')->where(['r_id'=>$r_id]);
        $query->andWhere(['appName'=>$appName]);
        $query->andWhere(['packageName'=>$packageName]);
        $query->andWhere(['create_time'=>$date]);
        $dataList = $query->all();
        return $dataList;
    }

    public function getAllAppEachNum($postdata){
        $sql = 'select create_time as date,appName,count(\'appName\') as num from `app_report_sync` where create_time="'.$postdata['date'].'" group by appName  order by '.($postdata['sort']?$postdata['sort']:'num').' '.($postdata['desc']==1?'asc':'desc').'';
        $dataList = Yii::$app->db->createCommand($sql)->queryAll();
        return $dataList;
    }
}
