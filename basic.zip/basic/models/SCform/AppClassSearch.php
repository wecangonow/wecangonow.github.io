<?php

namespace app\models\SCform;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\ARbase\AppClass;
use yii\db\Query;

/**
 * AppClassSearch represents the model behind the search form about `app\models\ARbase\AppClass`.
 */
class AppClassSearch extends AppClass
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'type', 'sort', 'update_time', 'create_time'], 'integer'],
            [['name', 'pt_name', 'en_name', 'lang', 'link'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = new Query();
        $query->select(['*'])
            ->from(['app_class']);

        $this->setWhere($query, $params);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'sort' => [
                // Set the default sort by name ASC and created_at DESC.
                'defaultOrder' => [
                    'id' => SORT_DESC,
                ],
                'attributes' => ['id', 'name','type','lang','sort','create_time', 'update_time'],
            ],
            'pagination' => [
                'pageSize' => 20,
            ],
        ]);

        return $dataProvider;
    }

    public function setWhere($query, $params)
    {
        if (!empty($params['AppClassSearch']['name'])) {
            $query->andwhere(['like', 'name', $params['AppClassSearch']['name']]);
        }
        if ($params['AppClassSearch']['type'] !== '' && $params['AppClassSearch']['type'] !== NULL) {
            $query->andwhere(['type' => $params['AppClassSearch']['type']]);
        }
        if (!empty($params['AppClassSearch']['lang']) && $params['AppClassSearch']['lang']!=1) {
            $query->andwhere(['like', 'lang', $params['AppClassSearch']['lang']]);
        }
    }
    /**
     * 获取顶级分类
     * @return array
     */
    public function getTopClass(){
        $query = new Query();
        $topClass = $query->select(['*'])->from("app_class")->where(['type'=>0])->all();
        return $topClass;
    }
    public function getOtherClass(){
        $query = new Query();
        $topClass = $query->select(['*'])->from("app_class")->where('type!=0')->all();
        return $topClass;
    }
    public function getClassByPClass($p_class){

        $query = new Query();
        $Class = $query->select(['*'])->from("app_class")->where(['type'=>$p_class])->all();
        return $Class;
    }
    public function getClassByName($name){
        $query = new Query();
        $Class = $query->select(['*'])->from("app_class")->where(['name'=>$name])->one();
        return $Class;
    }
    public function checkClassIsParentClass($id){

        $query = new Query();
        $Class = $query->select(['*'])->from("app_class")->where(['type'=>$id])->one();
        return $Class;
    }
}
