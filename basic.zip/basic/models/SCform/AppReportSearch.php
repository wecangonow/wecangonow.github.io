<?php

namespace app\models\SCform;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\ARbase\AppReport;
use yii\db\Query;

/**
 * AppReportSearch represents the model behind the search form about `app\models\ARbase\AppReport`.
 */
class AppReportSearch extends AppReport
{
    public $type;
    public $date;
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id'], 'integer'],
            [['os', 'adid', 'mac', 'aid', 'uuid', 'vm_version', 'time', 'locale', 'imei', 'appid', 'create_time', 'channel', 'os_version','type','date'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = AppReport::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'id' => $this->id,
            'time' => $this->time,
            'locale' => $this->locale,
            'imei' => $this->imei,
            'appid' => $this->appid,
            'create_time' => $this->create_time,
        ]);

        $query->andFilterWhere(['like', 'os', $this->os])
            ->andFilterWhere(['like', 'adid', $this->adid])
            ->andFilterWhere(['like', 'mac', $this->mac])
            ->andFilterWhere(['like', 'aid', $this->aid])
            ->andFilterWhere(['like', 'uuid', $this->uuid])
            ->andFilterWhere(['like', 'vm_version', $this->vm_version])
            ->andFilterWhere(['like', 'channel', $this->channel])
            ->andFilterWhere(['like', 'os_version', $this->os_version]);

        return $dataProvider;
    }
    public function getUserPcListData(){
        $query = new Query();
        $appReportList = $query->select(["*"])->from("app_report")->all();
        return $appReportList;
    }

    public function checkUuidAppIsExist($pc,$time){
        $query= new Query();
        $query->select(['*'])->from(['app_report'])->where(['uuid'=>$pc['uuid']]);
        $query->andWhere(['create_time'=>$time]);
        $dataList = $query->andWhere(['mac'=>$pc['mac']])->one();
        return $dataList;
    }
    public function getDauByDate($date){
        $query = new Query();
        $appReportList = $query->select(["*"])->from("app_report")->where(['create_time'=>$date])->groupBy(['uuid'])->all();
        return $appReportList;
    }
    public function getAnalogNumByDate($date){
        $sql = 'select uuid,count(mac) as macnum from app_report where create_time="'.$date.'" group by uuid';
        $dataList = Yii::$app->db->createCommand($sql)->queryAll();
        return $dataList;
    }
}
