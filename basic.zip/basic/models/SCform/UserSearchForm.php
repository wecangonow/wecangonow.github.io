<?php

namespace app\models\SCform;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\ARbase\UpUser;

/**
 * User represents the model behind the search form about `app\models\ARbase\UpUser`.
 */
class UserSearchForm extends UpUser
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['username', 'password', 'create_time', 'update_time'], 'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        if (Yii::$app->user->getIdentity()->username == "admin")
            $query = UpUser::find();
        else
            $query = UpUser::find()->where(["username" => Yii::$app->user->getIdentity()->username]);

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => 20,
            ],
        ]);

        if (!($this->load($params) && $this->validate())) {
            return $dataProvider;
        }

        $query->andFilterWhere(['like', 'username', $this->username])
            ->andFilterWhere(['like', 'password', $this->password])
            ->andFilterWhere(['like', 'create_time', $this->create_time])
            ->andFilterWhere(['like', 'create_time', $this->update_time]);
        return $dataProvider;
    }
}
