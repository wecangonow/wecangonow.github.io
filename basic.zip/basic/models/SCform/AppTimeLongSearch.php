<?php

namespace app\models\SCform;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\ARbase\AppTimeLong;
use yii\db\Query;

/**
 * AppTimeLongSearch represents the model behind the search form about `app\models\ARbase\AppTimeLong`.
 */
class AppTimeLongSearch extends AppTimeLong
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'time', 'long'], 'integer'],
            [['package', 'uuid', 'create_time'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = AppTimeLong::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'id' => $this->id,
            'time' => $this->time,
            'long' => $this->long,
            'create_time' => $this->create_time,
        ]);

        $query->andFilterWhere(['like', 'package', $this->package])
            ->andFilterWhere(['like', 'uuid', $this->uuid]);

        return $dataProvider;
    }
    public function getAppTimeLongByDate($postdata){
        $sql = 'select `id`,`package`,`uuid`,`time`,`long`,`create_time` from `app_time_long` where create_time="'.$postdata['date'].'" and package!="" order by `'.($postdata['sort']?$postdata['sort']:'id').'` '.($postdata['desc']==1?'asc':'desc').'';
//        echo $sql;die;
        $dataList = Yii::$app->db->createCommand($sql)->queryAll();
        return $dataList;

    }
}
