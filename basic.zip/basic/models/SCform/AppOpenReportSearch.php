<?php

namespace app\models\SCform;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\ARbase\AppOpenReport;
use yii\db\Query;

/**
 * AppOpenReportSearch represents the model behind the search form about `app\models\ARbase\AppOpenReport`.
 */
class AppOpenReportSearch extends AppOpenReport
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'num','unum'], 'integer'],
            [['name', 'create_time'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = AppOpenReport::find();

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        $query->andFilterWhere([
            'id' => $this->id,
            'num' => $this->num,
            'unum' => $this->unum,
            'create_time' => $this->create_time,
        ]);

        $query->andFilterWhere(['like', 'name', $this->name]);

        return $dataProvider;
    }
    public function getAppTimesByDate($postdata){
        $sql = 'select * from `app_open_report` where create_time="'.$postdata['date'].'" group by `name` order by '.($postdata['sort']?$postdata['sort']:'id').' '.($postdata['desc']==1?'asc':'desc').'';
        $dataList = Yii::$app->db->createCommand($sql)->queryAll();
        return $dataList;
    }
}
