<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "auth".
 *
 * @property integer $id
 * @property integer $topid
 * @property string $name
 * @property string $value
 */
class Auth extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'auth';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['topid', 'name', 'value'], 'required'],
            [['topid'], 'integer'],
            [['name', 'value'], 'string', 'max' => 30]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'topid' => 'Topid',
            'name' => 'Name',
            'value' => 'Value',
        ];
    }

    //获取权限列表
    public static function getall(){
        $rows=Auth::find()->where(['topid'=>0])->asArray()->all();
        foreach($rows as $key=>$val){
            $rows[$key]['son']=Auth::find()->where(['topid'=>$val['id']])->asArray()->all();
        }

        return $rows;
    }
}
