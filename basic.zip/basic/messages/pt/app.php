<?php
return [
    'home'=>'Página de Carregamento',
    'game'=>'Jogos',
    'soft'=>'Aplicativos',
    'more'=>'Mais',
    'rec_game'=>'Jogos Recomendados',
    'rec_soft'=>'Aplicativos Recomendados',
    'hot_game'=>'Ranking de Jogos Populares',
    'hot_soft'=>'Ranking de Aplicativos Populares',
    'down'=>'Baixar',
    'all'=>'Todos',
    'rec'=>'Recomendo',
    'hot'=>'Popular',
    'allcate'=>'Todas categorias',
    'search'=>'Inscreva o nome de aplicativo ou jogo',
    'open'=>'abrir',
    'sitename'=>'Loja Simcake'


];
?>
 