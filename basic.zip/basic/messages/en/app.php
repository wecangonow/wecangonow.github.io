<?php
return [
    'home'=>'Home Page',
    'game'=>'Games',
    'soft'=>'Applications',
    'more'=>'More',
    'rec_game'=>'Recommended Games',
    'rec_soft'=>'Recommended Applications',
    'hot_game'=>'Popular Games Chart',
    'hot_soft'=>'Popular Applications Chart',
    'down'=>'Install',
    'all'=>'All',
    'rec'=>'Recommend',
    'hot'=>'Popular',
    'allcate'=>'All categories',
    'search'=>'Please type in the name of game or application',
    'open'=>'Open',
    'sitename'=>'Simcake Market '


];
?>
