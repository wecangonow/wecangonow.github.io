<?php

//return [
//    'class' => 'yii\caching\MemCache',
//    'useMemcached' => true,
//    'keyPrefix' =>'up_',
//    'servers' => [
//        [
//            'host' => '52.67.94.16',
//            'port' => 11211,
//            'weight' => 1,
//        ]
//    ],
//];

return [
    'class' => 'yii\caching\MemCache',
    'useMemcached' => true,
    'keyPrefix' =>'up_',
    'servers' => [
        [
            'host' => '10.1.9.145',
            'port' => 11211,
            'weight' => 1,
        ]
    ],
];
