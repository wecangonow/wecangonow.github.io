<?php

$params = require(__DIR__ . '/params.php');

$config = [
    'id'           => 'basic',
    'basePath'     => dirname(__DIR__),
    'bootstrap'    => ['log'],
    'defaultRoute' => 'ssite', 
    'components'   => [
        'urlManager'   => [
            'enablePrettyUrl' => true,
            'showScriptName'  => false,
        ],
        'request'      => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey'  => '4SI1yjZva7qdEtMw6NyaN9wuzmpMnIx8',
            'enableCsrfValidation' => false,
        ],
        'cache'        => require(__DIR__ . '/cache.php'),
        'user'         => [
            'identityClass'   => 'app\models\User',
            'enableAutoLogin' => true,
        ],
        'errorHandler' => [
            'errorAction' => 'ssite/error',
        ],
        'mailer'       => [
            'class'            => 'yii\swiftmailer\Mailer',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => true,
        ],
        'log'          => [
            'traceLevel' => YII_DEBUG ? 1 : 0,
            'targets'    => [
                YII_DEBUG ? [
                    'class'      => 'yii\log\FileTarget',
                    'logVars'    => '',
                    'categories' => ['yii\db\*', 'application'],
                    'levels'     => ['trace', 'info', 'error', 'warning'],
                ]
                    :
                    [
                        'class'  => 'yii\log\FileTarget',
                        'levels' => ['error', 'warning'],
                    ],
            ],
        ],

        'i18n'         => [
            'translations' => [
                'app' => [
                    'class'    => 'yii\i18n\PhpMessageSource',
                    //'basePath' => '@language',
                    'fileMap'  => [
                        'app'       => 'app.php'
                    ],
                ],
            ],
        ],

        'db'           => require(__DIR__ . '/db.php'),
    ],
    'params'       => $params,
];

if (YII_ENV_DEV)
{
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][]      = 'debug';
    $config['modules']['debug'] = 'yii\debug\Module';

    $config['bootstrap'][]    = 'gii';
    $config['modules']['gii'] = 'yii\gii\Module';
}

return $config;
