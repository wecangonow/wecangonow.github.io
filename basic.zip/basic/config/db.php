<?php

return [
    'class' => 'yii\db\Connection',
'dsn' => 'mysql:host=10.1.9.102:3306;dbname=simcake',
'username' => 'root',
'password' => '123456',
'charset' => 'utf8',
];
