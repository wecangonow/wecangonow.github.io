<?php

return [
    'adminEmail' => 'admin@example.com',
    'upcleanerKey' => 'Ie10e4UUj5GiO09kVfm_Zi2wx-NGDYY0',
    'webpath' => 'http://bg.simcake.com/',
    'cdnurl' => 'http://static.simcake.com/'
];


