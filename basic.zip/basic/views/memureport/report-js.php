<?php
/**
 * Created by PhpStorm.
 * User: chunyu
 * Date: 16/4/7
 * Time: 上午11:48
 */
$date = date("Y-m-d");
?>
var date = "<?=$date;?>"
$(function(){


    $("#appreportsearch-date").click(function(i){
        $(this).next().click();
    })
    $("#appreportsearch-date").keydown(function(i){
        return false;
    })
    $(".btn-primary").click(function(){
        if($("#appreportsearch-date").val()==''){
            alert("请选择日期");
            return false;
        }
        if($("#appreportsearch-date").val()>= date){
            alert("日期必须是过去的日子");
            return false;
        }
        if($("#appreportsearch-type").val()==''){
            alert("请选择报表类型");
            return false;
        }
    })
})