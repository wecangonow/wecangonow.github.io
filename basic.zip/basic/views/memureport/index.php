<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel report\models\SCform\Reportsearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Reports';
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
    .grid-view {
        max-width: 100%;
    }

    .summary {
        display: inline-block;
    }

    td a {
        padding: 5px;
    }

    .form-inline {
        max-width: 100%;
        margin-bottom: 10px;
    }

    .search-group {
        float: right;
    }
</style>
<div class="report-index">
    <h1></h1>

    <div class="form-inline" style="margin-bottom:25px">
        <span>
        <?php echo $this->render('_search', ['model' => $searchModel,'appconfig'=>$appconfig]); ?>
        </span>
    </div>
    </form>
</div>
