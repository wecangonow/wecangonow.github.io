<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use nkovacs\datetimepicker\DateTimePicker;

/* @var $this yii\web\View */
/* @var $model report\models\SCform\reportsearch */
/* @var $form yii\widgets\ActiveForm */
?>
    <style>
        .form-inline .form-group {
            vertical-align: baseline;
        }

        .form-control {
            padding: 0px;
        }
    </style>

    <div class="report-search">
        <div class="form-inline">
            <?php $form = ActiveForm::begin([
                'action' => ['index'],
                'method' => 'get'
            ]); ?>

            <?= $form->field($model, 'date')->widget(DateTimePicker::className(), [
                'type' => 'datetime',
                'format' => 'php:Y-m-d',
                'clientOptions' => [
                    'sideBySide' => true,
                ]
            ])->label('') ?>

            <?= $form->field($model, 'type')->dropDownList([1 => 'dau', 2 => 'app chart', 3 => 'simulator', 4 => 'app times ', 5 => 'app open long'], ['prompt' => '请选择报表内容']) ?>
            <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
            <?php ActiveForm::end(); ?>
        </div>

    </div>
<?php $this->registerJsFile("report/report-js", ['depends' => 'yii\bootstrap\BootstrapPluginAsset']); ?>