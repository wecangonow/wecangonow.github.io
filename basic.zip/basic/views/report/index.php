<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel report\models\SCform\Reportsearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Reports';
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
    .grid-view {
        max-width: 100%;
    }

    .summary {
        display: inline-block;
    }

    td a {
        padding: 5px;
    }

    .form-inline {
        max-width: 100%;
        margin-bottom: 10px;
    }

    .search-group {
        float: right;
    }
</style>
<div class="report-index">
    <h1></h1>

    <div class="form-inline" style="margin-bottom:25px">
        <span>
        <?php echo $this->render('_search', ['model' => $searchModel]); ?>
        </span>
    </div>
    </form>
    <form id="report" action="/report/sort" method="post" onsubmit="return check(this)">
        <?php
        if (isset($tableArr)) {
            if ($tableArr['type'] == 1) {
                ?>
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>DATE</th>
                        <th>NUMBER</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr data-key="1">
                        <td><?= $tableArr['date']; ?></td>
                        <td><?= $tableArr['dau']; ?></td>
                    </tr>
                    </tbody>
                </table>
                <?php

            } elseif ($tableArr['type'] == 2) {
                ?>
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th width="20%">DATE</th>
                        <th width="40%"><a data-sort="name" href="/report/index?AppReportSearch[sort]=appName&AppReportSearch[type]=2&AppReportSearch[desc]=<?=$tableArr['desc']?>&AppReportSearch[date]=<?=$tableArr['date'];?>">APPNAME</a></th>
                        <th width="40%"><a data-sort="name" href="/report/index?AppReportSearch[sort]=num&AppReportSearch[type]=2&AppReportSearch[desc]=<?=$tableArr['desc']?>&AppReportSearch[date]=<?=$tableArr['date'];?>">NUM</a></th>
                    </tr>
                    </thead>
                    <?php
                    foreach ($tableArr['datalist'] as $key => $value) {
                        ?>
                        <tbody>
                        <tr data-key="1">
                            <td width="20%"><?= $value['date']; ?></td>
                            <td width="40%"><?= $value['appName']; ?></td>
                            <td width="40%"><?= $value['num']; ?></td>
                        </tr>
                        </tbody>
                        <?php
                    }
                    ?>
                </table>
                <?php
            }elseif ($tableArr['type'] == 3) {
                ?>
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th>DATE</th>
                        <th>ONLY</th>
                        <th>MORE</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr data-key="1">
                        <td><?= $tableArr['date']; ?></td>
                        <td><?= $tableArr['analogOne']; ?></td>
                        <td><?= $tableArr['analogMore']; ?></td>
                    </tr>
                    </tbody>
                </table>
            <?php
            }elseif ($tableArr['type'] == 4) {
                ?>
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th width="20%">DATE</th>
                        <th width="40%"><a data-sort="name" href="/report/index?AppReportSearch[sort]=name&AppReportSearch[type]=4&AppReportSearch[desc]=<?=$tableArr['desc']?>&AppReportSearch[date]=<?=$tableArr['date'];?>">PACKAGE</a></th>
                        <th width="40%"><a data-sort="num" href="/report/index?AppReportSearch[sort]=num&AppReportSearch[type]=4&AppReportSearch[desc]=<?=$tableArr['desc']?>&AppReportSearch[date]=<?=$tableArr['date'];?>">NUM</a></th>
                        <th width="40%"><a data-sort="unum" href="/report/index?AppReportSearch[sort]=unum&AppReportSearch[type]=4&AppReportSearch[desc]=<?=$tableArr['desc']?>&AppReportSearch[date]=<?=$tableArr['date'];?>">UNUM</a></th>
                    </tr>
                    </thead>
                    <?php
                    foreach ($tableArr['datalist'] as $key => $value) {
                        ?>
                        <tbody>
                        <tr data-key="1">
                            <td width="20%"><?= $value['create_time']; ?></td>
                            <td width="40%"><?= $value['name']; ?></td>
                            <td width="40%"><?= $value['num']; ?></td>
                            <td width="40%"><?= $value['unum']; ?></td>
                        </tr>
                        </tbody>
                        <?php
                    }
                    ?>
                </table>
                <?php
            }elseif ($tableArr['type'] == 5) {
                ?>
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr>
                        <th width="20%">DATE</th>
                        <th width="40%"><a data-sort="package" href="/report/index?AppReportSearch[sort]=package&AppReportSearch[type]=5&AppReportSearch[desc]=<?=$tableArr['desc']?>&AppReportSearch[date]=<?=$tableArr['date'];?>">PACKAGE</a></th>
                        <th width="40%"><a data-sort="long" href="/report/index?AppReportSearch[sort]=long&AppReportSearch[type]=5&AppReportSearch[desc]=<?=$tableArr['desc']?>&AppReportSearch[date]=<?=$tableArr['date'];?>">LONG</a></th>
                    </tr>
                    </thead>
                    <?php
                    foreach ($tableArr['datalist'] as $key => $value) {
                        ?>
                        <tbody>
                        <tr data-key="1">
                            <td width="10%"><?= $value['create_time']; ?></td>
                            <td width="20%"><?= $value['package']; ?></td>
                            <td width="10%"><?= date("H:i:s",($value['long']/1000)); ?></td>
                        </tr>
                        </tbody>
                        <?php
                    }
                    ?>
                </table>
                <?php
            }
        }
        ?>
    </form>
</div>
