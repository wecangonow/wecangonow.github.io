<?php
use yii\helpers\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\bootstrap\SideNavWidget;
use yii\widgets\Breadcrumbs;
use app\assets\AppAsset;

/* @var $this \yii\web\View */
/* @var $content string */

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>"/>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>

<?php $this->beginBody() ?>
<?php $this->endBody() ?>
<div class="wrap">
    <?php
    NavBar::begin([
        'brandLabel' => 'UPCLEANER BACKGROUD',
        'brandUrl' => Yii::$app->homeUrl,
        'options' => [
            'class' => 'navbar-inverse navbar-fixed-top',
        ],
    ]);
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-right nav'],
        'items' => [
            Yii::$app->user->isGuest ?
                ['label' => 'Login', 'url' => ['/ssite/login']] :
                ['label' => 'Logout (' . Yii::$app->user->identity->username . ')',
                    'url' => ['/ssite/logout'],
                    'linkOptions' => ['data-method' => 'post']],
        ],
    ]);
    NavBar::end();
    ?>
    <div class="row">
        <div class="col-md-2">
            <?php
            //route init
            $pathInfo = Yii::$app->request->pathInfo;
            $guest = Yii::$app->user->isGuest;
            $type = Yii::$app->request->get("type");
            $cache = Yii::$app->cache;
            $user_auths=$cache->get('user_auths'.Yii::$app->user->id);
            $item=[
                'items' => [
                    ['label' => 'Home', 'url' => ['/ssite/index'], 'active' => in_array($pathInfo, ["ssite/index"]) ? true : false],
                    ['label' => 'User management', 'url' => ['/user/index'], 'active' => in_array($pathInfo, ["user/index", "user/create", "user/update"]) ? true : false],
                    'banner'=>['label' => 'Banner', 'url' => ['/banner/index'], 'active' => in_array($pathInfo, ["banner/index", "banner/create", "banner/update"]) ? true : false],
                    'app'=>['label' => 'App', 'url' => ['/app/index'], 'active' => in_array($pathInfo, ["app/index", "app/create", "app/update"]) ? true : false],
                    'recommend'=>['label' => 'Recommend', 'url' => ['/recommend/index'], 'active' => in_array($pathInfo, ["recommend/index", "recommend/create", "recommend/update", "recommend/cancel"]) ? true : false],
                    'hot'=>['label' => 'Popular Chart', 'url' => ['/hot/index'], 'active' => in_array($pathInfo, ["hot/index", "hot/create", "hot/update", "hot/cancel"]) ? true : false],
                    'class'=>['label' => 'Class', 'url' => ['/appclass/index'], 'active' => in_array($pathInfo, ["appclass/index", "appclass/create", "appclass/update"]) ? true : false],
                    'report'=>['label' => 'Report', 'url' => ['/report/index'], 'active' => in_array($pathInfo, ["report/index"]) ? true : false],
                    'conf'=>['label' => '配置', 'url' => ['/conf/index'], 'active' => in_array($pathInfo, ["conf/index"]) ? true : false],
                    'hwmconf'=>['label' => 'HWM配置', 'url' => ['/hwmconf/index'], 'active' => in_array($pathInfo, ["hwmconf/index"]) ? true : false],


                ]
            ];
            if(Yii::$app->user->getIdentity()->username != 'admin')
            foreach($item['items'] as $key=>$val){

                if(in_array($key,$user_auths)||in_array($key,['0','1'])) continue;
                else
                    unset($item['items'][$key]);

            }

            if($guest) unset($item);
            echo SideNavWidget::widget($item);
            ?>
        </div>
        <div class="col-md-9 yii-content">
            <?=
            Breadcrumbs::widget([
                'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
            ]) ?>
            <?= $content ?>
        </div>
    </div>
</div>

</body>
</html>
<?php $this->endPage() ?>
