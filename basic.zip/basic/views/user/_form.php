<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\ARbase\UpUser */
/* @var $form yii\widgets\ActiveForm */
?>
<style>
    .dl1{}
    .dl1 dd{clear: both;background: #f0f0f0;padding: 5px 10px;}
    .dl1 dt{line-height: 35px;}
    .li{width: 120px;height: 30px;float: left}
</style>
<div class="up-user-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= Yii::$app->user->getIdentity()->username == 'admin' ? $form->field($model, 'username')->textInput(['maxlength' => 255,"value" => $modelU->username]): "" ?>

    <?= $form->field($model, 'password')->passwordInput(['maxlength' => 255]) ?>

    <dl class="dl1">
    <?php
    if(Yii::$app->user->getIdentity()->username == 'admin' && $modelU->id != 1)
        foreach($authrows as $val):?>
      <dd> <?=Html::input('checkbox','auths[]',$val['value'],['checked'=>in_array($val['value'],$user_auths)?true:false])?> <?=$val['name']?> </dd>
    <?php endforeach?>
    </dl>



    <div class="form-group">
        <?= Html::submitButton($modelU->isNewRecord ? 'Create' : 'Update', ['class' => $modelU->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
