<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\VLform\User */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Users';
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
.grid-view
 {
    max-width: 1000px;
 }
</style>
<div class=up-user-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <p>
        <?= Yii::$app->user->getIdentity()->username == 'admin' ? Html::a('Create User', ['create'], ['class' => 'btn btn-success']) : "" ?>
    </p>

    <?=
    GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            'username',
            'create_time',
            'update_time',
            Yii::$app->user->getIdentity()->username == 'admin' ?
                [
                    'class' => 'yii\grid\ActionColumn',
                    'template' => '{update} {delete}',
                    'buttons' => [
                        'delete' => function ($url, $model) {
                                if ($model->username != "admin") {
                                    return Html::a('<span class="glyphicon glyphicon-trash"></span>', $url, [
                                        'title' => Yii::t('yii', 'Delete'),
                                        'data-confirm' => Yii::t('yii', 'Are you sure you want to delete this item?'),
                                        'data-method' => 'post',
                                        'data-pjax' => '0',
                                    ]);
                                }
                            }
                    ],
                ]
                :
                [
                    'class' => 'yii\grid\ActionColumn',
                    'template' => '{update}',
                ]
            ,
        ],
    ]); ?>

</div>
