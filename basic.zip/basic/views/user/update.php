<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\ARbase\UpUser */

$this->title = 'Update User: ' . ' ' . $modelU->username;
$this->params['breadcrumbs'][] = ['label' => 'Users', 'url' => ['index']];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="up-user-update" style="width:31.6667%">
    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'modelU' => $modelU,
        'user_auths' => $user_auths,
        'authrows' => $authrows,
    ]) ?>



</div>
