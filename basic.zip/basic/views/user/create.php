<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\ARbase\UpUser */

$this->title = 'Create User';
$this->params['breadcrumbs'][] = ['label' => 'Users', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
$modelU->isNewRecord = 1;
?>
<div class="up-user-create" style="width:31.6667%">
    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'modelU' => $modelU,
    ]) ?>
</div>
