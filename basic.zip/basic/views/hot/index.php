<?php

use yii\helpers\Html;
use yii\grid\GridView;
use kartik\alert\Alert;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SCform\Appsearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Popular Chart';
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
    .hot_sort{width: 50px;}
    .app-search{ clear: both;height: 60px;}
    .app-search .form-group{width: auto;  float: left;padding:0 5px}
    .app-search .form-div{ padding: 25px 0 0 20px;}
    .grid-view{clear: both}
    .green{color: green}
    .red{color: red}
    .yel{color:yellowgreen }
</style>
<div class="app-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php if (Yii::$app->getSession()->hasFlash('success')) {
        echo Alert::widget([
            'options' => [
                'class' => 'alert-success', //这里是提示框的class
            ],
            'body' => Yii::$app->getSession()->getFlash('success'), //消息体
            'delay' => 3000,
        ]);
    }
    if (Yii::$app->getSession()->hasFlash('error')) {
        echo Alert::widget([
            'options' => [
                'class' => 'alert-danger',
            ],
            'body' => Yii::$app->getSession()->getFlash('error'),
            'delay' => 3000,
        ]);
    } ?>
    <?php  echo $this->render('_search', ['model' => $searchModel,
        'topClassList' => $topClassList,
        'config' => $config,
        'classList' => $classList,]); ?>

    <script>

        function check(form) {
            var status = 0;
            $("input.hot_sort").each(function () {
                if ($(this).val() == '' || $(this).val() <0) {
                    status = 1;
                    return false;
                }
            });
            if (status) {
                alert('排序不能有空,或者为负数');
                return false;
            }
        }


    </script>
    <?php
    $columns = [
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'id',
            'label' => 'ID',
            'headerOptions' => ['style' => 'width: 8%'],
            'enableSorting' => true,
        ],
        [
            'attribute' => 'sort',
            'label' => '排序',
            'content' => function ($model) {
                return "<input type='number' name='hot_sort[" . $model['id'] . "]' class='hot_sort' value='" . $model['hot_sort'] . "'>";
            }
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'name',
            'headerOptions' => ['style' => 'width: 10%'],
            'enableSorting' => true,
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'p_class',
            'headerOptions' => ['style' => 'width: 10%'],
            'enableSorting' => true,
            'format' => "raw",
            'value' => function ($model) use ($topClassList) {
                return $topClassList[$model['p_class']];
            }
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'class',
            'headerOptions' => ['style' => 'width: 10%'],
            'enableSorting' => true,
            'format' => "raw",
            'value' => function ($model) use ($otherClassList) {
                return $otherClassList[$model['class']];
            }
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'tag',
            'headerOptions' => ['style' => 'width: 6%'],
            'enableSorting' => true,
            'format' => "raw",
            'value' => function ($model) {
                if($model['tag']==0)
                return '无';
                if($model['tag']==1)
                    return 'hot';
                if($model['tag']==2)
                    return 'new';

            }
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'lang',
            'headerOptions' => ['style' => 'width: 10%'],
            'enableSorting' => true,
            'format' => "raw",
            'value' => function ($model) use ($config) {
                $array = [];
                foreach(explode(',',$model['lang']) as $key=>$value){
                    array_push($array,$config['app_lang'][$value]);
                }
                return implode(',',$array);
            }
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'update_time',
            'headerOptions' => ['style' => 'width: 20%'],
            'enableSorting' => true,
            'format' => "raw",
            'value' => function ($model) {
                return date("Y-m-d H:i:s",$model['update_time']);
            }
        ]
    ];
    $action = [
        'class' => 'yii\grid\ActionColumn',
        'template' => '{update} {cancel} ',
        'header' => '操作',
        'headerOptions' => ['style' => 'width: 13%'],
        'urlCreator' => function ($action, $model, $key, $index) {
            if ($action == 'update') {
                return '/app/' . $action . "?id=" . $model["id"];
            } else {
                return '/hot/' . $action . "?id=" . $model["id"];
            }
        },
        'buttons' => [
            'cancel' => function ($url, $model, $key) {
                $buttomclass = "glyphicon-remove";
                return Html::a('<span class="glyphicon ' . $buttomclass . '"></span>', $url, [
                    'title' => '取消排行',
                    'data-confirm' => Yii::t('yii', '你确定要取消排行吗?'),
                    'data-method' => 'post',
                    'data-pjax' => '0'
                ]);

            }
        ],
    ];
    //    if (Yii::$app->user->can('pluginManage')) {
    $columns[] = $action;
    //    }
    ?>
    <form name="categoryform" id="categoryform" method="post" action="/hot/sort" onsubmit="return check(this)">
        <?=
        GridView::widget([
            'dataProvider' => $dataProvider,
            //'filterModel' => $searchModel,
            'columns' => $columns
        ]); ?>
        <div class="form-group">
            <?= Html::submitButton('更新', ['class' => 'btn btn-success']) ?>
        </div>
    </form>

</div>
