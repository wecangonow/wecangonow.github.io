<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\data\ArrayDataProvider;

$this->title = 'Memu Charts';
?>
<style>
    .info{font-weight: bold}
</style>
<dir class="row">
    <div class="col-md-6">
        hello
    </div>
    <div class="col-md-6">
        hello
    </div>

</dir>
<div class="row">

<div class="col-md-12">

    <?php

    function filter($item) {
        $mailfilter = Yii::$app->request->getQueryParam('filteremail', '');
        if (strlen($mailfilter) > 0) {
            if (strpos($item['email'], $mailfilter) != false) {
                return true;
            } else {
                return false;
            }
        } else {
            return true;
        }
    }

    //$filteredresultData = array_filter($resultData, 'filter');
    //
    //
    //$mailfilter = Yii::$app->request->getQueryParam('filteremail', '');
    //$namefilter = Yii::$app->request->getQueryParam('filtername', '');
    //
    //$searchModel = ['id' => null, 'name' => $namefilter, 'email' => $mailfilter];

    //$dataProvider = new ArrayDataProvider([
    //    'key'=>'id',
    //    'allModels' => $filteredresultData,
    //    'sort' => [
    //        'attributes' => ['id', 'name', 'email'],
    //    ],
    //]);
    $dataProvider = new ArrayDataProvider([
        'allModels' => $resultData
    ]);

    echo GridView::widget([
        'dataProvider' => $dataProvider,
        'layout' => '{items}',
        'rowOptions' => function($data,$key,$index,$grid){
            if($data['dayofweek'] == "Thursday"){
                return ['class' => 'info'];
            }
        },

        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            'date',

            [
                'attribute' => 'dau',
                'label'     =>  '日活跃(DAU)',
                'value'     => 'dau',
                'contentOptions'   => function($data){
                    if($data['dau_max']) {
                        return ['style' => 'color:blue;'];
                    }
                    if($data['dau_min']) {
                        return ['style' => 'color:red;'];
                    }
                }
            ],
            [
                'attribute' => 'dru',
                'label'     =>  '日存量(DRU)',
                'value' => 'dru',
                'contentOptions'   => function($data){
                    if($data['dru_max']) {
                        return ['style' => 'color:blue;'];
                    }
                    if($data['dru_min']) {
                        return ['style' => 'color:red;'];
                    }
                }
            ],
            [
                'attribute' => 'dnu',
                'label'     =>  '日新增(DNU)',
                'value' => 'dnu',
                'contentOptions'   => function($data){
                    if($data['dnu_max']) {
                        return ['style' => 'color:blue;'];
                    }
                    if($data['dnu_min']) {
                        return ['style' => 'color:red;'];
                    }
                }
            ],
            [
                'attribute' => 'd2a/dnu',
                'label'     =>  '次日活跃率(D2A/DNU)',
                'value' => 'd2a/dnu',
                'contentOptions'   => function($data){
                    if($data['d2a/dnu_max']) {
                        return ['style' => 'color:blue;'];
                    }
                    if($data['d2a/dnu_min']) {
                        return ['style' => 'color:red;'];
                    }
                }
            ],
            [
                'attribute' => 'd2r/dnu',
                'label'     =>  '次日留存率(D2R/DNU)',
                'value' => 'd2r/dnu',
                'contentOptions'   => function($data){
                    if($data['d2r/dnu_max']) {
                        return ['style' => 'color:blue;'];
                    }
                    if($data['d2r/dnu_min']) {
                        return ['style' => 'color:red;'];
                    }
                }
            ],
            [
                'attribute' => 'nuu/dnu',
                'label'     =>  '次日活跃率(NUU/DNU)',
                'value' => 'nuu/dnu',
                'contentOptions'   => function($data){
                    if($data['nuu/dnu_max']) {
                        return ['style' => 'color:blue;'];
                    }
                    if($data['nuu/dnu_min']) {
                        return ['style' => 'color:red;'];
                    }
                }
            ],
            //[
            //    "attribute" => "email",
            //    'filter' => '<input class="form-control" name="filteremail" value="'. $searchModel['email'] .'" type="text">',
            //    'value' => 'email',
            //]

        ]
    ]);
    ?>

</div>

</div>

