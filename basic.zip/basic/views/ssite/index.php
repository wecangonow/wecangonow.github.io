<?php
/* @var $this yii\web\View */
$this->title = 'Upcleaner Backgroud';
?>
<div class="site-index">

    <div style="margin-top: 200px" class="jumbotron">
        <h1>UPCLEANER BACKGROUD</h1>

        <p class="lead">Welcome to Upcleaner Backgroud.</p>
    </div>
</div>
