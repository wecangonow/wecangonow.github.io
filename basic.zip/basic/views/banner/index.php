<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title                   = 'Banners';
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
    .sort{width: 50px;}
</style>
<div class="banner-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Banner', ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <script>
        function check(form) {

            var status = 0;
            $("input.sort").each(function () {
                if ($(this).val() == '' || $(this).val() <0) {
                    status = 1;
                    return false;
                }
            });
            if (status) {
                alert('排序不能有空,或者为负数');
                return false;
            }
        }
    </script>

    <form id="banner" action="/banner/sort" method="post" onsubmit="return check(this)">
        <?= GridView::widget([
            'dataProvider' => $dataProvider,
            'columns'      => [

                'id',
                [
                    'attribute' => 'sort',
                    'label'   => 'sort',
                    'content' => function ($model)
                    {

                        return "<input type='number' name='sort[" . $model->id . "]' class='sort' value='" . $model->sort . "'>";
                    }
                ],
                'name',
                'lang',
                'size',
                ['class' => 'yii\grid\ActionColumn'],
            ],
        ]); ?>
        <div class="form-group">
            <?= Html::submitButton('更新', ['class' => 'btn btn-success']) ?>
        </div>
    </form>

</div>
