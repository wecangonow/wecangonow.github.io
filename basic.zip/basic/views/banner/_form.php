<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use kartik\file\FileInput;



/* @var $this yii\web\View */
/* @var $model app\models\ARbase\Banner */
/* @var $form yii\widgets\ActiveForm */


?>

<style>

    .form-group{ clear: both;padding: 18px 0;}
    .form-group .control-label{float: left;width: 100px; text-align: right;padding: 8px 10px 0 0;}
    .form-group .form-control{float: left;width: 500px;margin:0 5px;}
    .form-group .help-block{float: left;width: 300px;}
</style>

<div class="banner-form">

    <?php $form = ActiveForm::begin(['options' => ['id'=>'banner','enctype' => 'multipart/form-data']]); ?>

    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>
    <?= $form->field($model, 'lang')->dropDownList(['pt' => '葡语','en' => '英语']) ?>

    <?= $form->field($model, 'size')->dropDownList(['850*250' => '850*250','425*250' => '425*250']) ?>

    <?= $form->field($model, 'sort')->textInput() ?>

    <?php if($model->isNewRecord!=1){ ?>
    <div class="form-group" style="padding-left: 100px"><img src="<?=$model->img ?>"> </div>
    <?php } ?>

    <?=$form->field($model, 'img')->fileInput()  ?>

    <?= $form->field($model, 'link')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
