<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\ARbase\App */
/* @var $form yii\widgets\ActiveForm */
?>
<style>

    .form-group{ clear: both;padding: 18px 0;}
    .form-group .control-label{float: left;width: 100px; text-align: right;padding: 8px 10px 0 0;}
    .form-group .form-control{float: left;width: 500px;margin:0 5px;}
    .form-group .help-block{float: left;width: 300px;}
</style>
<div class="app-form">

    <?php $form = ActiveForm::begin(['options' => ['id'=>'app','enctype' => 'multipart/form-data']]); ?>

    <?= $form->field($model, 'lang')->checkboxList($config['app_lang']); ?>

    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'pt_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'en_name')->textInput(['maxlength' => true]) ?>
    <?= $form->field($model, 'p_class')->dropDownList($topClassList, ['prompt' => '请选择父级分类']); ?>
    <?= $form->field($model, 'class')->dropDownList($classList, ['prompt' => '请选择子级分类']); ?>

    <?= $form->field($model, 'tag')->radioList([0=>'无',1=>'hot',2=>'new']) ?>

    <?= $form->field($model, 'level')->textInput() ?>
    <?= $form->field($model, 'size')->textInput() ?>
    <?= $form->field($model, 'is_recommend')->radioList([0=>'否',1=>'是']) ?>
    <?= $form->field($model, 'is_hot')->radioList([0=>'否',1=>'是']) ?>

    <?= $form->field($model, 'sort')->textInput() ?>

    <?php if($model->img){ ?>
        <div class="form-group" style="padding-left: 100px"><img src="<?=$model->img ?>"> </div>
    <?php } ?>

    <?=$form->field($model, 'img')->fileInput()  ?>

    <?= $form->field($model, 'link')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
<?php $this->registerJsFile("app/app-js", ['depends' => 'yii\bootstrap\BootstrapPluginAsset']); ?>
