<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel app\models\SCform\Appsearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Apps';
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
    .sort{width: 50px;}
    .app-search{ clear: both;height: 60px;}
    .app-search .form-group{width: auto;  float: left;padding:0 5px}
    .app-search .form-div{ padding: 25px 0 0 20px;}
    .grid-view{clear: both}
    .green{color: green}
    .red{color: red}
    .yel{color:yellowgreen }
</style>
<div class="app-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php  echo $this->render('_search', ['model' => $searchModel,
        'topClassList' => $topClassList,
        'config' => $config,
        'classList' => $classList,]); ?>

    <script>

        function check(form) {

            var status = 0;
            $("input.sort").each(function () {
                if ($(this).val() == '' || $(this).val() <0) {
                    status = 1;
                    return false;
                }
            });
            if (status) {
                alert('排序不能有空,或者为负数');
                return false;
            }
        }


    </script>
    <?php
    $columns = [
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'id',
            'label' => 'ID',
            'headerOptions' => ['style' => 'width: 6%'],
            'enableSorting' => true,
        ],
        [
            'attribute' => 'sort',
            'label'   => '排序',
            'content' => function ($model) {
                return "<input type='number' name='sort[" . $model['id'] . "]' class='sort' value='" . $model['sort'] . "'>";
            }
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'name',
            'headerOptions' => ['style' => 'width: 16%'],
            'enableSorting' => true,
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'p_class',
            'headerOptions' => ['style' => 'width: 10%'],
            'enableSorting' => true,
            'format' => "raw",
            'value' => function ($model) use ($topClassList) {
                return $topClassList[$model['p_class']];
            }
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'class',
            'headerOptions' => ['style' => 'width: 10%'],
            'enableSorting' => true,
            'format' => "raw",
            'value' => function ($model) use ($otherClassList) {
                return $otherClassList[$model['class']];
            }
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'tag',
            'headerOptions' => ['style' => 'width: 6%'],
            'enableSorting' => true,
            'format' => "raw",
            'value' => function ($model) {
                if($model['tag']==0)
                return '无';
                if($model['tag']==1)
                    return 'hot';
                if($model['tag']==2)
                    return 'new';

            }
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'lang',
            'headerOptions' => ['style' => 'width: 10%'],
            'enableSorting' => true,
            'format' => "raw",
            'value' => function ($model) use ($config) {
                $array = [];
                foreach(explode(',',$model['lang']) as $key=>$value){
                    array_push($array,$config['app_lang'][$value]);
                }
                return implode(',',$array);
            }
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'update_time',
            'headerOptions' => ['style' => 'width: 18%'],
            'enableSorting' => true,
            'format' => "raw",
            'value' => function ($model) {
                return date("Y-m-d H:i:s",$model['update_time']);
            }
        ]
    ];
    $action = [
        'class' => 'yii\grid\ActionColumn',
        'template' => '{update} {delete} ',
        'header' => '操作',
        'headerOptions' => ['style' => 'width: 10%'],
        'urlCreator' => function ($action, $model, $key, $index) {
            if ($action == 'status') {
            } else {
                return '/app/' . $action . "?id=" . $model["id"];
            }
        },
        'buttons' => [
            'delete' => function ($url, $model, $key) {
                $buttomclass = "glyphicon-trash";
                return Html::a('<span class="glyphicon ' . $buttomclass . '"></span>', $url, [
                    'title' => '删除',
                    'data-confirm' => Yii::t('yii', 'Are you sure you want to delete this item?'),
                    'data-method' => 'post',
                    'data-pjax' => '0'
                ]);

            }
        ],
    ];
    //    if (Yii::$app->user->can('pluginManage')) {
    $columns[] = $action;
    //    }
    ?>
    <form name="categoryform" id="categoryform" method="post" action="/app/sort" onsubmit="return check(this)">
        <?=
        GridView::widget([
            'dataProvider' => $dataProvider,
            //'filterModel' => $searchModel,
            'columns' => $columns
        ]); ?>
        <div class="form-group">
            <?= Html::submitButton('更新', ['class' => 'btn btn-success submit-sort']) ?>
        </div>
    </form>

</div>
