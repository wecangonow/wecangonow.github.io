<?php
/**
 * Created by PhpStorm.
 * User: chunyu
 * Date: 16/4/12
 * Time: 下午12:39
 */
?>
$(function(){
    $("#appsearch-p_class").change(function(){
        var p_class = $(this).val();
        ajaxSend(p_class);
    })
})
function ajaxSend(p_class){
    var data = "p_class="+p_class;
    $.ajax({
        url : '/app/get-class',
        type: 'POST',
        data : data,
        success : function(rs){
            $("#appsearch-class").html('');
            $("#appsearch-class").append(rs);
        },
        error:function(json){
            console.log('11');
        }
    })
}
