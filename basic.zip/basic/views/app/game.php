
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, target-densitydpi=device-dpi">
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css?t=<?=$time?>">
    <link rel="stylesheet" type="text/css" href="../css/mobile.css?t=<?=$time?>">
    <script type="text/javascript">
	    ;(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	    ga('create', 'UA-76562005-1', 'auto');
	    ga('send', 'pageview');

	    /*获取当前地址参数*/
	    function parseParamsFromUrl() {
	        var params = {};
	        var parts = window.location.search.substr(1).split('\x26');
	        for ( var i = 0; i < parts.length; i++) {
	            var keyValuePair = parts[i].split('=');
	            var key = decodeURIComponent(keyValuePair[0]);
	                params[key] = keyValuePair[1] ? decodeURIComponent(keyValuePair[1].replace(/\+/g, ' ')) : keyValuePair[1];
	            }
	        return params;
	    }
	    var urlParams = parseParamsFromUrl();
	</script>
</head>
<body>

    <div class="header fixed">
    	<div class="container">
    		<a href="index.html?t=<?=$time?>" class="pull-left logo">
	    		<img src="../images/logo.png">
				<span><?=Yii::t('app', 'sitename')?></span>
	    	</a>
	    	<ul>
	    		<li class="<?=$tpl==''?'active':''?>"><a href="index.html?t=<?=$time?>"><?=Yii::t('app', 'home')?></a></li>
	    		<li class="<?=$tpl=='game'?'active':''?>"><a href="game.html?t=<?=$time?>"><?=Yii::t('app', 'game')?></a></li>
	    		<li class="<?=$tpl=='soft'?'active':''?>"><a href="soft.html?t=<?=$time?>"><?=Yii::t('app', 'soft')?></a></li>
	    	</ul>
	    	<div class="pull-right">
	    		<div class="form-group has-feedback">
	    			<input type="text" class="form-control" >
	    			<span class="glyphicon glyphicon-search form-control-feedback"></span>
	    		</div>
	    	</div>
    	</div>
    </div>
    <div class="main game" style="margin-top: 50px;">
    	<div class="lt">
    		<ul class="nav nav-stacked">
    			<li class="<?=$classid==''?'active':''?>" data-cls="0"><a href="<?=$tpl?>.html"><?=Yii::t('app', 'all')?></a></li>
				<?php
				$class = json_decode($data)->class;



				foreach($class as $item){

				?>
    			<li class="<?=($item->id==$classid)?'active':''?>" data-cls="<?=$item->en_name?>"><a href="game<?=$item->id?>.html" ><?=$item->lname?></a></li>
				<?php } ?>
    		</ul>
    	</div>
    	<div class="rt">
    		<div class="top-menu">
    			<ul class="nav nav-pills tabs">
				  	<li role="presentation" class="active"><a href="#Complete" data-status="all"><?=Yii::t('app', 'all')?></a></li>
				  	<li role="presentation"><a href="#Recommendation" data-status="rec"><?=Yii::t('app', 'rec')?></a></li>
				  	<li role="presentation"><a href="#Popular" data-status="hot"><?=Yii::t('app', 'hot')?></a></li>
				</ul>
    		</div>
    		<div class="tab-content">
				<div class="tab-pane active" id="Complete">
					<div class="container">
	    				<?php 
	    				$arr = json_decode($data);
	    				foreach($arr->all[0] as $val){
		                    $tag='';
		                    if($val->tag==1){
		                        $tag='hot';
		                    }elseif($val->tag==2){
		                        $tag='new';
		                    }
	    				?>
	    				<div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
		                    <div class="item clearfix">
		                        <div class="pull-left item-logo">
		                            <a href="" class="download" data-url="<?=$val->link?>" data-enname="<?=$val->enname?>"><img class="img-responsive" src="<?=$val->img?>"></a>
		                            <span class="<?=$tag?>"><?=$tag ?></span>
		                        </div>
		                        <div class="text pull-left">
		                            <a href="" class="download" data-url="<?=$val->link?>" data-enname="<?=$val->enname?>"><h3 class="title"><?=$val->name?></h3></a>
		                            <p class="start" >
		                                <span style="width: <?=$val->level*16 ?>px;"></span>
		                            </p>
		                            <a href="" class="btn btn-download btn-sm download" data-url="<?=$val->link?>" data-enname="<?=$val->enname?>"><?=Yii::t('app', 'down')?></a>
		                        </div>
		                    </div>
		                </div>
		               	<?php } ?>
	    			</div>
				</div>
    			<div class="tab-pane" id="Recommendation">
    				<div class="container">
    					<?php 
	    				foreach($arr->rec[0] as $val){
		                    $tag='';
		                    if($val->tag==1){
		                        $tag='hot';
		                    }elseif($val->tag==2){
		                        $tag='new';
		                    }
	    				?>
	    				<div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
		                    <div class="item clearfix">
		                        <div class="pull-left item-logo">
		                            <a class="download" data-url="<?=$val->link?>" data-enname="<?=$val->enname?>"><img class="img-responsive" src="<?=$val->img?>"></a>
		                            <span class="<?=$tag?>"><?=$tag ?></span>
		                        </div>
		                        <div class="text pull-left">
		                            <a class="download" data-url="<?=$val->link?>" data-enname="<?=$val->enname?>"><h3 class="title"><?=$val->name?></h3></a>
		                            <p class="start" >
		                                <span style="width: <?=$val->level*16 ?>px;"></span>
		                            </p>
		                            <a class="btn btn-download btn-sm download" data-url="<?=$val->link?>" data-enname="<?=$val->enname?>"><?=Yii::t('app', 'down')?></a>
		                        </div>
		                    </div>
		                </div>
		               	<?php } ?>
    				</div>
    			</div>
    			<div class="tab-pane" id="Popular">
    				<div class="container">
    					<?php 
	    				foreach($arr->hot[0] as $val){
		                    $tag='';
		                    if($val->tag==1){
		                        $tag='hot';
		                    }elseif($val->tag==2){
		                        $tag='new';
		                    }
	    				?>
	    				<div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
		                    <div class="item clearfix">
		                        <div class="pull-left item-logo">
		                            <a class="download" data-url="<?=$val->link?>" data-enname="<?=$val->enname?>"><img class="img-responsive" src="<?=$val->img?>"></a>
		                            <span class="<?=$tag?>"><?=$tag ?></span>
		                        </div>
		                        <div class="text pull-left">
		                            <a class="download" data-url="<?=$val->link?>" data-enname="<?=$val->enname?>"><h3 class="title"><?=$val->name?></h3></a>
		                            <p class="start" >
		                                <span style="width: <?=$val->level*16 ?>px;"></span>
		                            </p>
		                            <a class="btn btn-download btn-sm download" data-url="<?=$val->link?>" data-enname="<?=$val->enname?>"><?=Yii::t('app', 'down')?></a>
		                        </div>
		                    </div>
		                </div>
		               	<?php } ?>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>

	<script type="text/javascript" src="../js/jquery-1.11.3.min.js?t=<?=$time?>"></script>
	<script type="text/javascript" src="../js/cookie.js?t=<?=$time?>"></script>
	<script type="text/javascript">
		function openGooglePlay(param) {
			window.jsObj.onOpenGooglePlay(param);
		}
		function Searchapk(param) {
			window.jsObj.onSearchGooglePlay(param);
		}


		var pageClass = '<?=$tpl?>';
		
		$(function() {
			$('.tabs  a').on('click',function(e) {
				e.preventDefault();
				e.stopPropagation();
				var target = $(this).attr('href');
				tabStatus = $(this).data('status');
				$(this).parent().addClass('active').siblings().removeClass('active');
				$(target).addClass('active').siblings('.tab-pane').removeClass('active');
			});

			if (urlParams['rec']) {
				$('.tabs li').eq(1).find('a').trigger('click');
	 		}
			var applist = util.cookie.get('applist');

			$('.main .btn-download').each(function() {
				var link = $(this).data('url') ? $(this).data('url') : $(this).data('link');
				
				if (applist && applist.indexOf(link)>0) {
					$(this).html('<?=Yii::t('app', 'open')?>');
				}
			});


			var tabStatus = 'all';
			var cacheIndex = 1;
			function template(data, text) {
				var tag='';
                if(data['tag']==1){
                    tag='hot';
                } else if(data['tag']==2) {
                    tag='new';
                }
				return '<div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">'
		                    +'<div class="item clearfix">'
		                        +'<div class="pull-left item-logo">'
		                            +'<a class="download" data-url="'+data['link']+'" data-enname="'+data['enname']+'"><img class="img-responsive" src="'+data['img']+'"></a>'
		                            +'<span class="'+tag+'">'+tag+'</span>'
		                        +'</div>'
		                        +'<div class="text pull-left">'
		                            +'<a class="download" data-url="'+data['link']+'" data-enname="'+data['enname']+'"><h3 class="title">'+data['name']+'</h3></a>'
		                            +'<p class="start" >'
		                                +'<span style="width: '+data['level']*16+'px;"></span>'
		                            +'</p>'
		                            +'<a class="btn btn-download btn-sm download" data-url="'+data['link']+'" data-enname="'+data['enname']+'">'+text+'</a>'
		                        +'</div>'
		                    +'</div>'
		                +'</div>';
			}

			
			var apps = <?=$data?>;
			console.log(apps);
			$(window).on('scroll',function() {
				if ($(window).scrollTop()>1*cacheIndex) {
					if (apps[tabStatus][cacheIndex]&&apps[tabStatus][cacheIndex].length>0) {
						var curData = apps[tabStatus][cacheIndex];
						var tpl ='';
						curData.forEach(function(v) {
							if (applist.indexOf(v['link'])>0) {
								tpl += template(v,'<?=Yii::t('app', 'open')?>');
							} else {
								tpl += template(v,'<?=Yii::t('app', 'down')?>');
							}
						});
						switch(tabStatus) {
							case 'all':
								$('#Complete .container').append(tpl);
								break;
							case 'rec':
								$('#Recommendation .container').append(tpl);
								break;
							case 'hot':
								$('#Popular .container').append(tpl);
								break;
						}
						cacheIndex++;
					}
				}
			});


			var cls = $('.main .lt li.active').data('cls');
			if (pageClass=='game') {
				var data={"model_name":"pageview","event_name":"pageview","name":'game'}
				$.ajax({
					url:'http://api.simcake.com/api/front-data',
					data:data,
				})
				if (cls==0) {
					$('#Complete').on('click', '.download', function(e) {
						e.preventDefault();
						var url = $(this).data('url');
						var enname = $(this).data('enname');
						var data={"model_name":"game_app","event_name":"app_click","name":enname}
						$.ajax({
							url:'http://api.simcake.com/api/front-data',
							data:data,
						})
						ga('send','event','game_app','app_click',enname);
						window.jsObj.JavacallOpenApk(url);
					});
					$('#Recommendation').on('click', '.download',function(e) {
						e.preventDefault();
						var url = $(this).data('url');
						var enname = $(this).data('enname');
						var data={"model_name":"reco_game","event_name":"app_click","name":enname}
						$.ajax({
							url:'http://api.simcake.com/api/front-data',
							data:data,
						})
						ga('send','event','reco_game','app_click',enname);
						window.jsObj.JavacallOpenApk(url);
					});
					$('#Popular').on('click', '.download', function(e) {
						e.preventDefault();
						var url = $(this).data('url');
						var enname = $(this).data('enname');
						var data={"model_name":"hot_game","event_name":"app_click","name":enname}
						$.ajax({
							url:'http://api.simcake.com/api/front-data',
							data:data,
						})
						ga('send','event','hot_game','app_click',enname);
						window.jsObj.JavacallOpenApk(url);
					});
				} else {
					$('#Complete').on('click', '.download', function(e) {
						e.preventDefault();
						var url = $(this).data('url');
						var enname = $(this).data('enname');
						var data={"model_name":'game_app_'+cls,"event_name":"app_click","name":enname}
						$.ajax({
							url:'http://api.simcake.com/api/front-data',
							data:data,
						})
						ga('send','event','game_app_'+cls,'app_click',enname);
						window.jsObj.JavacallOpenApk(url);
					});
					$('#Recommendation').on('click', '.download',function(e) {
						e.preventDefault();
						var url = $(this).data('url');
						var enname = $(this).data('enname');
						var data={"model_name":'reco_game_'+cls,"event_name":"app_click","name":enname}
						$.ajax({
							url:'http://api.simcake.com/api/front-data',
							data:data,
						})
						ga('send','event','reco_game_'+cls,'app_click',enname);
						window.jsObj.JavacallOpenApk(url);
					});
					$('#Popular').on('click', '.download', function(e) {
						e.preventDefault();
						var url = $(this).data('url');
						var enname = $(this).data('enname');
						var data={"model_name":'hot_game_'+cls,"event_name":"app_click","name":enname}
						$.ajax({
							url:'http://api.simcake.com/api/front-data',
							data:data,
						})
						ga('send','event','hot_game_'+cls,'app_click',enname);
						window.jsObj.JavacallOpenApk(url);
					});
				}
				
			} else {
				var data={"model_name":"pageview","event_name":"pageview","name":'app'}
				$.ajax({
					url:'http://api.simcake.com/api/front-data',
					data:data,
				})
				if (cls==0) {
					$('#Complete').on('click', '.download', function(e) {
						e.preventDefault();
						var url = $(this).data('url');
						var enname = $(this).data('enname');
						var data={"model_name":"apps_app","event_name":"app_click","name":enname}
						$.ajax({
							url:'http://api.simcake.com/api/front-data',
							data:data,
						})
						ga('send','event','apps_app','app_click',enname);
						window.jsObj.JavacallOpenApk(url);
					});
					$('#Recommendation').on('click', '.download', function(e) {
						e.preventDefault();
						var url = $(this).data('url');
						var enname = $(this).data('enname');
						var data={"model_name":"reco_app","event_name":"app_click","name":enname}
						$.ajax({
							url:'http://api.simcake.com/api/front-data',
							data:data,
						})
						ga('send','event','reco_app','app_click',enname);
						window.jsObj.JavacallOpenApk(url);
					});
					$('#Popular').on('click', '.download', function(e) {
						e.preventDefault();
						var url = $(this).data('url');
						var enname = $(this).data('enname');
						var data={"model_name":"hot_app","event_name":"app_click","name":enname}
						$.ajax({
							url:'http://api.simcake.com/api/front-data',
							data:data,
						})
						ga('send','event','hot_app','app_click',enname);
						window.jsObj.JavacallOpenApk(url);
					});
				} else {
					$('#Complete').on('click', '.download', function(e) {
						e.preventDefault();
						var url = $(this).data('url');
						var enname = $(this).data('enname');
						var data={"model_name":'apps_app_'+cls,"event_name":"app_click","name":enname}
						$.ajax({
							url:'http://api.simcake.com/api/front-data',
							data:data,
						})
						ga('send','event','apps_app_'+cls,'app_click',enname);
						window.jsObj.JavacallOpenApk(url);
					});
					$('#Recommendation').on('click', '.download', function(e) {
						e.preventDefault();
						var url = $(this).data('url');
						var enname = $(this).data('enname');
						var data={"model_name":'reco_app_'+cls,"event_name":"app_click","name":enname}
						$.ajax({
							url:'http://api.simcake.com/api/front-data',
							data:data,
						})
						ga('send','event','reco_app_'+cls,'app_click',enname);
						window.jsObj.JavacallOpenApk(url);
					});
					$('#Popular').on('click', '.download', function(e) {
						e.preventDefault();
						var url = $(this).data('url');
						var enname = $(this).data('enname');
						var data={"model_name":'hot_app_'+cls,"event_name":"app_click","name":enname}
						$.ajax({
							url:'http://api.simcake.com/api/front-data',
							data:data,
						})
						ga('send','event','hot_app_'+cls,'app_click',enname);
						window.jsObj.JavacallOpenApk(url);
					});
				}
			}

			$('.header .form-control-feedback').on('click', function () {
				var value = $(this).parents('.pull-right').find('input').val();
				var data={"model_name":"search_bar","keywords":value}
				$.ajax({
					url:'http://api.simcake.com/api/front-data',
					data:data,
				})
				ga('send','event','search_bar', value);
				window.jsObj.JavaSearchApk(value);
				return false;
			});
			$('.header input').on('keyup', function(e) {
				if (e.which==13) {
					var value = $(this).val();
					var data={"model_name":"search_bar","keywords":value}
					$.ajax({
						url:'http://api.simcake.com/api/front-data',
						data:data,
					})
					ga('send','event','search_bar', value);
					window.jsObj.JavaSearchApk(value);
				}
				return false;
			});

		});
		

	</script>
</body>
</html>