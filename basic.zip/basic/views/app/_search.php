<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\SCform\Appsearch */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="app-search">

    <?php $form = ActiveForm::begin([
        'action' => ['index'],
        'method' => 'get',
    ]); ?>


    <?= $form->field($model, 'name') ?>
    <?= $form->field($model, 'p_class')->dropDownList($topClassList,['prompt' => '请选择父级分类']) ?>
    <?= $form->field($model, 'class')->dropDownList($classList,['prompt' => '请选择子级分类']) ?>
    <?= $form->field($model, 'lang')->dropDownList($config['app_lang'],['prompt' => '请选择语言']) ?>
    <?= $form->field($model, 'tag')->dropDownList([0=>'无',1=>'hot',2=>'new'],['prompt' => '请选择标签']) ?>

    <div class="form-div">
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Create App', ['create'], ['class' => 'btn btn-success']) ?>
        <?= Html::a('生成app页面', ['createhtml'], ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>

<?php $this->registerJsFile("app/search-js", ['depends' => 'yii\bootstrap\BootstrapPluginAsset']); ?>