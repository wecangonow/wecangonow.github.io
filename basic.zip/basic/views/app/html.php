<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, target-densitydpi=device-dpi">
	<title></title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css?t=<?=$time?>">
    <link rel="stylesheet" type="text/css" href="../css/mobile.css?t=<?=$time?>">
	<script type="text/javascript">
	    ;(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
	    (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
	    m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
	    })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

	    ga('create', 'UA-76562005-1', 'auto');

	    ga('send', 'pageview');
	</script>
</head>
<body>

    <div class="header fixed">
    	<div class="container">
    		<a href="index.html?t=<?=$time?>" class="pull-left logo">
	    		<img src="../images/logo.png">
	    		<span><?=Yii::t('app', 'sitename')?></span>
	    	</a>
	    	<ul>
	    		<li class="active"><a href="index.html?t=<?=$time?>"><?=Yii::t('app', 'home')?></a></li>
	    		<li><a href="game.html?t=<?=$time?>"><?=Yii::t('app', 'game')?></a></a></li>
	    		<li><a href="soft.html?t=<?=$time?>"><?=Yii::t('app', 'soft')?></a></a></li>
	    	</ul>
	    	<div class="pull-right">
	    		<div class="form-group has-feedback">
	    			<input type="text" class="form-control" >
	    			<span class="glyphicon glyphicon-search form-control-feedback"></span>
	    		</div>
	    	</div>
    	</div>
    </div>
    <div class="banner" style="margin-top: 50px;">
    	<div class="container">
    		<div class="col-xs-8">
    			<div id='slider-box' style="width: 100%" class='slider-container'>
					<div class='slider-wrapper'>

					</div>
				</div>
    		</div>
    		<div class="col-xs-4">
    			<div class="r">
    			</div>
    		</div>
    	</div>
    </div>
    <div class="main">
    	<div class="container game-container">
            <div class="col-ls-9 col-lt-8 col-lm-6">
                <div class="ltop clearfix" style="padding-bottom: 4px;">
                    <span class="pull-left"><?=Yii::t('app', 'rec_game')?></span>
                    <a href="game.html?t=<?=$time?>&rec=1" class="pull-right more">+<?=Yii::t('app', 'more')?></a>
                </div>
                <?php
                foreach($game_rec as $val){

                    $tag='';
                    if($val['tag']==1){
                        $tag='hot';
                    }elseif($val['tag']==2){
                        $tag='new';
                    }
                ?>
                <div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
                    <div class="item clearfix">
                        <div class="pull-left item-logo">
                            <a href="" class="download" data-url="<?=$val['link']?>" data-enname="<?=$val['enname']?>"><img class="img-responsive" src="<?=$val['img']?>"></a>
                            <span class="<?=$tag?>"><?=$tag ?></span>
                        </div>
                        <div class="text pull-left">
                            <a href="" class="download" data-url="<?=$val['link']?>" data-enname="<?=$val['enname']?>"><h3 class="title"><?=$val['name']?></h3></a>
                            <p class="start" >
                                <span style="width: <?=$val['level']*16 ?>px;"></span>
                            </p>
                            <a href="" class="btn btn-download btn-sm download" data-url="<?=$val['link']?>" data-enname="<?=$val['enname']?>"><?=Yii::t('app', 'down')?></a>
                        </div>
                    </div>
                </div>
               <?php } ?>
            </div>
			<div class="col-ls-3">
				<div class="ltop clearfix">
					<span class="pull-left"><?=Yii::t('app', 'hot_game')?></span>
				</div>
				<ul class="list-group game-rank">
					<?php
					foreach($game_hot as $key => $val){

					?>
					<li class="list-group-item">
						<span class="<?php if ($key<3) echo 'active'; else echo '';?> badge"><?=$key+1?></span>
						<a class='link-download' data-link='<?=$val['link']?>' data-enname="<?=$val['enname']?>"><img src="<?=$val['img']?>"></a>
						<a class='link-download' data-link='<?=$val['link']?>' data-enname="<?=$val['enname']?>"><span class="item-title"><?=$val['name']?></span></a>
						<a class='btn btn-download btn-xs pull-right link-download' data-link='<?=$val['link']?>' data-enname="<?=$val['enname']?>"><?=Yii::t('app', 'down')?></a>
					</li>
					<?php } ?>
				</ul>
			</div>
    	</div>
		<div class="container soft-container">
			<div class="col-ls-9 col-lt-8 col-lm-6">
				<div class="ltop clearfix" style="padding-bottom: 4px;">
					<span class="pull-left"><?=Yii::t('app', 'rec_soft')?></span>
					<a href="soft.html?t=<?=$time?>&rec=1" class="pull-right more">+<?=Yii::t('app', 'more')?></a>
				</div>
				<?php
				foreach($soft_rec as $val){

					$tag='';
					if($val['tag']==1){
						$tag='hot';
					}elseif($val['tag']==2){
						$tag='new';
					}
					?>
					<div class="col-md-4 col-lg-4 col-sm-6 col-xs-12">
						<div class="item clearfix">
							<div class="pull-left item-logo">
								<a href="" class="download" data-url="<?=$val['link']?>" data-enname="<?=$val['enname']?>"><img class="img-responsive" src="<?=$val['img']?>"></a>
								<span class="<?=$tag?>"><?=$tag ?></span>
							</div>
							<div class="text pull-left">
								<a href="" class="download" data-url="<?=$val['link']?>" data-enname="<?=$val['enname']?>"><h3 class="title"><?=$val['name']?></h3></a>
								<p class="start" >
									<span style="width: <?=$val['level']*16 ?>px;"></span>
								</p>
								<a href="" class="btn btn-download btn-sm download" data-url="<?=$val['link']?>" data-enname="<?=$val['enname']?>"><?=Yii::t('app', 'down')?></a>
							</div>
						</div>
					</div>
				<?php } ?>
			</div>
			<div class="col-ls-3">
				<div class="ltop clearfix">
					<span class="pull-left"><?=Yii::t('app', 'hot_soft')?></span>
				</div>
				<ul class="list-group app-rank">
					<?php
					foreach($soft_hot as $key => $val){
						?>
						<li class="list-group-item">
							<span class="<?php if ($key<3) echo 'active'; else echo '';?> badge"><?=$key+1?></span>
							<a class="link-download" data-link="<?=$val['link']?>" data-enname="<?=$val['enname']?>"><img src="<?=$val['img']?>"></a>
							<a class="link-download" data-link="<?=$val['link']?>" data-enname="<?=$val['enname']?>"><span class="item-title"><?=$val['name']?></span></a>
							<a class='btn btn-download btn-xs pull-right link-download' data-link='<?=$val['link']?>' data-enname="<?=$val['enname']?>"><?=Yii::t('app', 'down')?></a>
						</li>
					<?php } ?>
				</ul>
			</div>
		</div>
    </div>

	<script type="text/javascript" src="../js/jquery-1.11.3.min.js?t=<?=$time?>"></script>
	<script type="text/javascript" src="../js/slider.js?t=<?=$time?>"></script>
	<script type="text/javascript" src="../js/cookie.js?t=<?=$time?>"></script>
	<script type="text/javascript">

		function onload(uuid,mac,adcid,applist){
			util.cookie.set('uuid',uuid);
			util.cookie.set('mac',mac);
			util.cookie.set('adcid',adcid);
			util.cookie.set('applist',JSON.stringify(applist));
		}

		function openGooglePlay(param) {
			window.jsObj.onOpenGooglePlay(param);
		}
		function Searchapk(param) {
			window.jsObj.onSearchGooglePlay(param);
		}

		//要加载的图片地址
		var imgs=[{link:"<?=$banners_right['link']?>",src:"<?=$banners_right['img']?>",name: "<?=$banners_right['name']?>"}];
			<?php
			foreach($banners as $item){
           ?>
			imgs.push({link:"<?=$item['link']?>",src:"<?=$item['img']?>", name: "<?=$item['name']?>"});

		<?php } ?>
		var preload=function(imgs,callback){
			var imgs=(typeof imgs!="object")? [imgs] : imgs;
			var img = [];
			for(var i=0,len=imgs.length;i<len;i++){
				img[i] = new Image();
				img[i].src = imgs[i].src;
			}

			img[len-1].onload = callback?callback.apply(img):null;
		}

		$(function() {

			var applist = util.cookie.get('applist');

			$('.main .btn-download').each(function() {
				var link = $(this).data('url') ? $(this).data('url') : $(this).data('link');
				
				if (applist && applist.indexOf(link)>0) {
					$(this).html('<?=Yii::t('app', 'open')?>');
				}
			});

			var resize = function () {
				if (parseInt($('#slider-box').height(),10)>80) {
					$('.banner .col-xs-4').css({
						height: $('#slider-box').height()
					}).find('img').css({
						height: $('#slider-box').height()
					});
				} else {
					setTimeout(function () {
						resize();
					},100);
				}
			};

			var bW = parseInt($('#slider-box').width(),10);
			$('#slider-box').parents('.container').css({
				height: bW*250/850 + 'px',
				border: '1px solid #eee'
			});


			$(window).load(function(){
				preload(imgs,function(){
					var _self = this;
					_self.forEach(function(item,i){
						if (i==0) {
							$('.banner .r').append('<a class="banner-download" data-href="'+imgs[i].link+'" data-name="'+imgs[i].name+'" href="javascript:void(0);"><img src="' + item.src + '">');
						} else {
							$('#slider-box').find('.slider-wrapper').append('<div><a class="banner-download" data-href="'+imgs[i].link+'" data-name="'+imgs[i].name+'" href="javascript:void(0);"><img src="'+item.src+'"></a></div>')
						}
					});
					$('#slider-box').slider({
						auto: 3000,
						button: false
					});
					$('#slider-box').parents('.container').removeAttr('style');
					resize();
				});
			});

			$(window).resize(function () {
				setTimeout(function () {
					resize();
				},0)
			})
			//pageview 上报
			var data={"model_name":"pageview","event_name":"pageview","name":'Home'}
			$.ajax({
				url:'http://api.simcake.com/api/front-data',
				data:data,
			})

			//首页游戏推荐
			$('.main .game-container .download').on('click',function(e) {
				e.preventDefault();
				var url = $(this).data('url');
				var enname = $(this).data('enname');
				var data={"model_name":"reco_game","event_name":"app_click","name":enname}
				$.ajax({
					url:'http://api.simcake.com/api/front-data',
					data:data,
				})
				ga('send','event','reco_game','app_click',enname);
				window.jsObj.JavacallOpenApk(url);
			});
			//首页游戏推荐点击更多
			$('.main .game-container .more').on('click',function() {
				var data={"model_name":"reco_game","event_name":"more_click","name":"more"}
				$.ajax({
					url:'http://api.simcake.com/api/front-data',
					data:data,
				})
				ga('send','event','reco_game','more_click','more');
			});

			//首页应用推荐
			$('.main .soft-container .download').on('click',function(e) {
				e.preventDefault();
				var url = $(this).data('url');
				var enname = $(this).data('enname');
				var data={"model_name":"reco_app","event_name":"app_click","name":enname}
				$.ajax({
					url:'http://api.simcake.com/api/front-data',
					data:data,
				})
				ga('send','event','reco_app','app_click',enname);
				window.jsObj.JavacallOpenApk(url);
			});
			//首页应用更多
			$('.main .soft-container .more').on('click',function() {
				var data={"model_name":"reco_app","event_name":"more_click","name":"more"}
				$.ajax({
					url:'http://api.simcake.com/api/front-data',
					data:data,
				})
				ga('send','event','reco_app','more_click','more');
			});


			//首页热门游戏排行
			$('.main .game-rank .link-download').on('click',function(e) {
				e.preventDefault();
				var url = $(this).data('link');
				var enname = $(this).data('enname');
				var data={"model_name":"game_rank","event_name":"app_click","name":enname}
				$.ajax({
					url:'http://api.simcake.com/api/front-data',
					data:data,
				})
				ga('send','event','game_rank','app_click',enname);
				window.jsObj.JavacallOpenApk(url);
			});
			//首页热门应用排行
			$('.main .app-rank .link-download').on('click',function(e) {
				e.preventDefault();
				var url = $(this).data('link');
				var enname = $(this).data('enname');
				var data={"model_name":"app_rank","event_name":"app_click","name":enname}
				$.ajax({
					url:'http://api.simcake.com/api/front-data',
					data:data,
				})
				ga('send','event','app_rank','app_click',enname);
				window.jsObj.JavacallOpenApk(url);
			});
			//搜索框
			$('.header .form-control-feedback').on('click', function () {
				var value = $(this).parents('.pull-right').find('input').val();

				var data={"model_name":"search_bar","keywords":value}
				$.ajax({
					url:'http://api.simcake.com/api/front-data',
					data:data,
				})
				ga('send','event','search_bar', value);
				window.jsObj.JavaSearchApk(value);
			});
			//搜索框
			$('.header input').on('keyup', function(e) {
				if (e.which==13) {
					var value = $(this).val();
					var data={"model_name":"search_bar","keywords":value}
					$.ajax({
						url:'http://api.simcake.com/api/front-data',
						data:data,
					})
					ga('send','event','search_bar', value);
					window.jsObj.JavaSearchApk(value);
				}
				return false;
			});

			//首页banner
			$('.banner').on('click','.banner-download',function(e) {
				e.preventDefault();
				var url = $(this).data('href');
				var name = $(this).data('name');
				var data={"model_name":"home_banner","event_name":"app_click","name":name}
				$.ajax({
					url:'http://api.simcake.com/api/front-data',
					data:data,
				})
				ga('send','event','home_banner','app_click',name);
				window.jsObj.JavacallOpenApk(url);
			});
		});
	</script>
</body>
</html>