<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\ActiveForm;
use kartik\alert\Alert;
/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title                   = 'Confs';
$this->params['breadcrumbs'][] = $this->title;

if($_SESSION['confalert']){
    echo Alert::widget([
        'options' => [
            'class' => 'alert-success',
        ],
        'body' => '修改成功...',
        'delay' => 1000,
    ]);
    unset($_SESSION['confalert']);
}

?>
<style>
    .dl {
        border: solid #cdcdcd 1px;
        border-radius: 5px;
        padding: 10px 10px  40px ;font-weight: 100;
    }
    .form-group{ clear: both;padding: 8px 0;}
    .form-group .control-label{float: left;width: 120px; text-align: right;padding: 8px 10px 0 0;font-weight: 100;}
    .form-group .form-control{float: left;width: 500px;margin:0 5px;}
    .form-group .help-block{float: left;padding-left: 130px;}
</style>
<div class="conf-index">
    <?php $form = ActiveForm::begin(); ?>
    <dl class="dl">
        <dt>强制更新</dt>
        <dd> <?= $form->field($model, 'up_lock')->radioList([0=>'关',1=>'开'])->label('开关:') ?> </dd>
        <dd> <?= $form->field($model, 'up_ver')->label('更新版本:') ?> </dd>
        <dd> <?= $form->field($model, 'up_dlurl')->label('下载地址：') ?> </dd>
        <dd> <?= $form->field($model, 'up_md5')->label('MD5：') ?> </dd>
    </dl>
    <dl class="dl">
        <dt>推荐更新</dt>
        <dd> <?= $form->field($model, 'reup_lock')->radioList([0=>'关',1=>'开'])->label('开关:') ?> </dd>
        <dd> <?= $form->field($model, 'reup_ver')->label('更新版本:') ?> </dd>
        <dd> <?= $form->field($model, 'reup_dlurl')->label('下载地址：') ?> </dd>
        <dd> <?= $form->field($model, 'reup_md5')->label('MD5：') ?> </dd>
    </dl>

    <dl class="dl">
        <dt>最新版本(包含模拟器)</dt>
        <dd> <?= $form->field($model, 'new_ver')->label('最新版本:') ?> </dd>
        <dd> <?= $form->field($model, 'new_dlurl')->label('下载地址:') ?> </dd>
    </dl>

    <dl class="dl">
        <dt>最新版本(不包含模拟器)</dt>
        <dd> <?= $form->field($model, 'new_uninclude_ver')->label('最新版本:') ?> </dd>
        <dd> <?= $form->field($model, 'new_uninclude_dlurl')->label('下载地址:') ?> </dd>
    </dl>

    <?= Html::submitButton('Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    <?php ActiveForm::end(); ?>

    <p>&nbsp;</p>
</div>
