<?php

use yii\helpers\Html;
use yii\grid\GridView;
use kartik\alert\Alert;
use yii\web\Session;

/* @var $this yii\web\View */
/* @var $searchModel app\models\VLform\Grey */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = "Class";
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
    .grid-view {
        max-width: 100%;
    }

    .summary {
        display: inline-block;
    }

    td a {
        padding: 5px 5px;
    }

    .form-inline {
        max-width: 100%;
        margin-bottom: 10px;
    }

    .search-group {
        float: right;
    }
</style>
<div class=up-category-index">
    <h1><?= Html::encode($this->title) ?></h1>

    <?php if (Yii::$app->getSession()->hasFlash('success')) {
        echo Alert::widget([
            'options' => [
                'class' => 'alert-success', //这里是提示框的class
            ],
            'body' => Yii::$app->getSession()->getFlash('success'), //消息体
            'delay' => 3000,
        ]);
    }
    if (Yii::$app->getSession()->hasFlash('error')) {
        echo Alert::widget([
            'options' => [
                'class' => 'alert-danger',
            ],
            'body' => Yii::$app->getSession()->getFlash('error'),
            'delay' => 3000,
        ]);
    } ?>

    <script>

        function check(form) {

            var status = 0;
            $("input.sort").each(function () {
                if ($(this).val() == '' || $(this).val() <0) {
                    status = 1;
                    return false;
                }
            });
            if (status) {
                alert('排序不能有空,或者为负数');
                return false;
            }
        }


    </script>
    <?php echo $this->render('_search', ['model' => $searchModel,
        'topClassList' => $topClassList,
        'config' => $config,]); ?>

    <?php
    $columns = [
        [
            'class' => 'yii\grid\CheckboxColumn',
            'checkboxOptions' => function ($model) {
                return ['value' => $model['id'], 'class' => 'checkbox'];
            }
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'id',
            'label' => 'ID',
            'headerOptions' => ['style' => 'width: 8%'],
            'enableSorting' => true,
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'name',
            'label' => 'NAME',
            'headerOptions' => ['style' => 'width: 15%'],
            'enableSorting' => true,
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'type',
            'label' => 'TYPE',
            'headerOptions' => ['style' => 'width: 20%'],
            'enableSorting' => true,
            'format' => "raw",
            'value' => function ($model) use ($topClassList) {
                return $topClassList[$model['type']];
            }
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'update_time',
            'label' => 'UPDATE TIME',
            'headerOptions' => ['style' => 'width: 20%'],
            'enableSorting' => true,
            'format' => "raw",
            'value' => function ($model) {
                return date("Y-m-d H:i:s",$model['update_time']);
            }
        ],
        [
            'class' => 'yii\grid\DataColumn',
            'attribute' => 'lang',
            'label' => 'LANG',
            'headerOptions' => ['style' => 'width: 20%'],
            'enableSorting' => true,
            'format' => "raw",
            'value' => function ($model) use ($config) {
                $array = [];
                foreach(explode(',',$model['lang']) as $key=>$value){
                        array_push($array,$config['lang'][$value]);
                }
                return implode(',',$array);
            }
        ],
        [
            'attribute' => 'sort',
            'label' => 'SORT',
            'content' => function ($model) {
                return "<input type='number' name='sort[" . $model['id'] . "]' class='sort' value='" . $model['sort'] . "'>";
            }
        ],
    ];
    $action = [
        'class' => 'yii\grid\ActionColumn',
        'template' => '{update} {delete} ',
        'header' => '操作',
        'headerOptions' => ['style' => 'width: 13%'],
        'urlCreator' => function ($action, $model, $key, $index) {
            if ($action == 'status') {
            } else {
                return '/appclass/' . $action . "?id=" . $model["id"];
            }
        },
        'buttons' => [
            'delete' => function ($url, $model, $key) {
                $buttomclass = "glyphicon-trash";
                return Html::a('<span class="glyphicon ' . $buttomclass . '"></span>', $url, [
                    'title' => '删除',
                    'data-confirm' => Yii::t('yii', 'Are you sure you want to delete this item?'),
                    'data-method' => 'post',
                    'data-pjax' => '0'
                ]);

            }
        ],
    ];
    //    if (Yii::$app->user->can('pluginManage')) {
    $columns[] = $action;
    //    }
    ?>
    <form name="categoryform" id="categoryform" method="post" action="/appclass/sort" onsubmit="return check(this)">
        <?=
        GridView::widget([
            'dataProvider' => $dataProvider,
            //'filterModel' => $searchModel,
            'columns' => $columns
        ]); ?>
        <div class="form-group">
            <?= Html::submitButton('更新', ['class' => 'btn btn-success']) ?>
        </div>
    </form>
</div>
