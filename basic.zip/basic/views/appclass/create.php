<?php

use yii\helpers\Html;


/* @var $this yii\web\View */
/* @var $model app\models\ARbase\PCategory */

$this->title = 'Create Class';
$this->params['breadcrumbs'][] = $this->title;
?>
<style>
    div.required .control-label:after {
        content: "*";
        color: red;
    }
</style>
<div class="nb-aop-orderlist-create">

    <h1><?= Html::encode($this->title) ?></h1>
    <?= Yii::trace($model); ?>
    <?=
    $this->render('_form', [
        'model' => $model,
        'config'=>$config,
        'topClassList'=>$topClassList
        //'alert'=>$alert,

    ]) ?>

</div>
