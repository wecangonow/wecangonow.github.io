<?php
/**
 * Created by PhpStorm.
 * User: chunyu
 * Date: 16/4/12
 * Time: 下午12:39
 */
?>
$(function(){
    $("#appclass-lang input").click(function(i){
        if($(this).val()==1){
            if($(this).is(":checked")){
                $("#appclass-lang input").each(function(){
                    $(this).prop("checked",'true');
                })
            }else{
                $("#appclass-lang input").each(function(){
                    $(this).removeAttr("checked");
                })
            }
        }else{
            if($(this).prop('checked')==false){
                $("#appclass-lang input").each(function(i){
                    if(i==0){
                        $(this).removeAttr("checked");
                    }
                })
            }
        }
    })

$("#appclassform-lang input").click(function(i){
    if($(this).val()==1){
        if($(this).is(":checked")){
            $("#appclassform-lang input").each(function(){
                $(this).prop("checked",'true');
            })
        }else{
            $("#appclassform-lang input").each(function(){
                $(this).removeAttr("checked");
            })
        }
    }else{
        if($(this).prop('checked')==false){
            $("#appclassform-lang input").each(function(i){
                if(i==0){
                    $(this).removeAttr("checked");
                }
            })
        }
    }
})

})
