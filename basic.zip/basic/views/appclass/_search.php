<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\SCform\AdListSearch */
/* @var $form yii\widgets\ActiveForm */
?>

<style>
    .form-inline .form-group {
        vertical-align: baseline;
    }
    .form-control{
        padding:0px;
    }
    #padlistsearch-name{
        width:190px;
        padding:6px 12px;
    }
    #padlistsearch-putin{
        width:150px;
    }
</style>
<div class="plugin-management-search">
    <div class="form-inline">
        <?php $form = ActiveForm::begin([
            'action' => ['index'],
            'method' => 'get'
        ]); ?>

        <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

        <?= $form->field($model, 'type')->dropDownList($topClassList, ['prompt' => '全部']); ?>
        <?= $form->field($model, 'lang')->dropDownList($config['lang']); ?>
        <?= Html::submitButton('Search', ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Create Class', ['create'], ['class' => 'btn btn-success']) ?>
        <?php ActiveForm::end(); ?>
    </div>

</div>