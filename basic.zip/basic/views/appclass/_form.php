<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model app\models\ARbase\App */
/* @var $form yii\widgets\ActiveForm */
?>
<style>

    .form-group {
        clear: both;
        padding: 18px 0;
    }

    .form-group .control-label {
        float: left;
        width: 100px;
        text-align: right;
        padding: 8px 10px 0 0;
    }

    .form-group .form-control {
        float: left;
        width: 500px;
        margin: 0 5px;
    }

    .form-group .help-block {
        float: left;
        width: 300px;
    }

    #appclass-lang {
        width: 510px;
        float: left;
    }
</style>
<div class="app-form">

    <?php $form = ActiveForm::begin(['options' => ['id'=>'app','enctype' => 'multipart/form-data']]); ?>

    <?= $form->field($model, 'lang', ['enableAjaxValidation' => true])->checkboxList($config['lang']); ?>

    <?= $form->field($model, 'name', ['enableAjaxValidation' => true])->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'pt_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'en_name')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'type')->dropDownList($topClassList); ?>

    <?= $form->field($model, 'sort', ['enableAjaxValidation' => true])->textInput() ?>

    <?= $form->field($model, 'link')->textInput() ?>
    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
<?php $this->registerJsFile("appclass/appclass-js", ['depends' => 'yii\bootstrap\BootstrapPluginAsset']); ?>
