<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\ARbase\AppClass */

$this->title = 'Update App Class: ' . ' ' . $model->name;
$this->params['breadcrumbs'][] = ['label' => 'App Classes', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->name, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<style>
    div.required .control-label:after {
        content: "*";
        color: red;
    }
</style>
<div class="app-class-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
        'modelU' => $modelU,
        'config'=>$config,
        'topClassList'=>$topClassList
    ]) ?>

</div>