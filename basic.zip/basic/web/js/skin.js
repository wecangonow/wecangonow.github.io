/**
 * Created by og on 15/11/18.
 */




$('#skinsform-lang input').click(function(){
    var index = $(this).parent().index();
    if($(this).is(':checked')){
        $('.lange').children('div').eq(index).show();
    }
    else{
        $('.lange').children('div').eq(index).hide();
        $('.lange').children('div').eq(index).find('input').val('');
    }


});


$('#skinssubform-lang input').click(function(){
    var index = $(this).parent().index();
    if($(this).is(':checked')){
        $('.lange').children('div').eq(index).show();
    }
    else{
        $('.lange').children('div').eq(index).hide();
        $('.lange').children('div').eq(index).find('input').val('');
    }

});



$('#checks').click(function(){
    if($(this).is(':checked')){

        $('input.cks').prop("checked",true);
    }else{

        $('input.cks').prop("checked",false);
    }
});


$('#skinssubform-version').attr("disabled","disabled");


$('#skinform').bind('afterValidateAttribute',function(event, attribute, messages){

    if(attribute.id=='skinsform-skinurl'){


        var ver=$('#skinsform-version').val();
        var id=$('#skinssubform-id').val();
        var str=$('#'+attribute.id).val();
        var arr=str.split('\\');
        var my=arr[arr.length-1];
        var myName=my.split('.')[0];

        var count=0;

        $.ajaxSetup({
            async : false
        });

        if(messages['skinsform-skinurl']==''){

            if(ver=='') {
                messages['skinsform-skinurl']=['请先选择版本'];
            }
            else{
                $.get("/skins/checkzip?name="+myName+'&ver='+ver+'&id='+id,function(result){

                    count=result;
                });
                if(count>0){
                    messages['skinsform-skinurl']=['同版本下，皮肤包不能同名'];
                }
            }
        }
    }

    //else if(attribute.id=='skinssubform-skinurl'){
    //
    //    var ver=$('#skinssubform-version').val();
    //    var id=$('#skinssubform-id').val();
    //    var str=$('#'+attribute.id).val();
    //    var arr=str.split('\\');
    //    var my=arr[arr.length-1];
    //    var myName=my.split('.')[0];
    //
    //    var count=0;
    //
    //    $.ajaxSetup({
    //        async : false
    //    });
    //
    //    if(messages['skinssubform-skinurl']==''){
    //
    //        if(ver=='') {
    //            messages['skinssubform-skinurl']=['请先选择版本'];
    //        }
    //        else{
    //            $.get("/skins/checkzip?name="+myName+'&ver='+ver+'&id='+id,function(result){
    //
    //                count=result;
    //            });
    //            if(count>0){
    //                messages['skinssubform-skinurl']=['同版本下，皮肤包不能同名'];
    //            }
    //        }
    //    }
    //}
});




//
//$('#skinsform-lang input').click(function(){
//    var index = $(this).parent().index();
//
//    var lange = $("#skinsform-lang").parent().siblings('.lange');
//    if($(this).is(':checked')) {
//        lange.children('div').eq(index).show();
//    }else{
//        lange.children('div').eq(index).hide();
//    }
//});


