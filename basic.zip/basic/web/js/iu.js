versionNext();

$("#iuform-from_version").change(function () {
    versionNext();
});

function versionNext()
{
    var version = $("#iuform-from_version").val();
    var type = $("#ajaxId").val();
    $.ajax({
        type: "GET",
        url: "/iu/next-version",
        data: {"version": version, "type": type},
        dataType: "json",
        async: false,
        success: function (data) {
            $("#iuform-to_version").val(data.version);
        }
    });
}
