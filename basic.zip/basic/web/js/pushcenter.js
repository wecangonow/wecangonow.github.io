
var type=$('#type_val').val();
var lang=0;
var pushtime=0;
var timed=0;
var new_template=1;
var bottom=0;
var openmode=0;
var img='';


// 类型选择
$('#ptypes').find('select').change(function(){

    type=$('#ptypes').find('select').val();
    window.location.href="?tt="+type;

    //img='';
    //lang=0;
    //if (type == 2) {
    //    $('.news_type input').prop("checked", false);
    //    $('.soft_type,.news_area,#url,#command,#bottom,#openmode').hide();
    //    $('.news_type,#template').show();
    //    $('#imghit').html('图片要求：110*120');
    //} else if (type == 3) {
    //    $('.soft_type,.news_area,#url,#command,#openmode').hide();
    //    $('.soft_type,#bottom').show();
    //    $('#imghit').html('图片要求：300*240');
    //} else {
    //    $('.soft_type,#url,#command,#bottom,#openmode').show();
    //    $('.news_type,#template,.ldiv,.news_area').hide();
    //    $('#imghit').html('图片要求：300*240');
    //}

});


// 下拉语言
$('.soft_type').find('select').change(function(){
     lang=$('.soft_type').find('select').val();
     setarea(lang);
});


//多选语言
$('.news_type input').click(function(){

    var lstr='';
    $('.news_type input').each(function () {
        if($(this).is(':checked')) {
            lstr += $(this).val() + ',';
            $('.l-'+$(this).val()).show();
        }else{
            $('.l-'+$(this).val()).hide();
        }
    });
    lang = lstr.slice(0,-1);
    setarea(lang);
});


// 推送时间
$('#pushtime input').click(function(){
    pushtime= $(this).parent().index();
    pushtime==2?$('.picker').show():$('.picker').hide();

});

$('#pushcenterform-bottom input').click(function(){
       bottom= $(this).parent().index();

});
$('#pushcenterform-openmode input').click(function(){
       openmode= $(this).parent().index();
});


//新闻选择模板

$('#pushcenterform-new_template input').click(function(){

    if($(this).is(':checked')){
        new_template = $(this).parent().index()+1;
        if($(this).parent().index()==1){
          $('#imgfile').hide();
       }else{
           $('#imgfile').show();
       }
    }

});

$('#file').on('change',function(){
    sendForm();
});

$('body').on('click','.rclose',function(){
    $('.preview').hide();
});




// 提交验证
$('#submita').on('click',function(){

    if(checkform())
    $('#pushform').submit();
});




//预览
$('#preview').on('click',function(){

    if(!checkform()) return false;

    var type_val=type;
    var img_val=$('#pushcenterform-img').val();
    var pushtext_val=$('#pushcenterform-pushtext').val();
    var url_val=$('#pushcenterform-url').val();
    var code=$('#pushcenterform-code').val();
    var bottom_val=0;
    var html='<div class="rclose"><img src="/css/x.png"></div>';
    var pushtime2=$('#pushtime2').val();



    $('#pushcenterform-bottom input').each(function () {
        if($(this).is(':checked')&&$(this).parent().index()==1) {
            bottom_val=1;
        }
    });


    if(type_val==1){
        if(openmode!=1){
            url_val='javascript:vold(0);'
        }
        html+='<a href="'+url_val+'" target="_blank"><img src="/'+img_val+'"></a>';
        if(bottom_val==1){
            html+='<a href="'+url_val+'" class="btn" target="_blank">查看</a>';
        }
    }else if(type_val==3){
        html+='<img src="/'+img_val+'">';
        if(bottom_val==1){
            html+='<a href="javascript:void();" class="btn">查看</a>';
        }
    }
    else if(type_val==2){

        var arr=lang.split(',');
        var tit=$('#new_'+arr[0]+'_tit').val();
        var title=$('#new_'+arr[0]+'_title').val();
        var url=$('#new_'+arr[0]+'_url').val();
        var text=$('#new_'+arr[0]+'_text').val();
        $('.preview').css('width','350px');
        html+='<div class="tit">'+tit+'</div>';
        if(new_template==1){
            html+='<div class="img"><a href="'+url+'" target="_blank"><img src="/'+img_val+'"></a></div>';
            html+='<a href="'+url+'" target="_blank"><div class="text"><div class="h2_1">'+title+'</div>'+text+'</div></a>';
        }
        else
            html+='<a href="'+url+'" target="_blank"><div class="text2"><div class="h2_2">'+title+'</div>'+text+'</div></a>';
        html+='<div class="btn-div"><a href="'+url+'"  target="_blank">查看</a></div>';

    }else if(type_val==4){
        $.ajax({
            type: 'POST',
            url: '/pushcenter/mkhtml',
            data: {'code':code},
            success: function(data){
                html+='<div class="code"><iframe src="'+data+'" width="300" height="250"  frameborder="no" border="0" marginwidth="0" marginheight="0" scrolling="no" allowtransparency="yes"></iframe></div>';
            },
            dataType: 'text',
            async: false
        });
        $('.preview').css('height','250px');
    }

    $('.preview').html(html)
    $('.preview').show()


});


function checkform(){
    timed=$('#pushtime2').val();
    var pushtext=$('#pushcenterform-pushtext').val();
    var code=$('#pushcenterform-code').val();
    if(!lang){
        alert('请选择语言');return false;
    }
    if(pushtime==2&&!timed){
        alert('请填写定时时间');return false;
    }
    if(!pushtext){
        alert('请填写推送内容');return false;
    }
    if(type==1||type==3){
        if(!img){
            alert('请上传图片');return false;
        }
    }

    if(type==2){


        if(!lang){
            alert('请选择语言');return false;
        }

        var arr=lang.split(',');

        for(var i=0;i<arr.length;i++){

            if($('#new_'+arr[i]+'_tit').val()==''||$('#new_'+arr[i]+'_url').val()==''||$('#new_'+arr[i]+'_title').val()==''||$('#new_'+arr[i]+'_text').val()=='')
            {
                alert(arr[i]+' 下必填项不能为空')
                return false;
            }
        }


        if(new_template==1&&!img){
            alert('新闻模板一的时候 图片必选')
            return false;
        }

    }
    if(type==4){
        if(!code){
            alert('请填写投放代码');return false;
        }
    }
    return true;
}


//根据语言取到语言下面的地区，并赋值
function setarea(lang){

    if(!lang){
        $('#news_area').hide();
        $('#news_area').html('');
    }else{
        $.get("/pushcenter/getarea?lang="+lang,function(result){

            var str='';
            for(var i in result) {
                str+='<input type="checkbox" name="PushCenterForm[area][]"   value="'+i+'">'+result[i];
            };

            $('#news_area').show();
            $('#news_area').html(str);

        },'json');
    }

}
// 上传图片
function sendForm(){


    var timg = new Image();
    var reader = new FileReader();
    reader.onload = function(){
        timg.src = this.result;
        var wid=timg.width;
        var hei=timg.height;
        if(type==2&&new_template==1){
            if(wid!=110&&hei!=120){
                alert('新闻，模板一下，图片要求  110*120');return false;
            }
        }
        else if(type==1||type==3){
            if(wid!=300&&hei!=240){
                alert('图片要求  300*240');return false;
            }
        }
    };
    reader.readAsDataURL($('#file')[0].files[0]);


    var fd = new FormData();
    fd.append("img",$('#file')[0].files[0]);

    $.ajax({
        type:'POST',
        dataType:'text',
        processData: false,  // 告诉JSLite不要去处理发送的数据
        contentType: false,   // 告诉JSLite不要去设置Content-Type请求头
        data:fd,
        url:'/pushcenter/upload',
        success:function(data){

            $('#pushcenterform-img').val(data);
            img=data;

        },
        error:function(d){
            console.log('error:',d)
        }
    })
}



