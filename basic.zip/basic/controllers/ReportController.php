<?php

namespace app\controllers;

use app\models\ARbase\AppOpenReport;
use app\models\SCform\AppOpenReportSearch;
use app\models\SCform\AppReportSyncSearch;
use app\models\SCform\AppTimeLongSearch;
use Yii;
use app\models\ARbase\AppReport;
use app\models\SCform\AppReportSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\widgets\ActiveForm;

/**
 * ReportController implements the CRUD actions for AppReport model.
 */
class ReportController extends BaseController
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all AppReport models.
     * @return mixed
     */
    public function actionIndex()
    {
        set_time_limit(0);
        $cache = Yii::$app->cache;
        $postdata = Yii::$app->request->get();
        if ($postdata) {
            $tableArr = [];
            $tableArr['date'] = $postdata['AppReportSearch']['date'];
            switch ($postdata['AppReportSearch']['type']) {
                case 1://查询dau
                    $appReportModel = new AppReportSearch();
                    if ($cache->get('dau-' . $postdata['AppReportSearch']['date']) === false) {
                        $dataList = $appReportModel->getDauByDate($postdata['AppReportSearch']['date']);
                        $cache->set('dau-' . $postdata['AppReportSearch']['date'], $dataList, 600);
                        $dataList = $cache->get('dau-' . $postdata['AppReportSearch']['date']);
                    } else {
                        $dataList = $cache->get('dau-' . $postdata['AppReportSearch']['date']);
                    }
                    $tableArr['dau'] = count($dataList);
                    $tableArr['type'] = 1;
                    break;
                case 2:
                    $postdata['AppReportSearch']['desc'] == 1 ? 'asc' : 'desc';
                    //报表app数量排行
                    $appReportSyncModel = new AppReportSyncSearch();
                    if ($cache->get('apporder-' . $postdata['AppReportSearch']['date'] . $postdata['AppReportSearch']['sort'] . $postdata['AppReportSearch']['desc']) === false) {
                        $dataList = $appReportSyncModel->getAllAppEachNum($postdata['AppReportSearch']);
                        $cache->set('apporder-' . $postdata['AppReportSearch']['date'] . $postdata['AppReportSearch']['sort'] . $postdata['AppReportSearch']['desc'], $dataList,600);
                        $dataList = $cache->get('apporder-' . $postdata['AppReportSearch']['date'] . $postdata['AppReportSearch']['sort'] . $postdata['AppReportSearch']['desc']);
                    } else {
                        $dataList = $cache->get('apporder-' . $postdata['AppReportSearch']['date'] . $postdata['AppReportSearch']['sort'] . $postdata['AppReportSearch']['desc']);
                    }
                    $tableArr['desc'] = $postdata['AppReportSearch']['desc'] == 1 ? 2 : 1;
                    $tableArr['datalist'] = $dataList;
                    $tableArr['type'] = 2;
                    break;
                case 3:
                    //报表单个模拟器多个模拟器
                    $appReportModel = new AppReportSearch();
                    if ($cache->get('simulator-' . $postdata['AppReportSearch']['date']) === false) {
                        $dataList = $appReportModel->getAnalogNumByDate($postdata['AppReportSearch']['date']);
                        $cache->set('simulator-' . $postdata['AppReportSearch']['date'], $dataList, 600);
                        $dataList = $cache->get('simulator-' . $postdata['AppReportSearch']['date']);
                    } else {
                        $dataList = $cache->get('simulator-' . $postdata['AppReportSearch']['date']);
                    }
                    //逻辑处理
                    $analogOne = 0;
                    $analogMore = 0;
                    foreach ($dataList as $key => $value) {
                        if ($value['macnum'] == 1) {
                            $analogOne++;
                        } else {
                            $analogMore++;
                        }
                    }
                    $tableArr['analogOne'] = $analogOne;
                    $tableArr['analogMore'] = $analogMore;
                    $tableArr['type'] = 3;
                    break;
                case 4:
                    //报表app每天打开次数


                    $postdata['AppReportSearch']['desc'] == 1 ? 'asc' : 'desc';
                    //报表app数量排行
                    $appOpenReportModel = new AppOpenReportSearch();
                    if ($cache->get('apptimes-' . $postdata['AppReportSearch']['date'] . $postdata['AppReportSearch']['sort'] . $postdata['AppReportSearch']['desc']) === false) {
                        $dataList = $appOpenReportModel->getAppTimesByDate($postdata['AppReportSearch']);
                        $cache->set('apptimes-' . $postdata['AppReportSearch']['date'] . $postdata['AppReportSearch']['sort'] . $postdata['AppReportSearch']['desc'], $dataList, 600);
                        $dataList = $cache->get('apptimes-' . $postdata['AppReportSearch']['date'] . $postdata['AppReportSearch']['sort'] . $postdata['AppReportSearch']['desc']);
                    } else {
                        $dataList = $cache->get('apptimes-' . $postdata['AppReportSearch']['date'] . $postdata['AppReportSearch']['sort'] . $postdata['AppReportSearch']['desc']);
                    }
                    $tableArr['desc'] = $postdata['AppReportSearch']['desc'] == 1 ? 2 : 1;
                    $tableArr['datalist'] = $dataList;
                    $tableArr['type'] = 4;
                    break;
                case 5:
                    //报表app每天打开次数

                    $postdata['AppReportSearch']['desc'] == 1 ? 'asc' : 'desc';
                    //报表app数量排行
                    $apptimelongReportModel = new AppTimeLongSearch();
                    if ($cache->get('apptimelong-' . $postdata['AppReportSearch']['date'] . $postdata['AppReportSearch']['sort'] . $postdata['AppReportSearch']['desc']) === false) {
                        $dataList = $apptimelongReportModel->getAppTimeLongByDate($postdata['AppReportSearch']);
                        $cache->set('apptimelong-' . $postdata['AppReportSearch']['date'] . $postdata['AppReportSearch']['sort'] . $postdata['AppReportSearch']['desc'], $dataList, 600);
                        $dataList = $cache->get('apptimelong-' . $postdata['AppReportSearch']['date'] . $postdata['AppReportSearch']['sort'] . $postdata['AppReportSearch']['desc']);
                    } else {
                        $dataList = $cache->get('apptimelong-' . $postdata['AppReportSearch']['date'] . $postdata['AppReportSearch']['sort'] . $postdata['AppReportSearch']['desc']);
                    }
                    $tableArr['desc'] = $postdata['AppReportSearch']['desc'] == 1 ? 2 : 1;
                    $tableArr['datalist'] = $dataList;
                    $tableArr['type'] = 5;
                    break;
            }
        }
        $searchModel = new AppReportSearch();
        $searchModel->load(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'tableArr' => $tableArr
        ]);
    }

    /**
     * Displays a single AppReport model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new AppReport model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new AppReport();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing AppReport model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing AppReport model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the AppReport model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return AppReport the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = AppReport::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionReportJs()
    {
        return $this->renderPartial("report-js");
    }
}
