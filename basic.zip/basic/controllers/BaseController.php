<?php

namespace app\controllers;

use app\models\Adminuser;
use app\models\AuthUser;
use Yii;
use yii\web\Controller;
use yii\web\NotFoundHttpException;

class BaseController extends Controller
{


    public function beforeAction($action)
    {
        if (!parent::beforeAction($action)) {
            return false;
        }

        if(Yii::$app->user->getIdentity()->username == 'admin'){
            return true;
        }

        $cache = Yii::$app->cache;
        $user_auths=$cache->get('user_auths'.Yii::$app->user->id);

        $controller = Yii::$app->controller->id;

        if(!in_array($controller,$user_auths)&& Yii::$app->getErrorHandler()->exception === null){
             throw new \yii\web\UnauthorizedHttpException('对不起，您现在还没获此操作的权限');
        }
        return true;
    }

}

 
