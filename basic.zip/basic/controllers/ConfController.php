<?php

namespace app\controllers;

use app\models\VLform\ConfForm;
use Yii;
use app\models\ARbase\Conf;

use yii\web\NotFoundHttpException;

/**
 * ConfController implements the CRUD actions for Conf model.
 */
class ConfController extends BaseController
{

    public function actionIndex() {

        $model  = new ConfForm();
        $modelC = new Conf();

        if ($model->load(Yii::$app->request->post()))
        {

            if ($model->validate())
            {

                $post = Yii::$app->request->post();

                foreach ($post['ConfForm'] as $name => $val)
                {
                    $ob        = $modelC->findOne(['name' => $name]);
                    $ob->value = $val;
                    $ob->save();
                }
                $cache = Yii::$app->cache;
                $cache->delete('update_conf');
            }
            $_SESSION['confalert'] = 1;
        }

        $prem  = ['up_lock', 'up_ver', 'up_dlurl', 'up_md5', 'reup_lock', 'reup_ver', 'reup_dlurl', 'reup_md5', 'new_ver', 'new_dlurl', 'new_uninclude_ver', 'new_uninclude_dlurl'];
        $model = new ConfForm();
        $arr   = Conf::find()->where(['in', 'name', $prem])->asArray()->all();
        foreach ($arr as $v)
        {
            $model->$v['name'] = $v['value'];
        }

        return $this->render('index', [
            'model' => $model,
        ]);
    }

}
