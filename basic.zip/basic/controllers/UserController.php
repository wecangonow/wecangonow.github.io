<?php

namespace app\controllers;

use app\models\Auth;
use app\models\AuthUser;
use Yii;
use yii\filters\AccessControl;
use app\models\ARbase\UpUser;
use app\models\VLform\UserForm;
use app\models\VLform\UserSubForm;
use app\models\SCform\UserSearchForm;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * UserController implements the CRUD actions for UpUser model.
 */
class UserController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['index', 'create', 'update', 'delete'],
                'rules' => [
                    [
                        'actions' => ['index', 'create', 'update', 'delete'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all UpUser models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new UserSearchForm();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Creates a new UpUser model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new UserForm();

        if ($model->load(Yii::$app->request->post()) && $model->validate()) {
            $model->create_time = date("Y-m-d H:i:s");
            $model->update_time = $model->create_time;
            $model->password = md5(hash("sha256", $model->password));
            $model->save();
            return $this->redirect('index');
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing UpUser model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {

        $modelU = $this->findModel($id);
        if (Yii::$app->user->getIdentity()->username == 'admin')
            $model = new UserForm();
        else
            $model = new UserSubForm();

        if ($model->load(Yii::$app->request->post()) && $model->validate())
        {
            if (Yii::$app->user->getIdentity()->username == 'admin')
                $modelU->username = $model->username;
            if ($model->password)
            {
                $modelU->password = md5(hash("sha256", $model->password));
            }
            $auths = Yii::$app->request->post('auths');
            if ($auths)
            {
                AuthUser::deleteAll(['uid' => $id]);
                foreach ($auths as $va)
                {
                    $model        = new AuthUser();
                    $model->uid   = $id;
                    $model->value = $va;
                    $model->save();
                }
            }

            $modelU->update_time = date("Y-m-d H:i:s");
            Yii::trace($modelU->update());

            return $this->redirect(['index']);
        }
        else
        {
            $user_auths= AuthUser::getall($id);
            $authrows=Auth::getall();
            return $this->render('update', [
                'model'  => $model,
                'modelU' => $modelU,
                'user_auths' => $user_auths,
                'authrows' => $authrows,
            ]);
        }
    }

    /**
     * Deletes an existing UpUser model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the UpUser model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return UpUser the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = UpUser::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
