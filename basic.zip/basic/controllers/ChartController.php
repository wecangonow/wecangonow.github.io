<?php

namespace app\controllers;

use Yii;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

class ChartController extends BaseController
{
    public function behaviors()
    {
        return [
        ];
    }

    public function actionIndex()
    {
        $this->render("index");

    }

}
