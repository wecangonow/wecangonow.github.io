<?php
/**
 * Created by PhpStorm.
 * User: chunyu
 * Date: 16/7/5
 * Time: 下午4:57
 */
namespace app\controllers;

use Yii;
use PHPExcel;
use PHPExcel_Reader_Excel5;
use yii\filters\AccessControl;
use yii\web\Controller;
use app\models\ARbase\TwoWeek;
use app\models\SCform\UserSearchForm;

class HighchartsController extends Controller
{

    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['index'],
                'rules' => [
                    [
                        'allow' => true,
                        'actions' => ['index'],
                        'roles' => ['?'],
                    ],
                ],
            ],
        ];

    }

    public function getMin($arr, $index)
    {
        $min = $arr[0][$index];
        $ret = "";
        foreach($arr as $k => $v)
        {
            if($v[$index] <= $min)
            {
                $min = $v[$index];
                $ret = $k;
            }

        }
        return $ret;
    }

    public function getMax($arr, $index)
    {
        $max = "";
        $ret = "";
        foreach($arr as $k => $v)
        {
            if($v[$index] >= $max)
            {
                $max = $v[$index];
                $ret = $k;
            }

        }
        return $ret;
    }

    public function getDownloadSuccessRateByDate($date)
    {
        //1.当日大包下载成功率＝A/B
        //A ＝ select count(distinct uuid) from ev_download where create_time = '2016-10-27' and event in('dl_finish','mini_memu_dlfinish') and uuid in (select distinct uuid from ev_download where create_time = '2016-10-27' and event in('dl_start','mini_btn_click'));
        //B = select count(distinct uuid) from ev_download where create_time = '2016-10-27' and event in ('dl_start','mini_btn_click');

        $finish_sql = "select count(distinct uuid) as total from ev_download where create_time = '$date' and event in('dl_finish','mini_memu_dlfinish') and uuid in (select distinct uuid from ev_download where create_time = '$date' and event in('dl_start','mini_btn_click'))";
        $finish_num = Yii::$app->db->createCommand($finish_sql)->queryOne();

        $start_sql = "select count(distinct uuid) as total from ev_download where create_time = '$date' and event in ('dl_start','mini_btn_click')";
        $start_num = Yii::$app->db->createCommand($start_sql)->queryOne();


        return sprintf("%.2f", floatval($finish_num["total"]/$start_num["total"])*100) . "%";

    }
    public function getDumpRateByDate($date)
    {
        //3.崩溃率=A/B
        //A = select count(distinct uuid) from ev_dumpcount where create_time = '2016-10-27' and event in('dumpcount','simcake_dumpcount');
        //B = select count(distinct uuid) from ev_heartbeat where create_time = '2016-10-27' and event in ('heartbeat','svc_heartbeat_live');

        $dump_sql = "select count(distinct uuid) as total from ev_dumpcount where create_time = '$date' and event in('dumpcount','simcake_dumpcount')";
        $dump_num = Yii::$app->db->createCommand($dump_sql)->queryOne();

        $heart_sql = "select count(distinct uuid) as total from ev_heartbeat where create_time = '$date' and event in ('heartbeat','svc_heartbeat_live')";
        $heart_num = Yii::$app->db->createCommand($heart_sql)->queryOne();


        return sprintf("%.2f", floatval($heart_sql["total"]/$heart_num["total"])*100) . "%";

    }

    public function getInstallSuccessRateByDate($date)
    {
        //2.当日大包安装成功率 = A/B
        //A = select count(distinct uuid) from ev_install where create_time = '2016-10-27' and event in('install_finish','memu_install_finish') and uuid in(select distinct uuid from ev_install where create_time = '2016-10-27' and event in('install','memu_install_start'));
        //B = select count(distinct uuid) from ev_install where create_time = '2016-10-27' and event in('install','memu_install_start');
        //

        $finish_sql = "select count(distinct uuid) as total from ev_install where create_time = '$date' and event in('install_finish','memu_install_finish') and uuid in(select distinct uuid from ev_install where create_time = '$date' and event in('install','memu_install_start'))";
        $finish_num = Yii::$app->db->createCommand($finish_sql)->queryOne();

        $start_sql = "select count(distinct uuid) as total from ev_install where create_time = '$date' and event in('install','memu_install_start')";
        $start_num = Yii::$app->db->createCommand($start_sql)->queryOne();


        return sprintf("%.2f", floatval($finish_num["total"]/$start_num["total"])*100) . "%";

    }
    public function actionIndex()
    {
        $this->layout = "@app/views/layouts/main-single";
        echo $this->getDumpRateByDate("2016-10-29");
        die;
        //table 1 start
        //


        // table 2 start
        $sql = " select `date` ,dau ,dru ,dnu ,ifnull(d2a/dnu,0) as `d2a/dnu`,ifnull(d2r/dnu,0) as `d2r/dnu`, today_uninstall/dnu as `nuu/dnu` from rpn_total_core order by date desc limit 14";

        $data = Yii::$app->db->createCommand($sql)->queryAll();

        $key_arr = ["dau", "dru", "dnu", "d2a/dnu", "d2r/dnu", "nuu/dnu"];

        foreach($data as $key => $value) {
            $data[$key]['dayofweek'] = date("l", strtotime($data[$key]['date']));
            $data[$key]['d2a/dnu'] = sprintf("%.2f", floatval($data[$key]['d2a/dnu'])*100) . "%";
            $data[$key]['d2r/dnu'] = sprintf("%.2f", floatval($data[$key]['d2r/dnu'])*100) . "%";
            $data[$key]['nuu/dnu'] = sprintf("%.2f", floatval($data[$key]['nuu/dnu'])*100) . "%";
        }


        foreach($key_arr as $v) {
            $max_index = $this->getMax($data, $v);
            $data[$max_index][$v . "_max"] = true;
            $min_index = $this->getMin($data, $v);
            $data[$min_index][$v . "_min"] = true;
        }
        // table 2 end

        return $this->render('index', ['resultData'=>$data]);
    }

    public function actionGetExcelData()
    {
//        $objPHPExcel = new PHPExcel();
        $filePath = "./memu_report/2016-06-20/Memu2016-06-20.xls";
        $arr = array();
        $temparr = array();

        $PHPExcel = new PHPExcel();
        $PHPReader = new PHPExcel_Reader_Excel5();
        $PHPExcel = $PHPReader->load($filePath);
        $currentSheet = $PHPExcel->getSheet(0);
        /*取得一共有多少列*/
        $allColumn = $currentSheet->getHighestColumn();
        /*取得一共有多少行*/
        $allRow = $currentSheet->getHighestRow();
        for ($currentRow = 1; $currentRow <= $allRow; $currentRow++) {
            $temparr['channel'][] = $currentSheet->getCell('A' . $currentRow)->getValue();
            $temparr['DNU'][] = $currentSheet->getCell('B' . $currentRow)->getValue();
            $temparr['DAU'][] = $currentSheet->getCell('C' . $currentRow)->getValue();
            $temparr['fujian'][] = $currentSheet->getCell('D' . $currentRow)->getValue();
            $temparr['gerenwangpan'][] = $currentSheet->getCell('E' . $currentRow)->getValue();
            $temparr['chaodafujian'][] = $currentSheet->getCell('F' . $currentRow)->getValue();
            $temparr['suishenyou'][] = $currentSheet->getCell('G' . $currentRow)->getValue();
            $temparr['chuanzhen'][] = $currentSheet->getCell('H' . $currentRow)->getValue();
            $temparr['qiyewangpan'][] = $currentSheet->getCell('I' . $currentRow)->getValue();
        }
        echo "<pre>";
        print_r($temparr);
    }
}