<?php

namespace app\controllers;

use app\models\VLform\HwmconfForm;
use Yii;
use app\models\ARbase\Hwmconf;

use yii\web\NotFoundHttpException;

/**
 * HwmconfController implements the CRUD actions for Hwmconf model.
 */
class HwmconfController extends BaseController
{

    public function actionIndex() {

        $model  = new HwmconfForm();
        $modelC = new Hwmconf();

        if ($model->load(Yii::$app->request->post()))
        {
            if ($model->validate())
            {
                $post = Yii::$app->request->post();
                foreach ($post['HwmconfForm'] as $name => $val)
                {
                    $ob        = $modelC->findOne(['name' => $name]);
                    $ob->value = $val;

                    $ob->save();
                }
                $cache = Yii::$app->cache;
                $cache->delete('update_hwmconf');
            }
            $_SESSION['Hwmconfalert'] = 1;
        }

        $prem  = ['up_lock', 'up_ver', 'up_dlurl', 'up_md5', 'reup_lock', 'reup_ver', 'reup_dlurl', 'reup_md5', 'new_ver', 'new_dlurl'];
        $model = new HwmconfForm();
        $arr   = Hwmconf::find()->where(['in', 'name', $prem])->asArray()->all();
        foreach ($arr as $v)
        {
            $model->$v['name'] = $v['value'];
        }

        return $this->render('index', [
            'model' => $model,
        ]);
    }

}
