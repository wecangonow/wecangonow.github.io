<?php

namespace app\controllers;

use app\models\ARbase\Banner;
use app\models\ARext\LAppClass;
use Yii;
use app\models\ARbase\App;
use app\models\ARbase\AppU;
use app\models\SCform\Appsearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use app\plb\CommonLib;
use yii\web\UploadedFile;
/**
 * AppController implements the CRUD actions for App model.
 */
class HotController extends BaseController
{


    /**
     * Lists all App models.
     * @return mixed
     */
    public function actionIndex()
    {
        // 公共配置
        $config = require("../config/config.php");
        //获取类别属性
        $topClassList = LAppClass::getTopClass();
        $otherClassList = LAppClass::getOtherClass();
        $searchModel = new Appsearch();
        $dataProvider = $searchModel->searchHot(Yii::$app->request->queryParams);
        $searchModel->load(Yii::$app->request->queryParams);
        if(!empty(Yii::$app->request->queryParams['Appsearch'])){
            //获取子级分类
            $classArr = LAppClass::getClassByPClass($searchModel->p_class);
            if(!empty($classArr)){
                foreach($classArr as $key=>$value){
                    $classList[$value['id']] = $value['name'];
                }
            }
        }
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'topClassList' => $topClassList,
            'classList' => $classList,
            'config' => $config,
            'otherClassList' => $otherClassList,
        ]);
    }

    /**
     * Displays a single App model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

    /**
     * Creates a new App model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        //获取类别属性
        $topClassList = LAppClass::getTopClass();
        // 公共配置
        $config = require("../config/config.php");
        $model = new App();

        if ($model->load(Yii::$app->request->post()))
        {
            $dir = "uploads/app/";
            CommonLib::createFolder($dir);
            $model->img = UploadedFile::getInstance($model, 'img');

            if ($model->validate())
            {

                $imgpath = $dir . time() . '.' . $model->img->extension;
                $model->img->saveAs($imgpath);
                $model->img = '/'.$imgpath;

                $model->save();

                Yii::$app->getSession()->setFlash('success', "创建成功");
                return $this->redirect(['index']);
            }
        }

        return $this->render('create', [
            'model' => $model,
            'topClassList' => $topClassList,
            'config' => $config,
        ]);
    }

    /**
     * Updates an existing App model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        // 公共配置
        $config = require("../config/config.php");
        $model = AppU::findOne($id);

        if ($model->load(Yii::$app->request->post()))
        {

            $dir = "uploads/app/";
            CommonLib::createFolder($dir);
            $model->img = UploadedFile::getInstance($model, 'img');

            $model = LAppClass::deployDbData($model, $config);
            if ($model->validate())
            {
                if ($model->img)
                {
                    $imgpath = $dir . time() . '.' . $model->img->extension;
                    $model->img->saveAs($imgpath);
                    $model->img = '/'.$imgpath;
                }else{
                    unset($model->img);
                }

                $model->save();

                Yii::$app->getSession()->setFlash('success', "修改成功");
                return $this->redirect(['index']);
            }
        }

        //获取类别属性
        $topClassList = LAppClass::getTopClass();
        //获取子级分类
        $classArr = LAppClass::getClassByPClass($model->p_class);
        if(!empty($classArr)){
            foreach($classArr as $key=>$value){
                $classList[$value['id']] = $value['name'];
            }
        }
        $model->lang = explode(',', $model->lang);
        unset($config['lang'][0]);
        return $this->render('update', [
            'model' => $model,
            'topClassList' => $topClassList,
            'classList' => $classList,
            'config' => $config,
        ]);
    }

    public function actionSort() {

        $sort=Yii::$app->request->post('hot_sort');
        foreach($sort as $id=>$val){
            $mod=$this->findModel($id);
            $mod->hot_sort=$val;
            $mod->save();
        }
        return $this->redirect(['index']);
    }

    public function actionCreatehtml() {


        $row=App::find()->orderBy('sort asc')->asArray()->all();
        $banners=Banner::find()->where(['size'=>'850*250'])->orderBy('sort asc')->limit(4)->asArray()->all();
        $banners_right=Banner::find()->where(['size'=>'425*250'])->orderBy('sort asc')->asArray()->one();
        $str=$this->renderPartial('html', [
            'model' => $row,
            'banners' => $banners,
            'banners_right' => $banners_right,
        ]);
        file_put_contents('html/apps.html',$str);
        echo '<script>alert("生成完成")</script>';
        header("Location:/app/index");
    }

    /**
     * Deletes an existing App model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionCancel($id)
    {
        $hotU = $this->findModel($id);
        $hotU->is_hot = 0;
        $hotU->save();
        Yii::$app->getSession()->setFlash('success', "取消排行成功");
        return $this->redirect(['index']);
    }

    /**
     * Finds the App model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return App the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = App::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
    public function actionGetClass(){
        $postData = Yii::$app->request->post();
        $p_class = $postData['p_class'];
        if(!empty($p_class)){
            $class = LAppClass::getClassByPClass($p_class);
            $html = LAppClass::returnSelHtml($class);
            return $html;
        }else{
            return '<option value="">请选择子级分类</option>';
        }
    }

    public function actionAppJs()
    {
        return $this->renderPartial("app-js");
    }
}
