<?php

namespace app\controllers;

use app\models\ARext\LAppClass;
use app\models\SCform\Appsearch;
use app\models\VLform\AppclassForm;
use Yii;
use app\models\ARbase\AppClass;
use app\models\SCform\AppClassSearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\web\Response;
use yii\widgets\ActiveForm;

/**
 * AppclassController implements the CRUD actions for AppClass model.
 */
class AppclassController extends BaseController
{
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['post'],
                ],
            ],
        ];
    }

    /**
     * Lists all AppClass models.
     * @return mixed
     */
    public function actionIndex()
    {
        // 公共配置
        $config = require("../config/config.php");
        //获取类别属性
        $topClassList = LAppClass::deployTopClass();
        $searchModel = new AppClassSearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);
        $searchModel->load(Yii::$app->request->queryParams);
        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
            'topClassList' => $topClassList,
            'config' => $config,
        ]);
    }

    /**
     * Creates a new AppClass model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new AppClass();
        $model->isNewRecord = 1;
        //获取类别属性
        $topClassList = LAppClass::deployTopClass();
        // 公共配置
        $config = require("../config/config.php");

        if ($model->load(Yii::$app->request->post())) {

            if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
                $lang = $model->lang;
                if ($lang[0] == 1) {
                    unset($lang[0]);
                }
                $langStr = implode(',', $lang);
                $model->lang = $langStr;
                Yii::$app->response->format = Response::FORMAT_JSON;
                $result = ActiveForm::validate($model);
                return $result;
            }
            $model = LAppClass::deployDbData($model, $config);
            $model->save();
            Yii::$app->getSession()->setFlash('success', "Create Success");
            return $this->redirect(['index']);
        }
        return $this->render('create', [
            'model' => $model,
            'config' => $config,
            'topClassList' => $topClassList
        ]);
    }

    /**
     * Updates an existing AppClass model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        // 公共配置
        $config = require("../config/config.php");
        $model = new AppclassForm();
        $model->isNewRecord = 0;
        $modelU = $this->findModel($id);
        $model->attributes = $modelU->attributes;
        //获取类别属性
        $topClassList = LAppClass::deployTopClass();

        if ($model->load(Yii::$app->request->post())) {
            if (Yii::$app->request->isAjax && $model->load(Yii::$app->request->post())) {
                $lang = $model->lang;
                if ($lang[0] == 1) {
                    unset($lang[0]);
                }
                $langStr = implode(',', $lang);
                $model->lang = $langStr;
                Yii::$app->response->format = Response::FORMAT_JSON;
                $result = ActiveForm::validate($model);
                return $result;
            }
            $model = LAppClass::deployDbData($model, $config);
            $modelU->attributes = $model->attributes;
            $modelU->save();
            Yii::$app->getSession()->setFlash('success', "Update Success");
            return $this->redirect(['index']);
        } else {
            $model->lang = explode(',', $modelU->lang);
            $array = $model->lang;
            if (count($array) == 2) {
                array_unshift($array, '1');
            }
            $model->lang = $array;
            return $this->render('update', [
                'model' => $model,
                'modelU' => $modelU,
                'config' => $config,
                'topClassList' => $topClassList
            ]);
        }
    }

    /**
     * Deletes an existing AppClass model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $appclassSearch_model = new AppClassSearch();
        $class_rs = $appclassSearch_model->checkClassIsParentClass($id);
        if (!empty($class_rs)) {
            Yii::$app->getSession()->setFlash('error', "删除失败,该分类下有子分类");
            return $this->redirect(['index']);
            exit;
        }

        $appsearch_model = new Appsearch();
        $rs = $appsearch_model->checkClassIsHaveApp($id);
        if (empty($rs)) {
            $this->findModel($id)->delete();
            Yii::$app->getSession()->setFlash('success', "删除成功");
            return $this->redirect(['index']);
        } else {
            Yii::$app->getSession()->setFlash('error', "删除失败,该分类下有数据");
            return $this->redirect(['index']);
        }
    }

    /**
     * Finds the AppClass model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return AppClass the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = AppClass::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

    public function actionExcel()
    {
        $excel_path = './bbbbb.xlsx';

        //关闭yii的自动装载
        spl_autoload_unregister(array('YiiBase', 'autoload'));

        include 'PHPExcel/IOFactory.php';
        $objPHPExcel = \PHPExcel_IOFactory::load($excel_path);
        $sheetData = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);
        $appClasssearch_model = new AppClassSearch();
        foreach ($sheetData as $key => $value) {
            if ($key > 1) {
//                $rs = $appClasssearch_model->checkAppClass($value['A']);
                if (empty($rs)) {
                    $appClasssearch_model = new AppClass();
                    $appClasssearch_model->type = $value['A'];
                    $appClasssearch_model->name = $value['B'];
                    $appClasssearch_model->en_name = $value['C'];
                    $appClasssearch_model->pt_name = $value['D'];
                    $appClasssearch_model->lang = "pt,en";
                    $appClasssearch_model->sort = 1000;
                    $appClasssearch_model->create_time = time();
                    $appClasssearch_model->update_time = time();
                    $appClasssearch_model->save();
                }
            }
        }
        //恢复yii的自动装载
//        spl_autoload_register(array('YiiBase', 'autoload'));

    }

    public function actionSort()
    {

        $sort = Yii::$app->request->post('sort');
        foreach ($sort as $id => $val) {
            $mod = $this->findModel($id);
            $mod->sort = $val;
            $mod->save();
        }
        Yii::$app->getSession()->setFlash('success', "Create Success");
        return $this->redirect(['index']);
    }

    public function actionAppclassJs()
    {
        return $this->renderPartial("appclass-js");
    }
}
