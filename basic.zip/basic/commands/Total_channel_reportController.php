<?php
/**
 * Created by PhpStorm.
 * User: chunyu
 * Date: 16/4/6
 * Time: 下午3:59
 */

namespace app\commands;

use Yii;
use yii\console\Controller;
use PHPExcel;
use PHPExcel_Style_NumberFormat;


class Total_channel_reportController extends Controller
{
    public $channel = ['total'];

    /**
     * 每日生成数据
     */
    public function actionCreateReport()
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $begindate = '2016-09-09';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-09-09';
        $enddate = date("Y-m-d", strtotime("-1 days"));
        $day = $this->diffBetweenTwoDays($startdate, $enddate);
        ob_end_clean();
        ob_start();
        for ($j = 0; $j <= $day; $j++) {
            if (empty($this->checkTotalChannelTableData($startdate))) {
                $data = $this->getTotalChannelTableData($startdate);
                $this->saveTotalChannelData($data);
            }
            $data = $this->getTotalChannelSyncTableData($startdate, $enddate);
            $this->saveTotalChannelSyncData($data, $startdate);
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
        }

        $this->createMemuTotalChannelCSV('memu_total_channel');
    }

    /**
     * 生成csv文件
     */

    public function createMemuTotalChannelCSV($filename)
    {
        $sql = 'select * from rp_total_channel';
        $data = Yii::$app->db->createCommand($sql)->queryAll();
        foreach ($data as $key => $value) {
            $sync_sql = "select * from rp_total_channel_sync where date='" . $value['date'] . "' and channel='" . $value['channel'] . "'";
            $syncdata = Yii::$app->db->createCommand($sync_sql)->queryAll();
            foreach ($syncdata as $k => $v) {
                $data[$key][$v['key']] = $v['value'];
            }
            unset($data[$key]['id']);
            unset($data[$key]['create_time']);
        }
        $rowArr = [];
        foreach ($data as $key => $value) {
            if ($key == 0) {
                foreach ($value as $k => $v) {
                    $rowArr[] = $k;
                }
            }
        }
        array_unshift($data, $rowArr);

        $file = fopen("./web/memu_report/" . $filename . ".csv", "w");

        foreach ($data as $line) {
            fputcsv($file, $line, ',');
        }
    }

    /**
     * 检查rp_total_channel_sync表是否有数据
     * @param $startdate
     * @param $channel
     * @param $d
     * @return array|bool
     */
    public function checkTotalChannelSyncTableData($startdate, $d)
    {
        $sql = "select id from rp_total_channel_sync where `date`='" . $startdate . "' and `key`='" . $d . "'";
        $data = Yii::$app->db->createCommand($sql)->queryOne();
        return $data;
    }

    /**
     *检查rp_total_channel表是否有数据
     * @param $startdate
     * @return array|bool
     */
    public function checkTotalChannelTableData($startdate)
    {
        $sql = "select id from rp_total_channel where `date`='" . $startdate . "'";
        $data = Yii::$app->db->createCommand($sql)->queryOne();
        return $data;
    }

    /**
     * 获取rp_total_channel表中的相关数据
     * @param $enddate
     * @return mixed
     */
    public function getTotalChannelTableData($enddate)
    {
        //时间 A
        foreach ($this->channel as $k => $v) {
            $data['date'][$v] = $enddate;
            //获取渠道 B
            $data['channel'][$v] = $this->channel[$k];
        }
        //获取DNU C
        $data['dnu'] = $this->setDNU($enddate);
        //获取DAU D
        $data['dau'] = $this->setDAU($enddate);
        //获取DRU E
        $data['dru'] = $this->setDRU($enddate);
        //pageview F
        $data['pageview'] = $this->setPageview($enddate);
        //获取click G
        $data['dlclick'] = $this->setDlClick($enddate);
        //获取click H
        $data['ctr'] = $this->setCTR($enddate);
        //获取install_finish I
        $data['install_finish'] = $this->setInstallFinish($enddate);
        //获取卸载 J
        $data['uninstall'] = $this->setUnInstall($enddate);
        //获取卸载 K
        $data['today_uninstall'] = $this->setTodayUnInstall($enddate);
        //获取卸载 L
        $data['memu_run_time'] = $this->setMemuRuntime($enddate);


        return $data;
    }

    /**
     * 获取rp_total_channel_sync表中的相关数据
     * @param $startdate
     * @param $enddate
     * @return mixed
     */
    public function getTotalChannelSyncTableData($startdate, $enddate)
    {
        //以2016-06-20 开始的留存 M
        $data['da'] = $this->setKeepDAU($startdate, $enddate);
        //以2016-06-20 开始的留存 N
        $data['dr'] = $this->setKeepDRU($startdate, $enddate);
        return $data;
    }

    /**
     * 保存数据到rp_total_channel
     * @param $data
     */
    public function saveTotalChannelData($data)
    {
        $db = Yii::$app->db;
        foreach ($data as $key => $value) {
            if ($key != 'da' && $key != 'dr') {
                $rowArr[] = $key;
            }
        }
        $row = "`" . implode("`,`", $rowArr) . "`" . ",`create_time`";
        foreach ($this->channel as $key => $item) {
            $valuesArr = [];
            $values = '';
            $values .= "(";
            $valuesArr[] = $data['date'][$item];
            $valuesArr[] = $data['channel'][$item];
            $valuesArr[] = number_format($data['dnu'][$item]);
            $valuesArr[] = number_format($data['dau'][$item]);
            $valuesArr[] = number_format($data['dru'][$item]);
            $valuesArr[] = number_format($data['pageview'][$item]);
            $valuesArr[] = number_format($data['dlclick'][$item]);
            $valuesArr[] = $data['ctr'][$item];
            $valuesArr[] = number_format($data['install_finish'][$item]);
            $valuesArr[] = number_format($data['uninstall'][$item]);
            $valuesArr[] = number_format($data['today_uninstall'][$item]);
            $valuesArr[] = number_format(ceil($data['memu_run_time'][$item] * 5 / $data['dau'][$item]));
            $valuesArr[] = date("Y-m-d H:i:s");
            $values .= "'" . implode("','", $valuesArr) . "'";
            $values .= ")";
            $sql = "insert into rp_total_channel (" . $row . ") value " . $values;
            $db->createCommand($sql)->query();
        }
    }

    /**
     * 保存数据到 rp_total_channel_sync
     * @param $data
     * @param $startdate
     */
    public function saveTotalChannelSyncData($data, $startdate)
    {
        $db = Yii::$app->db;
        foreach ($this->channel as $key => $item) {
            $i = 2;
            for ($j = 0; $j < count($data['da']); $j++) {
                // 注释解开则 插入最新的一天的留存 注释掉则是循环所有的留存
                if ($j == (count($data['da']) - 1)) {
                    if (!empty($data['da'][$j])) {
                        foreach ($data['da'][$j] as $k => $v) {
                            if (empty($this->checkTotalChannelSyncTableData($startdate, 'total', "D" . $i . "A"))) {
                                $Dasql = "insert into rp_total_channel_sync (`date`,`channel`,`key`,`value`,`create_time`) VALUES ('" . $startdate . "','total','D" . $i . "A','" . number_format($data['da'][$j][$k]['DA']) . "','" . date("Y-m-d H:i:s") . "')";

                                $db->createCommand($Dasql)->query();
                            }
                            if (empty($this->checkTotalChannelSyncTableData($startdate, 'total', "D" . $i . "R"))) {
                                $Drsql = "insert into rp_total_channel_sync (`date`,`channel`,`key`,`value`,`create_time`) VALUES ('" . $startdate . "','total','D" . $i . "R','" . number_format($data['dr'][$j][$k]['DR']) . "','" . date("Y-m-d H:i:s") . "')";

                                $db->createCommand($Drsql)->query();
                            }
                        }
                    }
                }
                $i++;
            }
        }
    }

    /**
     * 设置excel DNU
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDNU($enddate)
    {
        $sql = "select count(distinct uuid) as dnu from `ev_memu_icon_visit_first` where create_time='" . $enddate . "'";
        $DNU = Yii::$app->db->createCommand($sql)->queryAll();
        return $this->processingData($DNU, 'dnu');
    }

    /**
     * 设置excel DAU
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDAU($enddate)
    {
        $sql = "select count(distinct uuid) as dau from `ev_memu_heartbeat` where create_time='" . $enddate . "'";
        $DAU = Yii::$app->db->createCommand($sql)->queryAll();
        return $this->processingData($DAU, 'dau');
    }

    /**
     * 设置excel DRU
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDRU($enddate)
    {
        $sql = "select count(distinct uuid) as dru from `ev_heartbeat` where create_time ='" . $enddate . "' and event in('svc_heartbeat_live','heartbeat')";
        $DRU = Yii::$app->db->createCommand($sql)->queryAll();
        return $this->processingData($DRU, 'dru');
    }

    /**
     * 设置excel pageview
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setPageview($enddate)
    {
        $sql = "select count(name) as pageview from `ev_landing_report` where create_time ='" . $enddate . "' and name like '%pageview%'";
        $pageview = Yii::$app->db->createCommand($sql)->queryAll();
        return $this->processingData($pageview, 'pageview');
    }

    /**
     * 设置excel 点击事件
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDlClick($enddate)
    {
        $sql = "select count(name) as dlclick from `ev_landing_report` where create_time ='" . $enddate . "' and name in('\"dlclick\"','\"page_btn_click\"')";
        $dlclick = Yii::$app->db->createCommand($sql)->queryAll();
        return $this->processingData($dlclick, 'dlclick');
    }

    /**ev_install
     * 设置excel CTR
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setCTR($enddate)
    {
        $sql = "select event_name,count(name) as pageview from `ev_landing_report` where create_time ='" . $enddate . "' and name like '%pageview%'";
        $pageview = Yii::$app->db->createCommand($sql)->queryAll();

        $sql = "select event_name,count(name) as dlclick from `ev_landing_report` where create_time ='" . $enddate . "' and  name in('\"dlclick\"','\"page_btn_click\"')";
        $dlclick = Yii::$app->db->createCommand($sql)->queryAll();

        $dataArr['total'] = sprintf('%.2f', round(($dlclick[0]['dlclick'] / $pageview[0]['pageview'] * 100), 2)) . '%';
        return $dataArr;


    }

    /**
     * 设置excel 安装完成
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setInstallFinish($enddate)
    {
        $sql = "select count(distinct uuid) as install_finish from `ev_install` where create_time = '" . $enddate . "' and event in('install_finish','memu_install_finish')";
        $install_finish = Yii::$app->db->createCommand($sql)->queryAll();
        return $this->processingData($install_finish, 'install_finish');
    }

    /**
     * 设置excel 卸载
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setUnInstall($enddate)
    {
        $sql = "select count(distinct uuid) as uninstall from ev_install where create_time ='" . $enddate . "' and event in('uninstall','memu_uninstall')";
        $uninstall = Yii::$app->db->createCommand($sql)->queryAll();
        return $this->processingData($uninstall, 'uninstall');
    }


    private function setTodayUnInstall($enddate)
    {
        $sql = "select count(distinct a.uuid) as today_uninstall from ev_install a  inner join ev_memu_icon_visit_first b on a.uuid = b.uuid  where a.create_time ='" . $enddate . "' and a.event in('uninstall','memu_uninstall') and b.create_time='" . $enddate . "'";
        $today_uninstall = Yii::$app->db->createCommand($sql)->queryAll();
        return $this->processingData($today_uninstall, 'today_uninstall');
    }

    /**
     * 设置excel 平均运行时长
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setMemuRuntime($enddate)
    {
        $sql = "select count(*) as memu_run_times from `ev_memu_heartbeat_runtime` where create_time ='" . $enddate . "'";
        $memu_run_times = Yii::$app->db->createCommand($sql)->queryAll();
        return $this->processingData($memu_run_times, 'memu_run_times');
    }

    /**
     * 设置excel 留存
     * @param $objectPHPExcel
     * @param $startdate
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setKeepDAU($startdate, $enddate)
    {
        $day = $this->diffBetweenTwoDays($startdate, $enddate);
        $D2AArr = [];
        for ($j = 1; $j <= $day + 1; $j++) {
            //获取2016-06-20的新增用户
            $secendday = date('Y-m-d', strtotime("$startdate   +" . $j . "   day"));
            if ($secendday <= $enddate) {
                $sql = "select count(distinct a.uuid) as DA from ev_memu_heartbeat a inner join ev_memu_icon_visit_first b on a.uuid = b.uuid where a.create_time ='" . $secendday . "' and b.create_time='" . $startdate . "'";
                $D2AArr[] = Yii::$app->db->createCommand($sql)->queryAll();
            }
        }
        return $D2AArr;
    }

    /**
     * 设置excel 留存
     * @param $objectPHPExcel
     * @param $startdate
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setKeepDRU($startdate, $enddate)
    {
        $day = $this->diffBetweenTwoDays($startdate, $enddate);
        $D2RArr = [];
        for ($j = 1; $j <= $day + 1; $j++) {
            //获取2016-06-20的新增用户
            $secendday = date('Y-m-d', strtotime("$startdate   +" . $j . "   day"));
            if ($secendday <= $enddate) {
                $sql = "select count(distinct a.uuid) as DR from ev_heartbeat a inner join ev_memu_icon_visit_first b on a.uuid = b.uuid where a.create_time ='" . $secendday . "' and b.create_time='" . $startdate . "'";
                $D2RArr[] = Yii::$app->db->createCommand($sql)->queryAll();
            }
        }
        return $D2RArr;
    }

    /**
     * 处理相关数据
     * @param $data
     * @param $channel
     * @param $event
     * @return array
     */
    public function processingData($data, $event)
    {
        $dataArr = [];
        foreach ($data as $item) {
            $dataArr['total'] = $item[$event];
        }
        return $dataArr;
    }

    /**
     *
     * @param $day1
     * @param $day2
     * @return float
     */
    function diffBetweenTwoDays($day1, $day2)
    {
        $second1 = strtotime($day1);
        $second2 = strtotime($day2);

        if ($second1 < $second2) {
            $tmp = $second2;
            $second2 = $second1;
            $second1 = $tmp;
        }
        return ceil(($second1 - $second2) / 86400);
    }

    public function checkTable($event, $date)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE '" . $event . $date . "'")->queryAll();
        if (empty($ta)) {
            return 0;
        }
        return 1;
    }

}