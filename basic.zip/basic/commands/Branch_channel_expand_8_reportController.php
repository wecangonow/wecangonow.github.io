<?php
/**
 * Created by PhpStorm.
 * User: chunyu
 * Date: 16/4/6
 * Time: ����3:59
 */
 
namespace app\commands;
 
use Yii;
use yii\console\Controller;
use PHPExcel;
use PHPExcel_Style_NumberFormat;
 
 
class Branch_channel_expand_8_reportController extends Controller
{
    public $channel = ['10001', '10002', '30001', '40001', '40002', 'fb2', 'fb3', 'fb5', 'ggs'];
 
    public function actionCreateReport()
    {
 
 
        $begindate = '2016-09-10';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-09-10';
        $enddate = date("Y-m-d", strtotime("-1 days"));
 
        $day = $this->diffBetweenTwoDays($startdate, $enddate);
        $db = Yii::$app->db;
 
        $rateArr = ['churn_rate_1','churn_rate_2','churn_rate_3','churn_rate_4','churn_rate_5','churn_rate_6','churn_rate_7','churn_rate_all','churn_rate_client'];
//        for ($j = 0; $j <= $day; $j++) {
 
            $sql = "call up_data_channel_expand('" . $enddate . "')";
            //$sql = "call up_data_channel_expand('" . $startdate . "',8)";
            //$sql = "call up_data_8('2016-10-20')";
            $data = $db->createCommand($sql)->queryAll();
            foreach ($data as $item) {
                if (!empty($item['channel']) && in_array($item['channel'],$this->channel)) {
                    $rowArr = [];
                    $valArr = [];
                    foreach ($item as $key => $value) {
                        $rowArr[] = $key;
 
                        if(in_array($key,$rateArr)){
                            $valArr[] = sprintf('%.2f', round(($value * 100), 2)).'%';
                        }else{
                            $valArr[] = $value;
                        }
                    }
                    
                    $rowArr[0] = 'date';
                    $rowStr = '`' . implode("`,`", $rowArr) . '`';;
                    $valStr = '("' . implode('","', $valArr) . '")';
                    $savesql = 'insert into rp_branch_channel_expand (' . $rowStr . ') value ' . $valStr . '';
                    $db->createCommand($savesql)->query();
                }
            }
  //          $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
    //    }
 
 
        $this->createMemuBranchChannelCSV('memu_branch_channel_expand_8');
 
    }
    /**
     * ����csv�ļ�
     */
    public function createMemuBranchChannelCSV($filename)
    {
        $sql = "select * from rp_branch_channel_expand where timezone=8 order by date desc;";
        $data = Yii::$app->db->createCommand($sql)->queryAll();
        $rowArr = [];
        foreach ($data as $key => $value) {
            if ($key == 0) {
                foreach ($value as $k => $v) {
                    $rowArr[] = $k;
                }
            }
        }
        array_unshift($data, $rowArr);
        $file = fopen("./web/memu_report/" . $filename . ".csv", "w");
 
        foreach ($data as $line) {
            fputcsv($file, $line, ',');
        }
    }
    /**
     *
     * @param $day1
     * @param $day2
     * @return float
     */
    function diffBetweenTwoDays($day1, $day2)
    {
        $second1 = strtotime($day1);
        $second2 = strtotime($day2);
 
        if ($second1 < $second2) {
            $tmp = $second2;
            $second2 = $second1;
            $second1 = $tmp;
        }
        return ceil(($second1 - $second2) / 86400);
    }
 
 
}