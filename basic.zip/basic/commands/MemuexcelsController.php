<?php
/**
 * Created by PhpStorm.
 * User: chunyu
 * Date: 16/4/6
 * Time: 下午3:59
 */

namespace app\commands;

use Yii;
use yii\console\Controller;
use PHPExcel;
use PHPExcel_Style_NumberFormat;


class MemuexcelsController extends Controller
{
    public $channel = ['10001', '10002', '30001', '400br', '201br', '311br', 'fb1', 'Memu'];
    public $EN_RATE = '';

    /**
     *
     * 生成每日上报数据
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */

    public function actionOneExcel()
    {
//        $cache = Yii::$app->cache;
//        $cache->flush();
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $begindate = '2016-06-20';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-06-20';
        $date = date("Y-m-d", strtotime("-1 days"));
//        $startdate = '2016-07-25';
//        $date = '2016-07-27';
        $day = $this->diffBetweenTwoDays($startdate, $date);
        ob_end_clean();
        ob_start();
        $row = $this->setExcelRowTop();
        $EN = 'A';
        $i = 1;
        $r = 2;
        $type = 1;
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0);
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            if ($startdate <= '2016-06-21') {
                $this->channel = ['10001', '10002', '30001'];
            }
            if ($startdate > '2016-06-21' && $startdate <= '2016-06-23') {
                $this->channel = ['10001', '10002', '30001', '400br'];
            }
            if ($startdate > '2016-06-23' && $startdate <= '2016-06-26') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br'];
            }
            if ($startdate == '2016-06-27') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br', '311br'];
            }
            if ($startdate == '2016-06-28') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br', '311br', 'fb2'];
            }
            if ($startdate == '2016-06-29') {
                $this->channel = ['10001', '10002', '30001', '400br', '311br', 'fb2'];
            }
            if ($startdate > '2016-06-29' && $startdate <= '2016-07-12') {
                $this->channel = ['10001', '10002', '30001', 'fb2'];
            }
            if ($startdate > '2016-07-12' && $startdate <= '2016-07-15') {
                $this->channel = ['10001', '10002', '30001', 'fb2', 'ggs'];
            }
            if ($startdate > '2016-07-15') {
                $this->channel = ['10001', '10002', '30001', '40001', 'fb2', 'ggs'];
            }
            $num = 1;
            $this->handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type);

            $path = "./web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/Memu_R" . $startdate . ".xls";

            if (!empty($objectPHPExcel)) {
                $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
                $objWriter->save($filename);
            }
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r = $r + count($this->channel) * $num;
            $num++;
        }
        /**
         * 设置Facebook excel
         */
        $this->setFbExcel($row);

        $begindate = '2016-07-06';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-07-06';
        $date = date("Y-m-d", strtotime("-1 days"));
        if ($date >= $startdate) {
            $day = $this->diffBetweenTwoDays($startdate, $date);
            $EN = 'A';
            $i = 1;
            $r = 2;
            $type = 1;
            $this->setGgExcel($row, $EN, $i, $day, $startdate, $date, $type, $r);

        }
    }

    public function setExcelRowTop()
    {

        $row = ['DATE', '渠道'
        ];
        $j = 2;
        $k = 2;
        for ($i = 0; $i < 20; $i++) {
            if ($i > 1) {
                if ($i < 11) {
                    if ($i == 8) {
                        $row[$i] = 'D10A RATE';
                    } elseif ($i == 9) {
                        $row[$i] = 'D15A RATE';
                    } elseif ($i == 10) {
                        $row[$i] = 'D30A RATE';
                    } else {
                        $row[$i] = 'D' . $j . 'A RATE';
                    }
                    $j++;
                } else {

                    if ($i == 17) {
                        $row[$i] = 'D10R RATE';
                    } elseif ($i == 18) {
                        $row[$i] = 'D15R RATE';
                    } elseif ($i == 19) {
                        $row[$i] = 'D30R RATE';
                    } else {
                        $row[$i] = 'D' . $k . 'R RATE';
                    }
                    $k++;
                }
            }
        }
        return $row;
    }

    /**
     * 设置Facebook excel 报表
     * @param $row
     * @param $EN
     * @param $i
     * @param $day
     * @param $startdate
     * @param $date
     * @param $type
     * @param $r
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */

    public function setFbExcel($row)
    {
        $begindate = '2016-06-28';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-06-28';
        $date = date("Y-m-d", strtotime("-1 days"));
//        $date = '2016-06-22';
        $day = $this->diffBetweenTwoDays($startdate, $date);
        $EN = 'A';
        $i = 1;
        $r = 2;
        $type = 1;
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0);
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            $this->channel = ['fb2'];
            $num = 1;
            $this->handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type);
            $path = "./web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/fb_r_report" . $startdate . ".xls";
            $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
            $objWriter->save($filename);
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r++;
            $num++;
        }
    }

    /**
     *
     * 设置google search excel 报表
     * @param $row
     * @param $EN
     * @param $i
     * @param $day
     * @param $startdate
     * @param $date
     * @param $type
     * @param $r
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */
    public function setGgExcel($row, $EN, $i, $day, $startdate, $date, $type, $r)
    {
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0);
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            $this->channel = ['ggs'];
            $num = 1;
            $this->handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type);
            $path = "./web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/gg_r_report" . $startdate . ".xls";
            $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
            $objWriter->save($filename);
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r++;
            $num++;
        }

    }

    public function handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type)
    {
        //时间 A
        $this->setdate($r, $objectPHPExcel, $startdate, $type);
        //获取渠道 B
        $this->setChannel($r, $objectPHPExcel, $type);
        //以2016-06-20 开始的留存 C
        $this->setKeepDAU($r, $objectPHPExcel, $startdate, $date, $type);
        //以2016-06-20 开始的留存 D
        $this->setKeepDRU($r, $objectPHPExcel, $startdate, $date, $type);
    }

    /**
     * 设置excel 日期
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setdate($r, $objectPHPExcel, $date, $type)
    {
        $channel = $this->channel;

        $i = $r;
        $EN = 'A';
        foreach ($channel as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $date);
            $i++;
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 渠道
     * @param $objectPHPExcel
     * @param $type
     * @return mixed
     */
    private function setChannel($r, $objectPHPExcel, $type)
    {
        $channel = $this->channel;
        $i = $r;
        $EN = 'B';
        foreach ($channel as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $i++;
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 留存
     * @param $objectPHPExcel
     * @param $startdate
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setKeepDAU($r, $objectPHPExcel, $startdate, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'install_finish" . $startdate . "'")->queryAll();
        if (!empty($ta)) {
            $type == 1 ? $channel = $this->channel : $channel = ['total'];;
            $cache = Yii::$app->cache;
            $i = $r;
            $d = 0;
            foreach ($channel as $value) {
                $EN = 'C';
                $day = $this->diffBetweenTwoDays($startdate, $date);
                for ($j = 1; $j <= $day + 1; $j++) {
                    if ($j > 0 && $j < 7) {
                        $objectPHPExcel = $this->getMemuARate($objectPHPExcel, $cache, $value, $date, $startdate, $EN, $j, $i);
                        $EN++;
                    } elseif ($j == 9) {
                        $objectPHPExcel = $this->getMemuARate($objectPHPExcel, $cache, $value, $date, $startdate, $EN, $j, $i);
                        $EN++;
                    } elseif ($j == 14) {
                        $objectPHPExcel = $this->getMemuARate($objectPHPExcel, $cache, $value, $date, $startdate, $EN, $j, $i);
                        $EN++;
                    } elseif ($j == 29) {
                        $objectPHPExcel = $this->getMemuARate($objectPHPExcel, $cache, $value, $date, $startdate, $EN, $j, $i);
                        $EN++;
                    }
                }
                $i++;
            }
        }
        $this->EN_RATE = $EN;
        return $objectPHPExcel;
    }

    public function getMemuARate($objectPHPExcel, $cache, $value, $date, $startdate, $EN, $j, $i)
    {
        if ($value == '400br' || $value == '201br' || $value == '311br' || $value == 'fb1' || $value == 'Memu') {
            $sql = "select uuid as DNU from (select * from `install_finish" . $startdate . "` where `channel`='" . $value . "' and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
        } else {
            if ($startdate >= '2016-07-01') {
                $sql = "select uuid as DNU from (select * from `memu_icon_visit_first" . $startdate . "` where `channel`='" . $value . "' and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
            } else {
                $sql = "select uuid as DNU from (select * from channel where `cid`='" . $value . "' and status=1 and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
            }
        }
        if ($cache->get('Memu_RDNU' . $value . $startdate) !== false) {
            $StartDNU = $cache->get('Memu_RDNU' . $value . $startdate);
        } else {
            $StartDNU = Yii::$app->db->createCommand($sql)->queryColumn();
            $cache->set('Memu_RDNU' . $value . $startdate, $StartDNU, 0);
        }
        //获取2016-06-20的新增用户
        $secendday = date('Y-m-d', strtotime("$startdate   +" . $j . "   day"));
        if ($secendday <= $date) {
            //获取heartbeat 所有用户
            $secendsSql = "select uuid from `memu_heartbeat" . $secendday . "` group by uuid";
            if ($cache->get('Memu_Rmemu_heartbeatsecendsUser' . $secendday) !== false) {
                $secendsUser = $cache->get('Memu_Rmemu_heartbeatsecendsUser' . $secendday);
            } else {
                $secendsUser = Yii::$app->db->createCommand($secendsSql)->queryColumn();
                $cache->set('Memu_Rmemu_heartbeatsecendsUser' . $secendday, $secendsUser, 0);
            }
            $d = count(array_intersect($secendsUser, $StartDNU));
            $dnu = count($StartDNU);
            $RATE = ($d / $dnu * 100) ? sprintf('%.2f', round(($d / $dnu * 100), 2)) . '%' : '';
            if(!empty($RATE)) {
                $objectPHPExcel->getActiveSheet()->getStyle("$EN$i")->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00);
            }
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $RATE);
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 留存
     * @param $objectPHPExcel
     * @param $startdate
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setKeepDRU($r, $objectPHPExcel, $startdate, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'install_finish" . $startdate . "'")->queryAll();
        if (!empty($ta)) {
            $type == 1 ? $channel = $this->channel : $channel = ['total'];;
            $cache = Yii::$app->cache;
            $i = $r;
            $d = 0;
            foreach ($channel as $value) {
                $EN = 'L';
                $day = $this->diffBetweenTwoDays($startdate, $date);

                for ($j = 1; $j <= $day + 1; $j++) {
                    if ($j > 0 && $j < 7) {
                        $objectPHPExcel = $this->getMemuRRate($objectPHPExcel, $cache, $value, $date, $startdate, $EN, $j, $i);
                        $EN++;
                    } elseif ($j == 9) {
                        $objectPHPExcel = $this->getMemuRRate($objectPHPExcel, $cache, $value, $date, $startdate, $EN, $j, $i);
                        $EN++;
                    } elseif ($j == 14) {
                        $objectPHPExcel = $this->getMemuRRate($objectPHPExcel, $cache, $value, $date, $startdate, $EN, $j, $i);
                        $EN++;
                    } elseif ($j == 29) {
                        $objectPHPExcel = $this->getMemuRRate($objectPHPExcel, $cache, $value, $date, $startdate, $EN, $j, $i);
                        $EN++;
                    }
                }
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    public function getMemuRRate($objectPHPExcel, $cache, $value, $date, $startdate, $EN, $j, $i)
    {
        if ($value == '400br' || $value == '201br' || $value == '311br' || $value == 'fb1' || $value == 'Memu') {
            $sql = "select uuid as DNU from (select * from `install_finish" . $startdate . "` where `channel`='" . $value . "' and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
        } else {
            if ($startdate >= '2016-07-01') {
                $sql = "select uuid as DNU from (select * from `memu_icon_visit_first" . $startdate . "` where `channel`='" . $value . "' and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
            } else {
                $sql = "select uuid as DNU from (select * from channel where `cid`='" . $value . "' and status=1 and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
            }
        }
        if ($cache->get('Memu_RDNU' . $value . $startdate) !== false) {
            $StartDNU = $cache->get('Memu_RDNU' . $value . $startdate);
        } else {
            $StartDNU = Yii::$app->db->createCommand($sql)->queryColumn();
            $cache->set('Memu_RDNU' . $value . $startdate, $StartDNU, 0);
        }
        //获取2016-06-20的新增用户
        $secendday = date('Y-m-d', strtotime("$startdate   +" . $j . "   day"));
        if ($secendday <= $date) {
            //获取heartbeat 所有用户
            $secendsSql = "select uuid from `heartbeat" . $secendday . "` group by uuid";
            if ($cache->get('Memu_RheartbeatsecendsUser' . $secendday) !== false) {
                $secendsUser = $cache->get('Memu_RheartbeatsecendsUser' . $secendday);
            } else {
                $secendsUser = Yii::$app->db->createCommand($secendsSql)->queryColumn();
                $cache->set('Memu_RheartbeatsecendsUser' . $secendday, $secendsUser, 0);
            }
            $d = count(array_intersect($StartDNU, $secendsUser));

            $dnu = count($StartDNU);
            $RATE = ($d / $dnu * 100) ? sprintf('%.2f', round(($d / $dnu * 100), 2)) . '%' : '';
            if(!empty($RATE)){
                $objectPHPExcel->getActiveSheet()->getStyle("$EN$i")->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00);
            }
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $RATE);
        }
        return $objectPHPExcel;
    }

    /**
     *
     * @param $day1
     * @param $day2
     * @return float
     */
    function diffBetweenTwoDays($day1, $day2)
    {
        $second1 = strtotime($day1);
        $second2 = strtotime($day2);

        if ($second1 < $second2) {
            $tmp = $second2;
            $second2 = $second1;
            $second1 = $tmp;
        }
        return ceil(($second1 - $second2) / 86400);
    }

    public function checkTable($event, $date)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE '" . $event . $date . "'")->queryAll();
        if (empty($ta)) {
            return 0;
        }
        return 1;
    }

}