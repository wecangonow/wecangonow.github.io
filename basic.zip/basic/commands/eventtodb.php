<?php

ini_set('memory_limit', '256M');
define('URL', 'http://bg.upcleaner.net/api2/upevent');
define('PATH', '/tmp/eventdata/');



class Lzo
{
    public $event = '';
    public $date = '';

    public $data = [];
    public $browser= [];
    public $dau = 0;

    public function __construct($event, $date) {

        if (!file_exists('json'))
        {
            mkdir('json', 0777, recursive);
        }
        $this->event = $event;
        $this->date  = $date;
        $this->opendir();
    }

    public function opendir($dir = '') {

        if (!$dir)
        {
            $dir = PATH . $this->event . '/' . $this->date . '/';
        }
        $list = scandir($dir);
        if(empty($list)) {
            echo 'no data';die;
        }
        $list = $this->arrfilter($list);
        foreach ($list as $val)
        {

            if (is_dir($dir . $val))
            {
                echo $dir . $val . '/' . "\n";
                $this->opendir($dir . $val . '/');
            }
            else
            {

                $this->read($dir . $val);
            }
        }
    }

    public function read($file) {

        $this->dau += 1;

        $txt = file_get_contents($file);
        $con = explode("\n", $txt);

        $keys = [];
        array_pop($arr);
        foreach ($con as $k => $va)
        {
            $row = explode(",", $va);
            if ($k == 0)
            {
                $keys = $row;
                continue;
            }
            $row = array_combine($keys, $row);

            switch ($this->event)
            {

                case 'QuickLnk':
                    $this->data[$row['descript']] += 1;
                    break;
                case 'HomePage':
                    $this->browser[$row['browser']] += 1;
                    $this->data[$row['homepage']] += 1;
                    break;
                default:
                    $this->data[$row['softname']] += 1;
                    break;
            }

        }
    }

    public function savetofile() {


        $this->data = array_filter($this->data, function ($var) {
            return ($var > 100 ? true : false);
        });
        arsort($this->data);

        $data = ['event' => $this->event, 'date' => $this->date, 'dau' => $this->dau, 'data' => $this->data];

        $json     = json_encode($data);
        $filename = 'json/' . $this->event . $this->date . '.json';
        file_put_contents($filename, $json);
        $this->send($filename);


        if (!empty($this->browser))
        {

            $this->browser = array_filter($this->browser, function ($var) {
                return ($var > 100 ? true : false);
            });
            $data = ['event' => 'browser', 'date' => $this->date, 'dau' => $this->dau, 'data' => $this->browser];
            arsort($this->browser);
            $json     = json_encode($data);
            $filename = 'json/' . $this->event .'browser'. $this->date . '.json';
            file_put_contents($filename, $json);
            $this->send($filename);

        }
    }

    /**
     * @param $arr
     *
     * @return array
     * 删除空目录
     */
    function arrfilter($arr) {

        return $data = array_filter($arr, function ($var)
        {

            return (in_array($var, ['.', '..']) ? false : true);
        });
    }

    function send($file) {

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_VERBOSE, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible;)");
        curl_setopt($ch, CURLOPT_URL, URL);
        curl_setopt($ch, CURLOPT_POST, true);
        $post = array(
            "event" => $this->event,
            "date"  => $this->date,
            "file"  => "@" . $file,
            "token"=>md5($this->event.$this->date.'luguo')
        );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        $response = curl_exec($ch);
        print_r($response);
        echo "\n";

    }
}

$stime = time();


 $sdate=$argv[1];
  $date =date('Ymd',strtotime("-1 day"));

echo $date=$sdate?$sdate:$date;

if(!$date) exit;

$arr  = ['AutoRun', 'InstSoftware', 'QuickLnk', 'HomePage'];
foreach ($arr as $val)
{
    $lzo = new Lzo($val, $date);
    $lzo->savetofile();
}

echo $time = time() - $stime;


?>



