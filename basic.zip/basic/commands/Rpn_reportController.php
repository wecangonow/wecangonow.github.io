<?php
/**
 * Created by PhpStorm.
 * User: chunyu
 * Date: 16/4/6
 * Time: 衔3:59
 */

namespace app\commands;

use Yii;
use yii\base\ErrorException;
use yii\console\Controller;
use PHPExcel;
use PHPExcel_Style_NumberFormat;


class Rpn_reportController extends Controller
{
    public function actionCreateReport()
    {
        $begindate = '2016-09-10';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-09-10';
        $enddate = date("Y-m-d", strtotime("-1 days"));

        $db = Yii::$app->db;

        $sql_addchannel ="insert into ev_channel(channel,total,enabled) select distinct channel,'total',true from ev_memu_heartbeat  where create_time='".$enddate."' and channel not in(select distinct channel from ev_channel)";
        $db->createCommand($sql_addchannel)->query();


        $sql_addchannel1 ="insert into ev_channel(channel,total,enabled) select distinct channel,'total',true from ev_heartbeat  where create_time='".$enddate."' and channel not in(select distinct channel from ev_channel)";
        $db->createCommand($sql_addchannel)->query();


        $sql_addchannel2 ="insert into ev_channel(channel,total,enabled) select distinct channel,'total',true from ev_install  where create_time='".$enddate."' and channel not in(select distinct channel from ev_channel)";
        $db->createCommand($sql_addchannel2)->query();

        $sql = "call up_total_core('" . $enddate . "');";
        $db->createCommand($sql)->queryAll();

        $sql_total = "call up_channel_total('" . $enddate . "','total');";
        $db->createCommand($sql_total)->queryAll();

        $sql_channel = "select distinct channel from ev_channel where channel not in('','total') ;";
        $data_channel = $db->createCommand($sql_channel)->queryAll();

        foreach ($data_channel as $key => $value) {
            $sql_up_channel = "call up_channel_c('".$enddate."','".$value['channel']."');";
            $db->createCommand($sql_up_channel)->queryAll();
        }


        $this->createCoreCSV('rpn_core');
        $this->createChannel30CSV('rpn_channel_30',$startdate,$enddate);

        $this->createChannelCSV('rpn_channel',$startdate,$enddate);
    }

    /**
     * ?蓅vμ?
     */
    public function createCoreCSV($filename)
    {
        $sql = " select `date` ,dau ,dru ,dnu ,ifnull(d2a/dnu,0) as `d2a/dnu`,ifnull(d2r/dnu,0) as `d2r/dnu`, today_uninstall/dnu as `nuu/dnu`,svclive from rpn_total_core order by date asc";
        $data = Yii::$app->db->createCommand($sql)->queryAll();
        $rowArr = [];
        foreach ($data as $key => $value) {
            if ($key == 0) {
                foreach ($value as $k => $v) {
                    $rowArr[] = $k;
                }
            }
        }
        array_unshift($data, $rowArr);
        $file = fopen("./web/memu_report/" . $filename . ".csv", "w");

        foreach ($data as $line) {
            fputcsv($file, $line, ',');
        }
    }
    /**
     * ?蓅vμ?
     */
    public function createChannel30CSV($filename,$startdate,$enddate)
    {

        $rowArr = [];
        $data = [] ;
        $sql_channel = "select distinct channel from ev_channel where channel not in('')";
        $data_channel = Yii::$app->db->createCommand($sql_channel)->queryAll();


        $day = $this->diffBetweenTwoDays($startdate, $enddate);
        //  print_r($day) ;
        for ($j = 0; $j < $day + 1; $j++) {

            $secendday = date('Y-m-d', strtotime("$startdate   +" . $j . "   day"));
            foreach ($data_channel as $key => $value) {
                $sql_data = "select a.date,a.channel,a.dau,a.dru,a.dnu,a.today_uninstall as uninstall_newuser,a.uninstall,a.start_success,a.icon_visit,a.multi_icon_visit,a.install,a.install_finish,a.dl_finish,a.dl_start,a.dumpcount,a.dumpuser,a.pageview,a.dlclick,
a.dl_mini_start,a.memu_run_time,
b.d2a,b.d2r,b.d3a,b.d3r,b.d4a,b.d4r,b.d5a,b.d5r,b.d6a,b.d6r,b.d7a,b.d7r,b.d8a,b.d8r,b.d9a,b.d9r,b.d10a,b.d10r,b.d11a,b.d11r,b.d12a,b.d12r,b.d13a,b.d13r,
b.d14a,b.d14r,b.d15a,b.d15r,b.d16a,b.d16r,b.d17a,b.d17r,b.d18a,b.d18r,b.d19a,b.d19r,b.d20a,b.d20r,b.d21a,b.d21r,b.d22a,b.d22r,b.d23a,b.d23r,b.d24a,b.d24r,
b.d25a,b.d25r,b.d26a,b.d26r,b.d27a,b.d27r,b.d28a,b.d28r,b.d29a,b.d29r,b.d30a,b.d30r from rpn_channel a left join (
SELECT date ,SUM(IF(`key`='d2a',value,0)) AS 'd2a',SUM(IF(`key`='d2r',value,0)) AS 'd2r' ,SUM(IF(`key`='d3a',value,0)) AS 'd3a',SUM(IF(`key`='d3r',value,0)) AS 'd3r' ,
SUM(IF(`key`='d4a',value,0)) AS 'd4a',SUM(IF(`key`='d4r',value,0)) AS 'd4r',SUM(IF(`key`='d5a',value,0)) AS 'd5a',SUM(IF(`key`='d5r',value,0)) AS 'd5r',
SUM(IF(`key`='d6a',value,0)) AS 'd6a',SUM(IF(`key`='d6r',value,0)) AS 'd6r',SUM(IF(`key`='d7a',value,0)) AS 'd7a',SUM(IF(`key`='d7r',value,0)) AS 'd7r' ,
SUM(IF(`key`='d8a',value,0)) AS 'd8a',SUM(IF(`key`='d8r',value,0)) AS 'd8r',SUM(IF(`key`='d9a',value,0)) AS 'd9a',SUM(IF(`key`='d9r',value,0)) AS 'd9r',
SUM(IF(`key`='d10a',value,0)) AS 'd10a',SUM(IF(`key`='d10r',value,0)) AS 'd10r' ,SUM(IF(`key`='d11a',value,0)) AS 'd11a',SUM(IF(`key`='d11r',value,0)) AS 'd11r',
SUM(IF(`key`='d12a',value,0)) AS 'd12a',SUM(IF(`key`='d12r',value,0)) AS 'd12r',SUM(IF(`key`='d13a',value,0)) AS 'd13a',SUM(IF(`key`='d13r',value,0)) AS 'd13r',
SUM(IF(`key`='d14a',value,0)) AS 'd14a',SUM(IF(`key`='d14r',value,0)) AS 'd14r',SUM(IF(`key`='d15a',value,0)) AS 'd15a',SUM(IF(`key`='d15r',value,0)) AS 'd15r' ,
SUM(IF(`key`='d16a',value,0)) AS 'd16a',SUM(IF(`key`='d16r',value,0)) AS 'd16r',SUM(IF(`key`='d17a',value,0)) AS 'd17a',SUM(IF(`key`='d17r',value,0)) AS 'd17r' ,
SUM(IF(`key`='d18a',value,0)) AS 'd18a',SUM(IF(`key`='d18r',value,0)) AS 'd18r',SUM(IF(`key`='d19a',value,0)) AS 'd19a',SUM(IF(`key`='d19r',value,0)) AS 'd19r',
SUM(IF(`key`='d20a',value,0)) AS 'd20a',SUM(IF(`key`='d20r',value,0)) AS 'd20r',SUM(IF(`key`='d21a',value,0)) AS 'd21a',SUM(IF(`key`='d21r',value,0)) AS 'd21r',
SUM(IF(`key`='d22a',value,0)) AS 'd22a',SUM(IF(`key`='d22r',value,0)) AS 'd22r',SUM(IF(`key`='d23a',value,0)) AS 'd23a',SUM(IF(`key`='d23r',value,0)) AS 'd23r',
SUM(IF(`key`='d24a',value,0)) AS 'd24a',SUM(IF(`key`='d24r',value,0)) AS 'd24r',SUM(IF(`key`='d25a',value,0)) AS 'd25a',SUM(IF(`key`='d25r',value,0)) AS 'd25r',
SUM(IF(`key`='d26a',value,0)) AS 'd26a',SUM(IF(`key`='d26r',value,0)) AS 'd26r',SUM(IF(`key`='d27a',value,0)) AS 'd27a',SUM(IF(`key`='d27r',value,0)) AS 'd27r' ,
SUM(IF(`key`='d28a',value,0)) AS 'd28a',SUM(IF(`key`='d28r',value,0)) AS 'd28r',SUM(IF(`key`='d29a',value,0)) AS 'd29a',SUM(IF(`key`='d29r',value,0)) AS 'd29r',
SUM(IF(`key`='d30a',value,0)) AS 'd30a',SUM(IF(`key`='d30r',value,0)) AS 'd30r' FROM rpn_channel_sync where channel='".$value['channel']."' and date='".$secendday."')
as b on a.date =b.date where a.date='".$secendday."' and a.channel='".$value['channel']."'";
                $data_inner = Yii::$app->db->createCommand($sql_data)->queryAll();

                if(count( $rowArr) ==0){
                    foreach ($data_inner as $key2 => $value2) {
                        if ($key2 == 0) {
                            foreach ($value2 as $k => $v) {
                                $rowArr[] = $k;
                            }
                        }
                    }
                }
                $rowArr1 = [];
                foreach ($data_inner as $key1 => $value1) {
                    if ($key1 == 0) {
                        foreach ($value1 as $k => $v) {
                            $rowArr1[] = $v;
                        }
                    }
                }
                //构詇eader
                if(count($rowArr1)>0){
                    array_push($data, $rowArr1);
                }

                //array_push($data, $data_inner);
            }

        }

        //构詇eader
        array_unshift($data, $rowArr);
        //  print_r($data);
        $file = fopen("./web/memu_report/" . $filename . ".csv", "w");

        foreach ($data as $line) {
            fputcsv($file, $line, ',');
        }
    }


    public function createChannelCSV($filename,$startdate,$enddate)
    {

        $rowArr = [];
        $data = [] ;
        $sql_channel = "select distinct channel from ev_channel where channel not in('')";
        $data_channel = Yii::$app->db->createCommand($sql_channel)->queryAll();


        $day = $this->diffBetweenTwoDays($startdate, $enddate);
        //  print_r($day) ;
        for ($j = 0; $j < $day + 1; $j++) {

            $secendday = date('Y-m-d', strtotime("$startdate   +" . $j . "   day"));
            foreach ($data_channel as $key => $value) {
                $sql_data = "select a.date,a.channel,a.dau,a.dru,a.dnu,  truncate(ifnull(b.d2a/a.dnu,0),2) as 'd2a/dnu', truncate(ifnull(b.d2r/a.dnu,0),2) as 'd2r/dnu',
truncate(ifnull(a.today_uninstall/a.dnu,0),2) as 'nuu/dnu',
 truncate(ifnull((a.dl_visit-a.icon_visit_first)/a.dl_visit,0),2) as 'all_lose', truncate(ifnull((1-a.start_success/icon_visit_ex),0),2) as 'start_faild_rate',
  truncate(ifnull(a.install_finish/a.install,0),2) as 'install_success_rate',a.dl_visit,
a.dlclick,a.pageview from rpn_channel a left join (
SELECT date ,SUM(IF(`key`='d2a',value,0)) AS 'd2a',SUM(IF(`key`='d2r',value,0)) AS 'd2r'
 FROM rpn_channel_sync where  channel='".$value['channel']."' and date='".$secendday."')
as b on a.date =b.date where  a.date='".$secendday."' and a.channel='".$value['channel']."';";
                $data_inner = Yii::$app->db->createCommand($sql_data)->queryAll();

                if(count( $rowArr) ==0){
                    foreach ($data_inner as $key2 => $value2) {
                        if ($key2 == 0) {
                            foreach ($value2 as $k => $v) {
                                $rowArr[] = $k;
                            }
                        }
                    }
                }
                $rowArr1 = [];
                foreach ($data_inner as $key1 => $value1) {
                    if ($key1 == 0) {
                        foreach ($value1 as $k => $v) {
                            $rowArr1[] = $v;
                        }
                    }
                }
                //构詇eader
                if(count($rowArr1)>0){
                    array_push($data, $rowArr1);
                }

                //array_push($data, $data_inner);
            }

        }

        //构詇eader
        array_unshift($data, $rowArr);
        //  print_r($data);
        $file = fopen("./web/memu_report/" . $filename . ".csv", "w");

        foreach ($data as $line) {
            fputcsv($file, $line, ',');
        }
    }
    /**
     *
     * @param $day1
     * @param $day2
     * @return float
     */
    function diffBetweenTwoDays($day1, $day2)
    {
        $second1 = strtotime($day1);
        $second2 = strtotime($day2);

        if ($second1 < $second2) {
            $tmp = $second2;
            $second2 = $second1;
            $second1 = $tmp;
        }
        return ceil(($second1 - $second2) / 86400);
    }


}