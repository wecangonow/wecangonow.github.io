<?php
/**
 * Created by PhpStorm.
 * User: chunyu
 * Date: 16/4/6
 * Time: 下午3:59
 */

namespace app\commands;

use Yii;
use yii\console\Controller;
use PHPExcel;
use PHPExcel_Style_NumberFormat;


class ExcelsController extends Controller
{
    public $channel = ['10001', '10002', '30001', '400br', '201br', '311br', 'fb1', 'Memu'];

    /**
     *
     * 生成每日上报数据
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */

    public function actionOneExcel()
    {
//        $cache = Yii::$app->cache;
//        $cache->flush();
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $begindate = '2016-06-20';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-06-20';
        $date = date("Y-m-d", strtotime("-1 days"));
//        $date = '2016-06-25';
        $day = $this->diffBetweenTwoDays($startdate, $date);
        ob_end_clean();
        ob_start();
        $row = $this->setExcelRowTop();
        $EN = 'A';
        $i = 1;
        $r = 2;
        $type = 1;
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0);
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            if ($startdate <= '2016-06-21') {
                $this->channel = ['10001', '10002', '30001'];
            }
            if ($startdate > '2016-06-21' && $startdate <= '2016-06-23') {
                $this->channel = ['10001', '10002', '30001', '400br'];
            }
            if ($startdate > '2016-06-23' && $startdate <= '2016-06-26') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br'];
            }
            if ($startdate == '2016-06-27') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br', '311br'];
            }
            if ($startdate == '2016-06-28') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br', '311br', 'fb2'];
            }
            if ($startdate == '2016-06-29') {
                $this->channel = ['10001', '10002', '30001', '400br', '311br', 'fb2'];
            }
            if ($startdate > '2016-06-29' && $startdate <= '2016-07-12') {
                $this->channel = ['10001', '10002', '30001', 'fb2'];
            }
            if ($startdate > '2016-07-12' && $startdate <= '2016-07-15') {
                $this->channel = ['10001', '10002', '30001', 'fb2', 'ggs'];
            }
            if ($startdate > '2016-07-15') {
                $this->channel = ['10001', '10002', '30001', '40001', 'fb2', 'ggs'];
            }
            if ($startdate > '2016-08-30') {
                $this->channel = ['10001', '10002', '30001', '40001', '40002', 'fb2', 'fb3', 'ggs'];
            }
            if ($startdate > '2016-08-31') {
                $this->channel = ['10001', '10002', '30001', '40001', '40002', 'fb2', 'fb3','fb5', 'ggs'];
            }
            $num = 1;
            $this->handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type);

            $path = "./web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/Memu" . $startdate . ".xls";
            if (!empty($objectPHPExcel)) {
                $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
                $objWriter->save($filename);
            }
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r = $r + count($this->channel) * $num;
            $num++;
        }
        /**
         * 设置Facebook excel
         */
        $this->setFbExcel($row);
        $this->setFb3Excel($row);
        $this->setFb5Excel($row);

        $begindate = '2016-07-06';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-07-06';
        $date = date("Y-m-d", strtotime("-1 days"));
        if ($date >= $startdate) {
            $day = $this->diffBetweenTwoDays($startdate, $date);
            $EN = 'A';
            $i = 1;
            $r = 2;
            $type = 1;
            $this->setGgExcel($row, $EN, $i, $day, $startdate, $date, $type, $r);

        }
    }

    public function setExcelRowTop()
    {

        $row = ['DATE', '渠道', 'DNU', 'DAU', 'DRU', 'Pageview', 'Click', 'CTR', 'Install_finish', '卸载', '今日卸载', '平均运行时长(h)',
            'D2A', 'D2R',
            'D3A', 'D3R',
            'D4A', 'D4R',
            'D5A', 'D5R',
            'D6A', 'D6R',
            'D7A', 'D7R',
            'D8A', 'D8R',
            'D9A', 'D9R',
            'D10A', 'D10R',
            'D11A', 'D11R',
            'D12A', 'D12R',
            'D13A', 'D13R',
            'D14A', 'D14R',
            'D15A', 'D15R',
            'D16A', 'D16R',
            'D17A', 'D17R',
            'D18A', 'D18R',
            'D19A', 'D19R',
            'D20A', 'D20R',
            'D21A', 'D21R',
            'D22A', 'D22R',
            'D23A', 'D23R',
            'D24A', 'D24R',
            'D25A', 'D25R',
            'D26A', 'D26R',
            'D27A', 'D27R',
            'D28A', 'D28R',
            'D29A', 'D29R',
            'D30A', 'D30R',
        ];
        $j = 2;
        for ($i = 0; $i < 200; $i++) {
            if ($i > 11) {
                if ($i % 2 == 0) {
                    $row[$i] = 'D' . $j . 'A';
                } else {
                    $row[$i] = 'D' . $j . 'R';
                    $j++;
                }
            }
        }
        return $row;
    }

    /**
     * 设置Facebook excel 报表
     * @param $row
     * @param $EN
     * @param $i
     * @param $day
     * @param $startdate
     * @param $date
     * @param $type
     * @param $r
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */

    public function setFbExcel($row)
    {
        $begindate = '2016-06-28';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-06-28';
        $date = date("Y-m-d", strtotime("-1 days"));
//        $date = '2016-06-22';
        $day = $this->diffBetweenTwoDays($startdate, $date);
        $EN = 'A';
        $i = 1;
        $r = 2;
        $type = 1;
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0);
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            $this->channel = ['fb2'];
            $num = 1;
            $this->handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type);
            $path = "./web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/fb_report" . $startdate . ".xls";
            $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
            $objWriter->save($filename);
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r++;
            $num++;
        }
    }

    /**
     * 设置Facebook excel 报表
     * @param $row
     * @param $EN
     * @param $i
     * @param $day
     * @param $startdate
     * @param $date
     * @param $type
     * @param $r
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */

    public function setFb3Excel($row)
    {
        $begindate = '2016-08-31';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-08-31';
        $date = date("Y-m-d", strtotime("-1 days"));
//        $date = '2016-06-22';
        $day = $this->diffBetweenTwoDays($startdate, $date);
        $EN = 'A';
        $i = 1;
        $r = 2;
        $type = 1;
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0);
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            $this->channel = ['fb3'];
            $num = 1;
            $this->handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type);
            $path = "./web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/fb3_report" . $startdate . ".xls";
            $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
            $objWriter->save($filename);
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r++;
            $num++;
        }
    }

    /**
     * 设置Facebook excel 报表
     * @param $row
     * @param $EN
     * @param $i
     * @param $day
     * @param $startdate
     * @param $date
     * @param $type
     * @param $r
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */

    public function setFb5Excel($row)
    {
        $begindate = '2016-08-31';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-08-31';
        $date = date("Y-m-d", strtotime("-1 days"));
//        $date = '2016-06-22';
        $day = $this->diffBetweenTwoDays($startdate, $date);
        $EN = 'A';
        $i = 1;
        $r = 2;
        $type = 1;
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0);
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            $this->channel = ['fb5'];
            $num = 1;
            $this->handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type);
            $path = "./web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/fb5_report" . $startdate . ".xls";
            $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
            $objWriter->save($filename);
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r++;
            $num++;
        }
    }
    /**
     *
     * 设置google search excel 报表
     * @param $row
     * @param $EN
     * @param $i
     * @param $day
     * @param $startdate
     * @param $date
     * @param $type
     * @param $r
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */
    public function setGgExcel($row, $EN, $i, $day, $startdate, $date, $type, $r)
    {
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0);
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            $this->channel = ['ggs'];
            $num = 1;
            $this->handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type);
            $path = "./web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/gg_report" . $startdate . ".xls";
            $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
            $objWriter->save($filename);
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r++;
            $num++;
        }

    }

    public function handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type)
    {
        //时间 A
        $this->setdate($r, $objectPHPExcel, $startdate, $type);
        //获取渠道 B
        $this->setChannel($r, $objectPHPExcel, $type);
        //获取DNU C
        $this->setDNU($r, $objectPHPExcel, $startdate, $type);
        //获取DAU D
        $this->setDAU($r, $objectPHPExcel, $startdate, $type);
        //获取DRU E
        $this->setDRU($r, $objectPHPExcel, $startdate, $type);
        //pageview F
        $this->setPageview($r, $objectPHPExcel, $startdate, $type);
        //获取click G
        $this->setDlClick($r, $objectPHPExcel, $startdate, $type);
        //获取click H
        $this->setCTR($r, $objectPHPExcel, $startdate, $type);
        //获取install_finish I
        $this->setInstallFinish($r, $objectPHPExcel, $startdate, $type);
        //获取卸载 J
        $this->setUnInstall($r, $objectPHPExcel, $startdate, $type);
        //获取卸载 K
        $this->setTodayUnInstall($r, $objectPHPExcel, $startdate, $type);
        //获取卸载 L
        $this->setMemuRuntime($r, $objectPHPExcel, $startdate, $type);
        //以2016-06-20 开始的留存 M
        $this->setKeepDAU($r, $objectPHPExcel, $startdate, $date, $type);
        //以2016-06-20 开始的留存 N
        $this->setKeepDRU($r, $objectPHPExcel, $startdate, $date, $type);
    }

    /**
     * 设置excel 日期
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setdate($r, $objectPHPExcel, $date, $type)
    {
        $channel = $this->channel;

        $i = $r;
        $EN = 'A';
        foreach ($channel as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $date);
            $i++;
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 渠道
     * @param $objectPHPExcel
     * @param $type
     * @return mixed
     */
    private function setChannel($r, $objectPHPExcel, $type)
    {
        $channel = $this->channel;
        $i = $r;
        $EN = 'B';
        foreach ($channel as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $i++;
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel DNU
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDNU($r, $objectPHPExcel, $date, $type)
    {
        $channel = $this->channel;
        $cache = Yii::$app->cache;
        $i = $r;
        $EN = 'C';

        $ta2 = Yii::$app->db->createCommand("SHOW TABLES LIKE 'install_finish" . $date . "'")->queryAll();
        if (!empty($ta2)) {
            foreach ($channel as $value) {
                if (($value == '400br' || $value == '201br' || $value == '311br' || $value == 'fb1' || $value == 'Memu') && $date < '2016-07-01') {
                    $sql = "select count(*) as DNU from (select * from `install_finish" . $date . "` where `channel`='" . $value . "' and uuid!='' and create_time like '%" . $date . "%' group by uuid) as table1";
                    if ($cache->get('quiteDNU' . $value . $date) !== false) {
                        $DNU = $cache->get('quiteDNU' . $value . $date);
                    } else {
                        $DNU = Yii::$app->db->createCommand($sql)->queryOne();
                        $cache->set('quiteDNU' . $value . $date, $DNU, 0);
                    }
                } else {
                    if ($date >= '2016-07-01') {
                        $sql = "select count(*) as DNU from (select * from `memu_icon_visit_first" . $date . "` where `channel`='" . $value . "' and uuid!='' and create_time like '%" . $date . "%' group by uuid) as table1";
                    } else {
                        $sql = "select count(*) as DNU from (select * from channel where `cid`='" . $value . "' and status=1 and uuid!='' and create_time like '%" . $date . "%' group by uuid) as table1";
                    }
                    if ($cache->get('dnu' . $value . $date) !== false) {
                        $DNU = $cache->get('dnu' . $value . $date);
                    } else {
                        $DNU = Yii::$app->db->createCommand($sql)->queryOne();
                        $cache->set('dnu' . $value . $date, $DNU, 0);
                    }
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $DNU['DNU'] ? number_format($DNU['DNU']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel DAU
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDAU($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'memu_heartbeat" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $channel = $this->channel;
            $cache = Yii::$app->cache;
            $i = $r;
            $EN = 'D';
            foreach ($channel as $value) {
                $sql = "select count(*) as memu_heartbeat from (select * from `memu_heartbeat" . $date . "` where `channel`='" . $value . "' and uuid!='' group by uuid) as table1";
                if ($cache->get('memu_heartbeat' . $value . $date) !== false) {
                    $memu_heartbeat = $cache->get('memu_heartbeat' . $value . $date);
                } else {
                    $memu_heartbeat = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('memu_heartbeat' . $value . $date, $memu_heartbeat, 0);
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $memu_heartbeat['memu_heartbeat'] ? number_format($memu_heartbeat['memu_heartbeat']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel DRU
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDRU($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'heartbeat" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $channel = $this->channel;
            $cache = Yii::$app->cache;
            $i = $r;
            $EN = 'E';
            foreach ($channel as $value) {
                $sql = "select count(*) as `heartbeat` from (select * from `heartbeat" . $date . "` where `channel`='" . $value . "' group by uuid) as table1";
                if ($cache->get('heartbeat' . $value . $date) !== false) {
                    $heartbeat = $cache->get('heartbeat' . $value . $date);
                } else {
                    $heartbeat = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('heartbeat' . $value . $date, $heartbeat, 0);
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $heartbeat['heartbeat'] ? number_format($heartbeat['heartbeat']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel pageview
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setPageview($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'landing_report" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $cache = Yii::$app->cache;
            $channel = $this->channel;
            $i = $r;
            $EN = 'F';
            foreach ($channel as $value) {
                $sql = "select count(*) as Pageview from (select * from `landing_report" . $date . "` where `event_name`='" . $value . "' and name like '%pageview%' group by uuid) as table1";
                if ($cache->get('pageview' . $value . $date) !== false) {
                    $Pageview = $cache->get('pageview' . $value . $date);
                } else {
                    $Pageview = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('pageview' . $value . $date, $Pageview, 0);
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $Pageview['Pageview'] ? number_format($Pageview['Pageview']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 点击事件
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDlClick($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'landing_report" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $cache = Yii::$app->cache;
            $channel = $this->channel;
            $i = $r;
            $EN = 'G';
            foreach ($channel as $value) {
                $sql = "select count(*) as dlclick from (select * from `landing_report" . $date . "` where `event_name`='" . $value . "' and name like '%dlclick%' group by uuid) as table1";
                if ($cache->get('dlclick' . $value . $date) !== false) {
                    $dlclick = $cache->get('dlclick' . $value . $date);
                } else {
                    $dlclick = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('dlclick' . $value . $date, $dlclick, 0);
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $dlclick['dlclick'] ? number_format($dlclick['dlclick']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel CTR
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setCTR($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'landing_report" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $cache = Yii::$app->cache;
            $channel = $this->channel;
            $i = $r;
            $EN = 'H';
            foreach ($channel as $value) {
                $sql = "select count(*) as dlclick from (select * from `landing_report" . $date . "` where `event_name`='" . $value . "' and name like '%dlclick%' group by uuid) as table1";
                if ($cache->get('dlclick' . $value . $date) !== false) {
                    $dlclick = $cache->get('dlclick' . $value . $date);
                } else {
                    $dlclick = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('dlclick' . $value . $date, $dlclick, 0);
                }
                $sql = "select count(*) as Pageview from (select * from `landing_report" . $date . "` where `event_name`='" . $value . "' and name like '%pageview%' group by uuid) as table1";
                if ($cache->get('pageview' . $value . $date) !== false) {
                    $Pageview = $cache->get('pageview' . $value . $date);
                } else {
                    $Pageview = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('pageview' . $value . $date, $Pageview, 0);
                }
                $CTR = ($dlclick['dlclick'] / $Pageview['Pageview'] * 100) ? sprintf('%.2f', round(($dlclick['dlclick'] / $Pageview['Pageview'] * 100), 2)) . '%' : 0;
                $objectPHPExcel->getActiveSheet()->getStyle("$EN$i")->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00);
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $CTR ? $CTR : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 安装完成
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setInstallFinish($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'install_finish" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $cache = Yii::$app->cache;
            $channel = $this->channel;
            $i = $r;
            $EN = 'I';
            foreach ($channel as $value) {
                $sql = "select count(*) as install_finish from (select * from `install_finish" . $date . "` where `channel`='" . $value . "' and uuid!='' group by uuid) as table1";

                if ($cache->get('install_finish' . $value . $date) !== false) {
                    $install_finish = $cache->get('install_finish' . $value . $date);
                } else {
                    $install_finish = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('install_finish' . $value . $date, $install_finish, 0);
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $install_finish['install_finish'] ? number_format($install_finish['install_finish']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 卸载
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setUnInstall($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'uninstall" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $channel = $this->channel;
            $cache = Yii::$app->cache;
            $i = $r;
            $EN = 'J';
            foreach ($channel as $value) {
                $sql = "select count(*) as uninstall from (select * from `uninstall" . $date . "` where `channel`='" . $value . "' group by uuid) as table1;";
                if ($cache->get('uninstall' . $value . $date) !== false) {
                    $uninstall = $cache->get('uninstall' . $value . $date);
                } else {
                    $uninstall = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('uninstall' . $value . $date, $uninstall, 0);
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $uninstall['uninstall'] ? number_format($uninstall['uninstall']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }


    private function setTodayUnInstall($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'uninstall" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $channel = $this->channel;
            $cache = Yii::$app->cache;
            $i = $r;
            $EN = 'K';
            foreach ($channel as $value) {

                $cache->set('uninstallUserList' . $value . $date, false, -1);
                $cache->set('quiteDNUList' . $value . $date, false, -1);
                $cache->set('dnulist' . $value . $date, false, -1);
                $sql = "select uuid from (select uuid from `uninstall" . $date . "` where `channel`='" . $value . "' and uuid!='' group by uuid) as table1;";
                if ($cache->get('uninstallUserList' . $value . $date) !== false) {
                    $uninstallUserList = $cache->get('uninstallUserList' . $value . $date);
                } else {
                    $uninstallUserList = Yii::$app->db->createCommand($sql)->queryColumn();
                    $cache->set('uninstallUserList' . $value . $date, $uninstallUserList, 0);
                }
                //DNU
                if (($value == '400br' || $value == '201br' || $value == '311br' || $value == 'fb1' || $value == 'Memu') && $date < '2016-07-01') {
                    $sql = "select uuid from (select uuid from `install_finish" . $date . "` where `channel`='" . $value . "' and uuid!='' and create_time like '%" . $date . "%' group by uuid) as table1";
                    if ($cache->get('quiteDNUList' . $value . $date) !== false) {
                        $DNUList = $cache->get('quiteDNUList' . $value . $date);
                    } else {
                        $DNUList = Yii::$app->db->createCommand($sql)->queryColumn();
                        $cache->set('quiteDNUList' . $value . $date, $DNUList, 0);
                    }
                } else {
                    if ($date >= '2016-07-01') {
                        $sql = "select uuid from (select uuid from `memu_icon_visit_first" . $date . "` where `channel`='" . $value . "' and uuid!='' and create_time like '%" . $date . "%' group by uuid) as table1";
                    } else {
                        $sql = "select uuid from (select uuid from channel where `cid`='" . $value . "' and status=1 and uuid!='' and create_time like '%" . $date . "%' group by uuid) as table1";
                    }
                    if ($cache->get('dnulist' . $value . $date) !== false) {
                        $DNUList = $cache->get('dnulist' . $value . $date);
                    } else {
                        $DNUList = Yii::$app->db->createCommand($sql)->queryColumn();
                        $cache->set('dnulist' . $value . $date, $DNUList, 0);
                    }
                }
                $todayUninstallList = array_intersect($DNUList, $uninstallUserList);
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", count($todayUninstallList) ? number_format(count($todayUninstallList)) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }
    /**
     * 设置excel 平均运行时长
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setMemuRuntime($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'uninstall" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $channel = $this->channel;
            $cache = Yii::$app->cache;
            $i = $r;
            $EN = 'L';
            foreach ($channel as $value) {
                $data = file_get_contents('http://api.simcake.com/report/memu_run_time/' . $date . '/memu_run_time1.txt');
                $array = [];
                $dataArr = explode("\n", $data);
                foreach ($dataArr as $key => $val) {
                    $dArr = json_decode($val, true);
                    if ($dArr['channel'] == $value) {
                        if($dArr['params']['runtime']<86400){
                            $array[$value][$dArr['uuid']] = $array[$value][$dArr['uuid']] + $dArr['params']['runtime'];
                        }
                    }
                }
                $sql = "select count(*) as memu_heartbeat from (select * from `memu_heartbeat" . $date . "` where `channel`='" . $value . "' and uuid!='' group by uuid) as table1";
                if ($cache->get('memu_heartbeat' . $value . $date) !== false) {
                    $memu_heartbeat = $cache->get('memu_heartbeat' . $value . $date);
                } else {
                    $memu_heartbeat = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('memu_heartbeat' . $value . $date, $memu_heartbeat, 0);
                }
                $runtimes = (array_sum($array[$value]) / 3600) / $memu_heartbeat['memu_heartbeat'];
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $runtimes ? $runtimes : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }
    /**
     * 设置excel 留存
     * @param $objectPHPExcel
     * @param $startdate
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setKeepDAU($r, $objectPHPExcel, $startdate, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'install_finish" . $startdate . "'")->queryAll();
        if (!empty($ta)) {
            $type == 1 ? $channel = $this->channel : $channel = ['total'];;
            $cache = Yii::$app->cache;
            $i = $r;
            $d = 0;
            foreach ($channel as $value) {
                $EN = 'M';
                $day = $this->diffBetweenTwoDays($startdate, $date);
                for ($j = 1; $j <= $day + 1; $j++) {
                    if ($value == '400br' || $value == '201br' || $value == '311br' || $value == 'fb1' || $value == 'Memu') {
                        $sql = "select uuid as DNU from (select * from `install_finish" . $startdate . "` where `channel`='" . $value . "' and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
                    } else {
                        if ($startdate >= '2016-07-01') {
                            $sql = "select uuid as DNU from (select * from `memu_icon_visit_first" . $startdate . "` where `channel`='" . $value . "' and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
                        } else {
                            $sql = "select uuid as DNU from (select * from channel where `cid`='" . $value . "' and status=1 and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
                        }
                    }
                    if ($cache->get('DNU' . $value . $startdate) !== false) {
                        $StartDNU = $cache->get('DNU' . $value . $startdate);
                    } else {
                        $StartDNU = Yii::$app->db->createCommand($sql)->queryColumn();
                        $cache->set('DNU' . $value . $startdate, $StartDNU, 0);
                    }
                    //获取2016-06-20的新增用户
                    $secendday = date('Y-m-d', strtotime("$startdate   +" . $j . "   day"));
                    if ($secendday <= $date) {
                        //获取heartbeat 所有用户
                        $secendsSql = "select uuid from `memu_heartbeat" . $secendday . "` group by uuid";
                        if ($cache->get('memu_heartbeatsecendsUser' . $secendday) !== false) {
                            $secendsUser = $cache->get('memu_heartbeatsecendsUser' . $secendday);
                        } else {
                            $secendsUser = Yii::$app->db->createCommand($secendsSql)->queryColumn();
                            $cache->set('memu_heartbeatsecendsUser' . $secendday, $secendsUser, 0);
                        }
                        $d = count(array_intersect($StartDNU, $secendsUser));
                        $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $d ? number_format($d) : 0);
                    }
                    $EN++;
                    $EN++;
                }
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 留存
     * @param $objectPHPExcel
     * @param $startdate
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setKeepDRU($r, $objectPHPExcel, $startdate, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'install_finish" . $startdate . "'")->queryAll();
        if (!empty($ta)) {
            $type == 1 ? $channel = $this->channel : $channel = ['total'];;
            $cache = Yii::$app->cache;
            $i = $r;
            $d = 0;
            foreach ($channel as $value) {
                $EN = 'N';
                $day = $this->diffBetweenTwoDays($startdate, $date);
                for ($j = 1; $j <= $day + 1; $j++) {
                    if ($value == '400br' || $value == '201br' || $value == '311br' || $value == 'fb1' || $value == 'Memu') {
                        $sql = "select uuid as DNU from (select * from `install_finish" . $startdate . "` where `channel`='" . $value . "' and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
                    } else {
                        if ($startdate >= '2016-07-01') {
                            $sql = "select uuid as DNU from (select * from `memu_icon_visit_first" . $startdate . "` where `channel`='" . $value . "' and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
                        } else {
                            $sql = "select uuid as DNU from (select * from channel where `cid`='" . $value . "' and status=1 and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
                        }
                    }
                    if ($cache->get('DNU' . $value . $startdate) !== false) {
                        $StartDNU = $cache->get('DNU' . $value . $startdate);
                    } else {
                        $StartDNU = Yii::$app->db->createCommand($sql)->queryColumn();
                        $cache->set('DNU' . $value . $startdate, $StartDNU, 0);
                    }
                    //获取2016-06-20的新增用户
                    $secendday = date('Y-m-d', strtotime("$startdate   +" . $j . "   day"));
                    if ($secendday <= $date) {
                        //获取heartbeat 所有用户
                        $secendsSql = "select uuid from `heartbeat" . $secendday . "` group by uuid";
                        if ($cache->get('heartbeatsecendsUser' . $secendday) !== false) {
                            $secendsUser = $cache->get('heartbeatsecendsUser' . $secendday);
                        } else {
                            $secendsUser = Yii::$app->db->createCommand($secendsSql)->queryColumn();
                            $cache->set('heartbeatsecendsUser' . $secendday, $secendsUser, 0);
                        }
                        $d = count(array_intersect($StartDNU, $secendsUser));
                        $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $d ? number_format($d) : 0);
                    }
                    $EN++;
                    $EN++;
                }
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     *
     * @param $day1
     * @param $day2
     * @return float
     */
    function diffBetweenTwoDays($day1, $day2)
    {
        $second1 = strtotime($day1);
        $second2 = strtotime($day2);

        if ($second1 < $second2) {
            $tmp = $second2;
            $second2 = $second1;
            $second1 = $tmp;
        }
        return ceil(($second1 - $second2) / 86400);
    }

    public function checkTable($event, $date)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE '" . $event . $date . "'")->queryAll();
        if (empty($ta)) {
            return 0;
        }
        return 1;
    }

}