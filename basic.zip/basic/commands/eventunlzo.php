




<?php


$stime=time();

function unlzo($event,$date){

    $dir=$event.'/'.$date.'/';

	for($i=0;$i<24;$i++){

		$hour=sprintf("%02d", $i);
		$lzodir=$dir.$hour.'/';


		echo $undir='/tmp/eventdata/'.$lzodir;
		echo "\n";
		if(!file_exists($undir)){
			mkdir($undir,'0777',true);
		}

		$files=scandir($lzodir);
		foreach($files as $file){
			if(!in_array($file, ['.','..'])){
				$str='pushd '.$lzodir.' && /usr/bin/lzom -d '.$file.' '.$undir.$file.'.txt';
				exec($str, $output, $return_val);
			}
		}

	}

}

//$date=date('Ymd');
$date='20151101';
$arr=['AutoRun','InstSoftware','QuickLnk','HomePage'];
foreach($arr as $val){
	unlzo($val,$date);
}

echo $time=time()-$stime;

?>



