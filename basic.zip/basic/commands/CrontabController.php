<?php
/**
 * Created by PhpStorm.
 * User: chunyu
 * Date: 16/4/6
 * Time: 下午3:59
 */

namespace app\commands;

use app\models\ARbase\AppForeg;
use app\models\ARbase\AppOpenReport;
use app\models\ARbase\AppTimeLong;
use app\models\ARbase\SimReport;
use Yii;
use app\models\ARbase\AppReport;
use app\models\ARbase\AppReportSync;
use app\models\SCform\AppReportSearch;
use app\models\SCform\AppReportSyncSearch;
use yii\console\Controller;
use PHPExcel;
use PHPExcel_Style_NumberFormat;


class CrontabController extends Controller
{
    public $channel = ['10001', '10002', '30001', '400br', '311br', '201br', 'fb1', 'Memu'];

    public $eventArr = ['dumpcount', 'visit', 'install', 'install_finish', 'close', 'uninstall', 'up_start', 'up_finish', 'up_failed', 'up_update', 'dl_visit', 'dl_start', 'dl_failed', 'dl_finish', 'dl_close', 'download', 'memu_visit', 'memu_icon_visit', 'memu_icon_visit_first', 'memu_multi_icon_visit', 'multi_memu_visit', 'heartbeat', 'memu_heartbeat'];

    public function actionManageReport()
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $cache = Yii::$app->cache;
        $date = date("Y-m-d", strtotime("-1 days"));
        $appReportSearchModel = new AppReportSearch();
        $appReportList = $appReportSearchModel->getUserPcListData();
        foreach ($appReportList as $key => $value) {
            $appListFileName = $value['uuid'] . $value['mac'];
            $app_list = json_decode(file_get_contents('api/app_list/' . 'app_list-' . $date . '-' . $appListFileName . '.txt'), true);
            foreach ($app_list['app_list'] as $k => $val) {
                $list = str_replace('\'', '', str_replace('}', '', str_replace('{', '', $val)));
                $ArrList = explode(',', $list);
                $reportSyncArr = [];
                $reportSyncArr['appName'] = $ArrList[0];
                $reportSyncArr['packageName'] = $ArrList[1];
                //检查用户app数据存不存在
                $appReportSyncModel = new AppReportSync();
                $appReportSyncSearchModel = new AppReportSyncSearch();
                if ($cache->get($value['id'] . $reportSyncArr['appName'] . $reportSyncArr['packageName'] . $date) === false) {
                    $dataList = $appReportSyncSearchModel->checkUuidAppIsExist($value['id'], $reportSyncArr['appName'], $reportSyncArr['packageName'], $date);
                    $cache->set($value['id'] . $reportSyncArr['appName'] . $reportSyncArr['packageName'] . $date, $dataList);
                    $dataList = $cache->get($value['id'] . $reportSyncArr['appName'] . $reportSyncArr['packageName'] . $date);
                } else {
                    $dataList = $cache->get($value['id'] . $reportSyncArr['appName'] . $reportSyncArr['packageName'] . $date);
                }
                if (empty($dataList)) {
                    //保存applist
                    $appReportSyncModel->attributes = $reportSyncArr;
                    $appReportSyncModel->r_id = $value['id'];
                    $appReportSyncModel->create_time = $date;
                    $appReportSyncModel->update_time = $date;
                    $appReportSyncModel->save();
                }

            }
        }
    }

    public function actionManageForeg()
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $date = date("Y-m-d", strtotime("-1 days"));
        $content = file_get_contents('api/app_foreg/app_foreg' . $date . '.txt');
        $foregArr = explode("app_foreg:", $content);
        $Arr = [];
        $foregNumArr = [];
        foreach ($foregArr as $key => $value) {
            if (!empty($value)) {
                $appForegArr = json_decode(trim($value), true);
                if (isset($appForegArr['pc'])) {
                    if (!in_array(json_decode($appForegArr['app_foreg'], true)['package'], $Arr)) {
                        array_push($Arr, json_decode($appForegArr['app_foreg'], true)['package']);
                    }

                    $packageArr = json_decode($appForegArr['app_foreg'], true);
                    if (in_array($packageArr['package'], $Arr)) {
                        $foregNumArr[$packageArr['package']]['num'] = $foregNumArr[$packageArr['package']]['num'] + 1;
                    }
                    $foregNumArr[$packageArr['package']]['User'][] = $appForegArr['pc']['uuid'];
                    $foregNumArr[$packageArr['package']]['User'] = array_unique($foregNumArr[$packageArr['package']]['User']);
                }
            }
        }
        foreach ($foregNumArr as $okey => $ovalue) {
            $appOpenReport = new AppOpenReport();
            $appOpenReport->name = $okey;
            $appOpenReport->num = intval($ovalue['num']);
            $appOpenReport->unum = intval(count($ovalue['User']));
            $appOpenReport->create_time = $date;
            $appOpenReport->save();
        }
    }

    public function actionManageUserLongTimes()
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $date = date("Y-m-d", strtotime("-1 days"));
        $content = file_get_contents('api/app_foreg/app_foreg' . $date . '.txt');
        $foregArr = explode("app_foreg:", $content);
        $Arr = [];
        foreach ($foregArr as $key => $value) {
            if (!empty($value)) {
                $appForegArr = json_decode(trim($value), true);
                if (isset($appForegArr['pc'])) {
                    $Arr[$appForegArr['pc']['uuid']][$key]['package'] = json_decode($appForegArr['app_foreg'], true)['package'];
                    $Arr[$appForegArr['pc']['uuid']][$key]['time'] = $appForegArr['pc']['time'];
                }
            }
        }
        $UserArr = [];
        foreach ($Arr as $key => $value) {
            $num = 0;
            $n = 0;
            foreach ($value as $k => $val) {
                if ($num == 0) {
                    $UserArr[$key][$n]['package'] = $val['package'];
                    $UserArr[$key][$n]['time'] = $val['time'];
                } elseif ($val['package'] == $UserArr[$key][$n - 1]['package']) {
                } elseif ($val['package'] !== $UserArr[$key][$n - 1]['package']) {
                    if ($n > 0) {
                        $UserArr[$key][$n - 1]['long'] = $val['time'] - $UserArr[$key][$n - 1]['time'];
                    }
                    $UserArr[$key][$n]['package'] = $val['package'];
                    $UserArr[$key][$n]['time'] = $val['time'];
                    $n++;
                }
                $num++;
            }
            $UserArr[$key][count($UserArr[$key]) - 1]['long'] = strtotime($date . '23:59:59') * 1000 - $UserArr[$key][$n - 1]['time'];
        }
        $lostArr = [];
        foreach ($UserArr as $key => $value) {
            $isArr = [];
            foreach ($value as $k => $v) {
                if (!in_array($v['package'], $isArr)) {
                    array_push($isArr, $v['package']);
                    $lostArr[$key][] = $v;
                } else {
                    foreach ($lostArr as $lk => $lv) {
                        foreach ($lv as $llk => $llv) {
                            if ($lostArr[$lk][$llk]['package'] == $v['package']) {
                                $lostArr[$lk][$llk]['long'] = $lostArr[$lk][$llk]['long'] + $v['long'];
                            }
                        }
                    }
                }
            }
        }
        foreach ($lostArr as $okey => $ovalue) {
            foreach ($ovalue as $k => $v) {
                if ($v['long'] > 0) {
                    $appTimeLong = new AppTimeLong();
                    $appTimeLong->package = $v['package'];
                    $appTimeLong->uuid = $okey;
                    $appTimeLong->time = $v['time'];
                    $appTimeLong->long = $v['long'];
                    $appTimeLong->create_time = $date;
                    $appTimeLong->save();
                }
            }
        }
    }

    /**
     * 处理安装过程上报数据
     */
    public function actionHandleReport()
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $date = date("Y-m-d", strtotime("-1 days"));
//        $date = date("Y-m-d");
        $date = '2016-06-25';
        $str = '';
        $num = 1;
        $eventArr = $this->eventArr;
        foreach ($eventArr as $key => $value) {
            $eventFile = 'api/report/' . $value . '/' . $date;
            if (file_exists($eventFile)) {
                $rs = $this->createTable($value, $date);
                if ($rs) {
                    $arr = scandir($eventFile);
                    $fileNum = count($arr) - 3;
                    $fileNum = $fileNum ? $fileNum : 1;
                    for ($i = 1; $i <= $fileNum; $i++) {
                        $content = file_get_contents($eventFile . '/' . $value . $i . '.txt');
                        $fileDataArr = (explode("\n", $content));
                        foreach ($fileDataArr as $v) {
                            if (!empty($v)) {
                                $dataArr = json_decode(trim($v), true);
                                $dataArr['params'] = json_encode($dataArr['params']);
                                $str .= "(NULL, '" . addslashes($dataArr['event']) . "', '" . addslashes($dataArr['channel']) . "', '" . addslashes($dataArr['subchannel']) . "', '" . $dataArr['version'] . "', '" . $dataArr['locale'] . "', '" . $dataArr['uuid'] . "', '" . $dataArr['appid'] . "', '" . json_encode($dataArr['params']) . "', '" . $date . "'),";
                                if ($num == 15000) {
                                    $sql = "INSERT INTO `simcake`.`" . $value . $date . "` (`id`, `event`, `channel`, `subchannel`, `version`, `locale`, `uuid`, `appid`, `params`, `create_time`) VALUES " . $str;

                                    $sql = substr($sql, 0, strlen($sql) - 1);
                                    Yii::$app->db->createCommand($sql)->query();
                                    $num = 0;
                                    $str = '';
                                }
                                $num++;
                            }
                        }
                        if (!empty($str)) {
                            $sql = "INSERT INTO `simcake`.`" . $value . $date . "` (`id`, `event`, `channel`, `subchannel`, `version`, `locale`, `uuid`, `appid`, `params`, `create_time`) VALUES " . $str;
                            $sql = substr($sql, 0, strlen($sql) - 1);
                            Yii::$app->db->createCommand($sql)->query();
                            $str = '';
                            $num = 1;
                        }
                    }
                }
            }
        }
    }

    /**
     * 创建安装过程上报时间数据库表
     *
     * @param $value
     * @param $date
     * @return int
     */
    public function createTable($value, $date)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE '" . $value . $date . "'")->queryAll();
        if ($ta == null) {
            $connection = Yii::$app->db; //连接
            $sql = "CREATE TABLE `" . $value . $date . "` (
                      `id` int(11) NOT NULL AUTO_INCREMENT,
                      `event` varchar(255) NOT NULL,
                      `channel` varchar(255) NOT NULL,
                      `subchannel` varchar(255) NOT NULL,
                      `version` varchar(255) NOT NULL,
                      `locale` varchar(255) NOT NULL,
                      `uuid` text NOT NULL,
                      `Appid` varchar(255) NOT NULL,
                      `params` text NOT NULL,
                      `create_time` date NOT NULL,
                      PRIMARY KEY (`id`),
                      KEY `event` (`event`),
                      KEY `appid` (`appid`),
                      KEY `create_time` (`create_time`),
                      KEY `channel` (`channel`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8;";
            $connection->createCommand($sql)->query();
            return 1;
        }
        return 1;
    }

    /**
     * 处理SIM cake 首页上报数据
     */
    public function actionFrontReport()
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $date = date("Y-m-d", strtotime("-1 days"));
//        $date = date("Y-m-d");

        $date = '2016-06-25';
        $eventFile = 'api/front_report/' . $date;
        $str = '';
        $num = 1;
        if (file_exists($eventFile)) {
            $rs = $this->createFrontTable('front_report', $date);
            $arr = scandir($eventFile);
            $fileNum = count($arr) - 3;
            $fileNum = $fileNum ? $fileNum : 1;
            for ($i = 1; $i <= $fileNum; $i++) {
                $content = file_get_contents($eventFile . '/front_report' . $i . '.txt');
                $fileDataArr = (explode("\n", $content));
                foreach ($fileDataArr as $v) {
                    if (!empty($v)) {
                        $dataArr = json_decode(trim($v), true);
                        $str .= "(NULL,'" . $dataArr['model_name'] . "','" . $dataArr['event_name'] . "','" . $dataArr['name'] . "', '" . $date . "'),";
                        if ($num == 15000) {
                            $sql = "INSERT INTO `simcake`.`" . "front_report" . $date . "` (`id`, `model_name`,`event_name`,`name`, `create_time`) VALUES " . $str;
                            $sql = substr($sql, 0, strlen($sql) - 1);
                            Yii::$app->db->createCommand($sql)->query();
                            $str = '';
                            $num = 0;
                        }
                        $num++;
                    }
                }
                $sql = "INSERT INTO `simcake`.`" . "front_report" . $date . "` (`id`, `model_name`,`event_name`,`name`, `create_time`) VALUES " . $str;
                $sql = substr($sql, 0, strlen($sql) - 1);
                Yii::$app->db->createCommand($sql)->query();
                $str = '';
                $num = 1;
            }
        }
    }

    /**
     * 创建SIM cake 首页上报数据表
     * @param $value
     * @param $date
     * @return int
     */
    public function createFrontTable($value, $date)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE '" . $value . $date . "'")->queryAll();
        if ($ta == null) {
            $connection = Yii::$app->db; //连接
            $sql = "CREATE TABLE `simcake`.`front_report" . $date . "` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `model_name` VARCHAR(255) NULL,
  `event_name` VARCHAR(255) NULL,
  `name` VARCHAR(255) NULL,
  `create_time` DATE NULL,
  PRIMARY KEY (`id`),
  INDEX `model_name` (`model_name` ASC),
  INDEX `event_name` (`event_name` ASC),
  INDEX `name` (`name` ASC),
  INDEX `create_time` (`create_time` ASC));
";
            $connection->createCommand($sql)->query();
            return 1;
        }
        return 1;
    }

    /**
     * 处理landing page 上报数据
     */
    public function actionLandingReport()
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
//        $date = date("Y-m-d", strtotime("-1 days"));
//        $date = date("Y-m-d");
        $date = '2016-07-28';
        $eventFile = 'api/landing_report/' . $date;
        $str = '';
        $num = 1;
        if (file_exists($eventFile)) {
            $rs = $this->createLandingTable('landing_report', $date);
            $arr = scandir($eventFile);
            $fileNum = count($arr) - 3;
            $fileNum = $fileNum ? $fileNum : 1;
            for ($i = 1; $i <= $fileNum; $i++) {
                $content = file_get_contents($eventFile . '/landing_report' . $i . '.txt');
                $fileDataArr = (explode("\n", $content));
                foreach ($fileDataArr as $v) {
                    if (!empty($v)) {
                        $dataArr = json_decode(trim($v), true);
                        $str .= "(NULL,'" . addslashes($dataArr['model_name']) . "','" . addslashes($dataArr['event_name']) . "','" . json_encode($dataArr['params']) . "','" . $dataArr['uuid'] . "', '" . $date . "'),";
                        if ($num == 15000) {
                            $sql = "INSERT INTO `simcake`.`" . "landing_report" . $date . "` (`id`, `model_name`,`event_name`,`name`,`uuid`, `create_time`) VALUES " . $str;
                            $sql = substr($sql, 0, strlen($sql) - 1);
                            Yii::$app->db->createCommand($sql)->query();
                            $str = '';
                            $num = 0;
                        }
                        $num++;
                    }
                }
                if (!empty($str)) {
                    $sql = "INSERT INTO `simcake`.`" . "landing_report" . $date . "` (`id`, `model_name`,`event_name`,`name`,`uuid`, `create_time`) VALUES " . $str;
                    $sql = substr($sql, 0, strlen($sql) - 1);
                    Yii::$app->db->createCommand($sql)->query();
                    $str = '';
                    $num = 1;
                }
            }
        }
    }

    /**
     * 生成landing page页面上报数据表
     * @param $value
     * @param $date
     * @return int
     */
    public function createLandingTable($value, $date)
    {

        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE '" . $value . $date . "'")->queryAll();
        if ($ta == null) {
            $connection = Yii::$app->db; //连接
            $sql = "CREATE TABLE `simcake`.`landing_report" . $date . "` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `model_name` VARCHAR(255) NULL,
  `event_name` VARCHAR(255) NULL,
  `name` VARCHAR(255) NULL,
  `uuid` VARCHAR(255) NULL,
  `create_time` DATE NULL,
  PRIMARY KEY (`id`),
  INDEX `model_name` (`model_name` ASC),
  INDEX `event_name` (`event_name` ASC),
  INDEX `name` (`name` ASC),
  INDEX `create_time` (`create_time` ASC));
";
            $connection->createCommand($sql)->query();
            return 1;
        }
        return 1;
    }


    /**
     * 处理安装过程上报数据
     */
    public function actionOneHandleReport()
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $date = date("Y-m-d", strtotime("-1 days"));
//        $date = date("Y-m-d");
        $date = '2016-08-04';
        $str = '';
        $num = 1;
        $eventArr = ['memu_icon_visit_first'];
        foreach ($eventArr as $key => $value) {
            $eventFile = 'api/report/' . $value . '/' . $date;
            if (file_exists($eventFile)) {
                $rs = $this->createTable($value, $date);
                if ($rs) {
                    $arr = scandir($eventFile);
                    $fileNum = count($arr) - 3;
                    $fileNum = $fileNum ? $fileNum : 1;
                    for ($i = 1; $i <= $fileNum; $i++) {
                        $content = file_get_contents($eventFile . '/' . $value . $i . '.txt');
                        $fileDataArr = (explode("\n", $content));
                        foreach ($fileDataArr as $v) {
                            if (!empty($v)) {
                                $dataArr = json_decode(trim($v), true);
                                $dataArr['params'] = json_encode($dataArr['params']);
                                $str .= "(NULL, '" . $dataArr['event'] . "', '" . $dataArr['channel'] . "', '" . $dataArr['subchannel'] . "', '" . $dataArr['version'] . "', '" . $dataArr['locale'] . "', '" . $dataArr['uuid'] . "', '" . $dataArr['appid'] . "', '" . $dataArr['params'] . "', '" . $date . "'),";
                                if ($num == 15000) {
                                    $sql = "INSERT INTO `simcake`.`" . $value . $date . "` (`id`, `event`, `channel`, `subchannel`, `version`, `locale`, `uuid`, `appid`, `params`, `create_time`) VALUES " . $str;
                                    $sql = substr($sql, 0, strlen($sql) - 1);
                                    Yii::$app->db->createCommand($sql)->query();
                                    $num = 0;
                                    $str = '';
                                }
                                $num++;
                            }
                        }
                        $sql = "INSERT INTO `simcake`.`" . $value . $date . "` (`id`, `event`, `channel`, `subchannel`, `version`, `locale`, `uuid`, `appid`, `params`, `create_time`) VALUES " . $str;
                        $sql = substr($sql, 0, strlen($sql) - 1);
                        Yii::$app->db->createCommand($sql)->query();
                    }
                }
            }
        }
    }

    /**
     * 本地获取线上上报数据文件
     */
    public function actionFindData()
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $eventArr = ['memu_heartbeat'];
        $date = '2016-07-11';
//        $date = date("Y-m-d", strtotime("-1 days"));
        foreach ($eventArr as $value) {
            $path = './api/report/' . $value . '/' . $date . '/';

            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $data = file_get_contents('http://api.simcake.com/report/' . $value . '/' . $date . '/' . $value . '1.txt');
            file_put_contents('./api/report/' . $value . '/' . $date . '/' . $value . '1.txt', $data);
        }
    }

    /**
     * 本地获取landingpage 线上上报数据文件
     */
    public function actionFindLandingData()
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $eventArr = ['landing_report'];
        $date = '2016-07-11';
//        $date = date("Y-m-d", strtotime("-1 days"));
        foreach ($eventArr as $value) {
            $path = './api/' . $value . '/' . $date . '/';

            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $data = file_get_contents('http://api.simcake.com/' . $value . '/' . $date . '/' . $value . '1.txt');
            file_put_contents($path . '/' . $value . '1.txt', $data);
        }
    }


    /**
     * 删除某天的数据表
     */
    public function actionDeleteTable()
    {

        $startdate = '2016-06-20';
        $date = date("Y-m-d", strtotime("-42 days"));
        $day = $this->diffBetweenTwoDays($startdate, $date);
        for ($i = 0; $i <= $day; $i++) {
            echo $startdate . '--';
            $eventArr = $this->eventArr;
            foreach ($eventArr as $value) {
                $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE '" . $value . $startdate . "'")->queryAll();
                if (!empty($ta)) {
                    $connection = Yii::$app->db; //连接
                    $sql = "drop table `" . $value . $startdate . "`;";
                    $connection->createCommand($sql)->query();
                }
            }
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
        }
    }

    /**
     *
     * @param $day1
     * @param $day2
     * @return float
     */
    function diffBetweenTwoDays($day1, $day2)
    {
        $second1 = strtotime($day1);
        $second2 = strtotime($day2);

        if ($second1 < $second2) {
            $tmp = $second2;
            $second2 = $second1;
            $second1 = $tmp;
        }
        return ceil(($second1 - $second2) / 86400);
    }

    public function actionMemuReport()
    {
        // Memu_R2016-08-10.xls
        $MemuexcelController = new MemuexcelsController();


        $MemuexcelController->actionOneExcel();
        // Memu_R_Total2016-08-10.xls
        $MemutotalexcelController = new MemutotalexcelsController();
        $MemutotalexcelController->actionOneExcel();
        // Memu2016-08-10.xls
        $ExcelsController = new ExcelsController();
        $ExcelsController->actionOneExcel();
        // Memu_total2016-08-10.xls
        $TotalexcelsController = new TotalexcelsController();
        $TotalexcelsController->actionTotalExcel();
    }
}