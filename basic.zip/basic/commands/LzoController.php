<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace app\commands;

use yii\console\Controller;

/**
 * This command echoes the first argument that you have entered.
 *
 * This command is provided as an example for you to learn how to create console commands.
 *
 * @author Qiang Xue <qiang.xue@gmail.com>
 * @since 2.0
 */
class LzoController extends Controller
{
    /**
     * This command echoes what you have entered as the message.
     * @param string $message the message to be echoed.
     */
    public function actionIndex()
    {


    }

    public function actionReadlzo()
    {
        $stime=time();

        //$date=date('Ymd');
        $date='20151101';
        $arr=['InstSoftware'];
        foreach($arr as $val){
            $this->readlzo($val,$date);
        }

        echo $time=time()-$stime;

    }

    function readlzo($event,$date){

       $path='/tmp/eventdata/InstSoftware/'.$date;

        for($i=0;$i<24;$i++){

            $hour=sprintf("%02d", $i);
            $lzodir=$path.$hour.'/';

            $files=scandir($lzodir);
            foreach($files as $file){
                if(in_array($file, ['.','..'])) continue;

                echo file_get_contents($lzodir.$file);
                die;
            }

        }




    }


}
