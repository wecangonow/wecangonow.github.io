<?php
/**
 * Created by PhpStorm.
 * User: chunyu
 * Date: 16/4/6
 * Time: 下午3:59
 */

namespace app\commands;

use Yii;
use yii\console\Controller;
use PHPExcel;
use PHPExcel_Style_NumberFormat;


class Branch_channel_expand_reportController extends Controller
{
    public $channel = ['10001', '10002', '30001', '40001', '40002', 'fb2', 'fb3', 'fb5', 'ggs'];

    public function actionCreateReport()
    {
        $begindate = '2016-09-10';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-09-10';
        $enddate = date("Y-m-d", strtotime("-1 days"));

        $day = $this->diffBetweenTwoDays($startdate, $enddate);
        $db = Yii::$app->db;

//        for ($j = 0; $j <= $day; $j++) {

        $sql = "call up_data('" . $enddate . "')";
        $data = $db->createCommand($sql)->queryAll();
        foreach ($data as $item) {
            if (!empty($item['channel']) && in_array($item['channel'], $this->channel)) {
                $rowArr = [];
                $valArr = [];
                foreach ($item as $key => $value) {
                    $rowArr[] = $key;
                    $valArr[] = $value;
                }
                $rowArr[0] = 'date';
                $rowStr = '`' . implode("`,`", $rowArr) . '`';;
                $valStr = '("' . implode('","', $valArr) . '")';
                $savesql = 'insert into rp_branch_channel_expand (' . $rowStr . ') value ' . $valStr . '';
                $db->createCommand($savesql)->query();
            }
        }
//            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
//        }


        $this->createMemuBranchChannelCSV('memu_branch_channel_expand');

    }

    /**
     * 生成csv文件
     */
    public function createMemuBranchChannelCSV($filename)
    {
        $sql = "select * from rp_branch_channel_expand";
        $data = Yii::$app->db->createCommand($sql)->queryAll();
        $rowArr = [];
        foreach ($data as $key => $value) {
            if ($key == 0) {
                foreach ($value as $k => $v) {
                    $rowArr[] = $k;
                }
            }
        }
        array_unshift($data, $rowArr);
        $file = fopen("./web/memu_report/" . $filename . ".csv", "w");

        foreach ($data as $line) {
            fputcsv($file, $line, ',');
        }
    }

    /**
     *
     * @param $day1
     * @param $day2
     * @return float
     */
    function diffBetweenTwoDays($day1, $day2)
    {
        $second1 = strtotime($day1);
        $second2 = strtotime($day2);

        if ($second1 < $second2) {
            $tmp = $second2;
            $second2 = $second1;
            $second1 = $tmp;
        }
        return ceil(($second1 - $second2) / 86400);
    }


}