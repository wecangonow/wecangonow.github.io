<?php
/**
 * Created by PhpStorm.
 * User: chunyu
 * Date: 16/9/5
 * Time: 下午2:03
 */

namespace app\commands;

use Yii;
use yii\console\Controller;
use PHPExcel;
use PHPExcel_Style_NumberFormat;

class MemuhelperController extends Controller
{
    public $channel = [];

    public function actionMakeExcel()
    {
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->createSheet(0);
        $objectPHPExcel->createSheet(1);
        $objectPHPExcel->createSheet(2);
        $objectPHPExcel->createSheet(3);
        $objectPHPExcel->createSheet(4);
        // 分渠道数据日报
        $this->actionOneExcel($objectPHPExcel);
        // 总数据报表
        $this->totalDataExcel($objectPHPExcel);
        // 分渠道留存率
        $this->actionChannelRate($objectPHPExcel);
        // 总留存率
        $this->actionTotalRate($objectPHPExcel);

    }

    /**
     *
     * 生成每日上报数据
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */

    public function actionOneExcel($objectPHPExcel)
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $begindate = '2016-06-20';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-06-20';
        $date = date("Y-m-d", strtotime("-1 days"));
        $startdate = '2016-07-25';
        $date = '2016-07-27';
        $day = $this->diffBetweenTwoDays($startdate, $date);
        ob_end_clean();
        ob_start();
        $row = $this->setExcelRowTop();
        $EN = 'A';
        $i = 1;
        $r = 2;
        $type = 1;
        $objectPHPExcel->setActiveSheetIndex(0)->setTitle('分渠道数据日报');
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            if ($startdate <= '2016-06-21') {
                $this->channel = ['10001', '10002', '30001'];
            }
            if ($startdate > '2016-06-21' && $startdate <= '2016-06-23') {
                $this->channel = ['10001', '10002', '30001', '400br'];
            }
            if ($startdate > '2016-06-23' && $startdate <= '2016-06-26') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br'];
            }
            if ($startdate == '2016-06-27') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br', '311br'];
            }
            if ($startdate == '2016-06-28') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br', '311br', 'fb2'];
            }
            if ($startdate == '2016-06-29') {
                $this->channel = ['10001', '10002', '30001', '400br', '311br', 'fb2'];
            }
            if ($startdate > '2016-06-29' && $startdate <= '2016-07-12') {
                $this->channel = ['10001', '10002', '30001', 'fb2'];
            }
            if ($startdate > '2016-07-12' && $startdate <= '2016-07-15') {
                $this->channel = ['10001', '10002', '30001', 'fb2', 'ggs'];
            }
            if ($startdate > '2016-07-15') {
                $this->channel = ['10001', '10002', '30001', '40001', 'fb2', 'ggs'];
            }
            if ($startdate > '2016-08-30') {
                $this->channel = ['10001', '10002', '30001', '40001', '40002', 'fb2', 'fb3', 'ggs'];
            }
            if ($startdate > '2016-08-31') {
                $this->channel = ['10001', '10002', '30001', '40001', '40002', 'fb2', 'fb3', 'fb5', 'ggs'];
            }
            $num = 1;
            $this->handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type);
            $path = "./../web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/Memu+helper" . $startdate . ".xls";
            if (!empty($objectPHPExcel)) {
                $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
                $objWriter->save($filename);
            }
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r = $r + count($this->channel) * $num;
            $num++;
        }
    }

    /**
     * 总数据报表
     * @param $objectPHPExcel
     */
    public function totalDataExcel($objectPHPExcel)
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $begindate = '2016-06-20';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-06-20';
        $date = date("Y-m-d", strtotime("-1 days"));
        $startdate = '2016-07-25';
        $date = '2016-07-27';
        $day = $this->diffBetweenTwoDays($startdate, $date);
        ob_end_clean();
        ob_start();
        $row = $this->setTotalExcelRowTop();
        $EN = 'A';
        $i = 1;
        $r = 2;
        $type = 2;
        $objectPHPExcel->setActiveSheetIndex(1)->setTitle('总数据日报');
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(1)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            $this->channel = ['total'];
            $num = 1;
            $objectPHPExcel = $this->handleTotalExcelRow($r, $objectPHPExcel, $startdate, $date, $type);
            $path = "./../web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/Memu+helper" . $startdate . ".xls";
            $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
            $objWriter->save($filename);
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r++;
            $num++;
        }
    }

    /**
     *
     * 分渠道留存率
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */

    public function actionChannelRate($objectPHPExcel)
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $begindate = '2016-06-20';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-06-20';
        $date = date("Y-m-d", strtotime("-1 days"));
        $startdate = '2016-07-25';
        $date = '2016-07-27';
        $day = $this->diffBetweenTwoDays($startdate, $date);
        ob_end_clean();
        ob_start();
        $row = $this->setChannelExcelRowTop();
        $EN = 'A';
        $i = 1;
        $r = 2;
        $type = 1;
        $objectPHPExcel->setActiveSheetIndex(2)->setTitle('分渠道留存率');
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(2)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            if ($startdate <= '2016-06-21') {
                $this->channel = ['10001', '10002', '30001'];
            }
            if ($startdate > '2016-06-21' && $startdate <= '2016-06-23') {
                $this->channel = ['10001', '10002', '30001', '400br'];
            }
            if ($startdate > '2016-06-23' && $startdate <= '2016-06-26') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br'];
            }
            if ($startdate == '2016-06-27') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br', '311br'];
            }
            if ($startdate == '2016-06-28') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br', '311br', 'fb2'];
            }
            if ($startdate == '2016-06-29') {
                $this->channel = ['10001', '10002', '30001', '400br', '311br', 'fb2'];
            }
            if ($startdate > '2016-06-29' && $startdate <= '2016-07-12') {
                $this->channel = ['10001', '10002', '30001', 'fb2'];
            }
            if ($startdate > '2016-07-12' && $startdate <= '2016-07-15') {
                $this->channel = ['10001', '10002', '30001', 'fb2', 'ggs'];
            }
            if ($startdate > '2016-07-15') {
                $this->channel = ['10001', '10002', '30001', '40001', 'fb2', 'ggs'];
            }
            $num = 1;
            $this->handleChannelExcelRow($r, $objectPHPExcel, $startdate, $date, $type);

            $path = "./../web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/Memu+helper" . $startdate . ".xls";

            if (!empty($objectPHPExcel)) {
                $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
                $objWriter->save($filename);
            }
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r = $r + count($this->channel) * $num;
            $num++;
        }
    }

    /**
     *
     * 总留存率
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */

    public function actionTotalRate($objectPHPExcel)
    {
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $begindate = '2016-06-20';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-06-20';
        $date = date("Y-m-d", strtotime("-1 days"));
        $startdate = '2016-07-25';
        $date = '2016-07-27';
        $day = $this->diffBetweenTwoDays($startdate, $date);
        ob_end_clean();
        ob_start();
        $row = $this->setChannelExcelRowTop();
        $EN = 'A';
        $i = 1;
        $r = 2;
        $type = 1;
        $objectPHPExcel->setActiveSheetIndex(3)->setTitle('总留存率');
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(3)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            $num = 1;
            $this->handleTotalChannelExcelRow($r, $objectPHPExcel, $startdate, $date, $type);

            $path = "./../web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/Memu+helper" . $startdate . ".xls";

            if (!empty($objectPHPExcel)) {
                $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
                $objWriter->save($filename);
            }
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r = $r + 1 * $num;
            $num++;
        }
    }

    public function handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type)
    {
        $ExcelsController = new ExcelsController();
        //时间 A
        $ExcelsController->setdate($r, $objectPHPExcel, $startdate, $type);
        //获取渠道 B
        $ExcelsController->setChannel($r, $objectPHPExcel, $type);
        //获取DNU C
        $ExcelsController->setDNU($r, $objectPHPExcel, $startdate, $type);
        //获取DAU D
        $ExcelsController->setDAU($r, $objectPHPExcel, $startdate, $type);
        //获取DRU E
        $ExcelsController->setDRU($r, $objectPHPExcel, $startdate, $type);
        //pageview F
        $ExcelsController->setPageview($r, $objectPHPExcel, $startdate, $type);
        //获取click G
        $ExcelsController->setDlClick($r, $objectPHPExcel, $startdate, $type);
        //获取click H
        $ExcelsController->setCTR($r, $objectPHPExcel, $startdate, $type);
        //获取install_finish I
        $ExcelsController->setInstallFinish($r, $objectPHPExcel, $startdate, $type);
        //获取卸载 J
        $ExcelsController->setUnInstall($r, $objectPHPExcel, $startdate, $type);
        //获取卸载 K
        $ExcelsController->setTodayUnInstall($r, $objectPHPExcel, $startdate, $type);
        //获取卸载 L
        $ExcelsController->setMemuRuntime($r, $objectPHPExcel, $startdate, $type);
        //以2016-06-20 开始的留存 M
        $ExcelsController->setKeepDAU($r, $objectPHPExcel, $startdate, $date, $type);
        //以2016-06-20 开始的留存 N
        $ExcelsController->setKeepDRU($r, $objectPHPExcel, $startdate, $date, $type);
    }


    public function handleTotalExcelRow($r, $objectPHPExcel, $startdate, $date, $type)
    {
        $TotalexcelsController = new TotalexcelsController();
        //时间 A
        $objectPHPExcel = $TotalexcelsController->setdate($r, $objectPHPExcel, $startdate, $type);
        //获取渠道 B
        $objectPHPExcel = $TotalexcelsController->setChannel($r, $objectPHPExcel, $type);
        //获取DNU C
        $objectPHPExcel = $TotalexcelsController->setDNU($r, $objectPHPExcel, $startdate, $type);
        //获取DAU D
        $objectPHPExcel = $TotalexcelsController->setDAU($r, $objectPHPExcel, $startdate, $type);
        //获取DRU E
        $objectPHPExcel = $TotalexcelsController->setDRU($r, $objectPHPExcel, $startdate, $type);
        //pageview F
        $objectPHPExcel = $TotalexcelsController->setPageview($r, $objectPHPExcel, $startdate, $type);
        //获取click G
        $objectPHPExcel = $TotalexcelsController->setDlClick($r, $objectPHPExcel, $startdate, $type);
        //获取click H
        $objectPHPExcel = $TotalexcelsController->setCTR($r, $objectPHPExcel, $startdate, $type);
        //获取install_finish I
        $objectPHPExcel = $TotalexcelsController->setInstallFinish($r, $objectPHPExcel, $startdate, $type);
        //获取卸载 J
        $objectPHPExcel = $TotalexcelsController->setUnInstall($r, $objectPHPExcel, $startdate, $type);
        //获取卸载率 K
        $objectPHPExcel = $TotalexcelsController->setTodayUnInstall($r, $objectPHPExcel, $startdate, $type);
        //获取奔溃率 L
        $objectPHPExcel = $TotalexcelsController->setDumpCountRate($r, $objectPHPExcel, $startdate, $type);
        //获取升级成功率 M
        $objectPHPExcel = $TotalexcelsController->setUpSuccessRate($r, $objectPHPExcel, $startdate, $type);
        //获取升级成功率 N
        $objectPHPExcel = $TotalexcelsController->setMemuRuntime($r, $objectPHPExcel, $startdate, $type);
        //以2016-06-20 开始的留存 O
        $objectPHPExcel = $TotalexcelsController->setKeepDAU($r, $objectPHPExcel, $startdate, $date, $type);
        //以2016-06-20 开始的留存 P
        $objectPHPExcel = $TotalexcelsController->setKeepDRU($r, $objectPHPExcel, $startdate, $date, $type);
        return $objectPHPExcel;
    }

    public function handleChannelExcelRow($r, $objectPHPExcel, $startdate, $date, $type)
    {
        $MemuexcelsController = new MemuexcelsController();
        //时间 A
        $MemuexcelsController->setdate($r, $objectPHPExcel, $startdate, $type);
        //获取渠道 B
        $MemuexcelsController->setChannel($r, $objectPHPExcel, $type);
        //以2016-06-20 开始的留存 C
        $MemuexcelsController->setKeepDAU($r, $objectPHPExcel, $startdate, $date, $type);
        //以2016-06-20 开始的留存 D
        $MemuexcelsController->setKeepDRU($r, $objectPHPExcel, $startdate, $date, $type);
    }


    public function handleTotalChannelExcelRow($r, $objectPHPExcel, $startdate, $date, $type)
    {
        $MemutotalexcelsController = new MemutotalexcelsController();
        //时间 A
        $MemutotalexcelsController->setdate($r, $objectPHPExcel, $startdate, $type);
        //获取渠道 B
        $MemutotalexcelsController->setChannel($r, $objectPHPExcel, $type);
        //以2016-06-20 开始的留存 C
        $MemutotalexcelsController->setKeepDAU($r, $objectPHPExcel, $startdate, $date, $type);
        //以2016-06-20 开始的留存 D
        $MemutotalexcelsController->setKeepDRU($r, $objectPHPExcel, $startdate, $date, $type);
    }

    public function setChannelExcelRowTop()
    {

        $row = ['DATE', '渠道'
        ];
        $j = 2;
        $k = 2;
        for ($i = 0; $i < 20; $i++) {
            if ($i > 1) {
                if ($i < 11) {
                    if ($i == 8) {
                        $row[$i] = 'D10A RATE';
                    } elseif ($i == 9) {
                        $row[$i] = 'D15A RATE';
                    } elseif ($i == 10) {
                        $row[$i] = 'D30A RATE';
                    } else {
                        $row[$i] = 'D' . $j . 'A RATE';
                    }
                    $j++;
                } elseif ($i == 11) {
                    $row[$i] = '';
                } else {
                    if ($i == 18) {
                        $row[$i] = 'D10R RATE';
                    } elseif ($i == 19) {
                        $row[$i] = 'D15R RATE';
                    } elseif ($i == 20) {
                        $row[$i] = 'D30R RATE';
                    } else {
                        $row[$i] = 'D' . $k . 'R RATE';
                    }
                    $k++;
                }
            }
        }
        return $row;
    }

    public function setTotalExcelRowTop()
    {
        $row = ['DATE', '渠道', 'DNU', 'DAU', 'DRU', 'Pageview', 'Click', 'CTR', 'Install_finish', '卸载', '今日卸载', 'DumpRate', 'UpSuccessRate', '平均运行时长(h)',
            'D2A', 'D2R',
            'D3A', 'D3R',
            'D4A', 'D4R',
            'D5A', 'D5R',
            'D6A', 'D6R',
            'D7A', 'D7R',
            'D8A', 'D8R',
            'D9A', 'D9R',
            'D10A', 'D10R',
            'D11A', 'D11R',
            'D12A', 'D12R',
            'D13A', 'D13R',
            'D14A', 'D14R',
            'D15A', 'D15R',
            'D16A', 'D16R',
            'D17A', 'D17R',
            'D18A', 'D18R',
            'D19A', 'D19R',
            'D20A', 'D20R',
            'D21A', 'D21R',
            'D22A', 'D22R',
            'D23A', 'D23R',
            'D24A', 'D24R',
            'D25A', 'D25R',
            'D26A', 'D26R',
            'D27A', 'D27R',
            'D28A', 'D28R',
            'D29A', 'D29R',
            'D30A', 'D30R',
        ];
        $j = 2;
        for ($i = 0; $i < 200; $i++) {
            if ($i > 14) {
                if ($i % 2 == 0) {
                    $row[$i] = 'D' . $j . 'A';
                } else {
                    $row[$i] = 'D' . $j . 'R';
                    $j++;
                }
            }
        }
        return $row;
    }

    public function setExcelRowTop()
    {

        $row = ['DATE', '渠道', 'DNU', 'DAU', 'DRU', 'Pageview', 'Click', 'CTR', 'Install_finish', '卸载', '今日卸载', '平均运行时长(h)',
            'D2A', 'D2R',
            'D3A', 'D3R',
            'D4A', 'D4R',
            'D5A', 'D5R',
            'D6A', 'D6R',
            'D7A', 'D7R',
            'D8A', 'D8R',
            'D9A', 'D9R',
            'D10A', 'D10R',
            'D11A', 'D11R',
            'D12A', 'D12R',
            'D13A', 'D13R',
            'D14A', 'D14R',
            'D15A', 'D15R',
            'D16A', 'D16R',
            'D17A', 'D17R',
            'D18A', 'D18R',
            'D19A', 'D19R',
            'D20A', 'D20R',
            'D21A', 'D21R',
            'D22A', 'D22R',
            'D23A', 'D23R',
            'D24A', 'D24R',
            'D25A', 'D25R',
            'D26A', 'D26R',
            'D27A', 'D27R',
            'D28A', 'D28R',
            'D29A', 'D29R',
            'D30A', 'D30R',
        ];
        $j = 2;
        for ($i = 0; $i < 200; $i++) {
            if ($i > 11) {
                if ($i % 2 == 0) {
                    $row[$i] = 'D' . $j . 'A';
                } else {
                    $row[$i] = 'D' . $j . 'R';
                    $j++;
                }
            }
        }
        return $row;
    }

    /**
     *
     * @param $day1
     * @param $day2
     * @return float
     */
    function diffBetweenTwoDays($day1, $day2)
    {
        $second1 = strtotime($day1);
        $second2 = strtotime($day2);

        if ($second1 < $second2) {
            $tmp = $second2;
            $second2 = $second1;
            $second1 = $tmp;
        }
        return ceil(($second1 - $second2) / 86400);
    }

    public function checkTable($event, $date)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE '" . $event . $date . "'")->queryAll();
        if (empty($ta)) {
            return 0;
        }
        return 1;
    }

}