<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace app\commands;

use yii\console\Controller;
use app\models\ARbase\SoftFeatures;
use app\models\ARbase\Soft;

/**
 * This command echoes the first argument that you have entered.
 *
 * This command is provided as an example for you to learn how to create console commands.
 *
 * @author Qiang Xue <qiang.xue@gmail.com>
 * @since 2.0
 */
class SoftController extends Controller
{
    /**
     * 导出1.4的特征到 特征库
     */
    public  function actionSofttofeatures(){

        SoftFeatures::deleteAll();
        $row=Soft::find()->all();

        foreach($row as $val){

            $model= new SoftFeatures();
            $model->tid=$val['id'];
            $model->feature=$val['feature'];
            $model->feature_key=$val['feature_key'];
            $model->feature_val=$val['feature_value'];
            $model->feature_file=$val['feature_val'];
            $model->time=time();
            $model->save();

        }
        echo '1';
    }
}
