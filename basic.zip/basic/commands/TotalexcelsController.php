<?php
/**
 * Created by PhpStorm.
 * User: chunyu
 * Date: 16/4/6
 * Time: 下午3:59
 */

namespace app\commands;

use Yii;
use yii\console\Controller;
use PHPExcel;
use PHPExcel_Style_NumberFormat;


class TotalexcelsController extends Controller
{
    public $channel = ['10001', '10002', '30001', '400br', '201br', '311br', 'fb1', 'Memu'];

    /**
     *
     * 生成每日上报数据
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */

    public function actionTotalExcel()
    {
//        $cache = Yii::$app->cache;
//        $cache->flush();
        error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED & ~E_WARNING);
        ini_set('memory_limit', '-1');
        set_time_limit(0);
        $begindate = '2016-06-20';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-06-20';
        $date = date("Y-m-d", strtotime("-1 days"));
//        $startdate = '2016-07-25';
//        $date = '2016-07-27';
        $day = $this->diffBetweenTwoDays($startdate, $date);
        ob_end_clean();
        ob_start();
        $row = $this->setExcelRowTop();
        $EN = 'A';
        $i = 1;
        $r = 2;
        $type = 2;
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0);
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            if ($startdate <= '2016-06-21') {
                $this->channel = ['10001', '10002', '30001'];
            }
            if ($startdate > '2016-06-21' && $startdate <= '2016-06-23') {
                $this->channel = ['10001', '10002', '30001', '400br'];
            }
            if ($startdate > '2016-06-23' && $startdate <= '2016-06-26') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br'];
            }
            if ($startdate == '2016-06-27') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br', '311br'];
            }
            if ($startdate == '2016-06-28') {
                $this->channel = ['10001', '10002', '30001', '400br', '201br', '311br', 'fb2'];
            }
            if ($startdate == '2016-06-29') {
                $this->channel = ['10001', '10002', '30001', '400br', '311br', 'fb2'];
            }
            if ($startdate > '2016-06-29' && $startdate <= '2016-07-12') {
                $this->channel = ['10001', '10002', '30001', 'fb2'];
            }
            if ($startdate > '2016-07-12' && $startdate <= '2016-07-15') {
                $this->channel = ['10001', '10002', '30001', 'fb2', 'ggs'];
            }
            if ($startdate > '2016-07-15') {
                $this->channel = ['10001', '10002', '30001', '40001', 'fb2', 'ggs'];
            }
            $num = 1;
            $objectPHPExcel = $this->handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type);
            $path = "./web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/Memu_total" . $startdate . ".xls";
            $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
            $objWriter->save($filename);
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r++;
            $num++;
        }
//        /**
//         * 设置Facebook excel
//         */
//        $this->setFbExcel($row);
//
//        $startdate = '2016-07-06';
//        $date = date("Y-m-d", strtotime("-1 days"));
//        if ($date >= $startdate) {
//            $day = $this->diffBetweenTwoDays($startdate, $date);
//            $EN = 'A';
//            $i = 1;
//            $r = 2;
//            $type = 1;
//            $this->setGgExcel($row, $EN, $i, $day, $startdate, $date, $type, $r);
//
//        }
    }


    public function setExcelRowTop()
    {
        $row = ['DATE', '渠道', 'DNU', 'DAU', 'DRU', 'Pageview', 'Click', 'CTR', 'Install_finish', '卸载', '今日卸载', 'DumpRate', 'UpSuccessRate', '平均运行时长(h)',
            'D2A', 'D2R',
            'D3A', 'D3R',
            'D4A', 'D4R',
            'D5A', 'D5R',
            'D6A', 'D6R',
            'D7A', 'D7R',
            'D8A', 'D8R',
            'D9A', 'D9R',
            'D10A', 'D10R',
            'D11A', 'D11R',
            'D12A', 'D12R',
            'D13A', 'D13R',
            'D14A', 'D14R',
            'D15A', 'D15R',
            'D16A', 'D16R',
            'D17A', 'D17R',
            'D18A', 'D18R',
            'D19A', 'D19R',
            'D20A', 'D20R',
            'D21A', 'D21R',
            'D22A', 'D22R',
            'D23A', 'D23R',
            'D24A', 'D24R',
            'D25A', 'D25R',
            'D26A', 'D26R',
            'D27A', 'D27R',
            'D28A', 'D28R',
            'D29A', 'D29R',
            'D30A', 'D30R',
        ];
        $j = 2;
        for ($i = 0; $i < 200; $i++) {
            if ($i > 14) {
                if ($i % 2 == 0) {
                    $row[$i] = 'D' . $j . 'A';
                } else {
                    $row[$i] = 'D' . $j . 'R';
                    $j++;
                }
            }
        }
        return $row;
    }


    public function handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type)
    {
        //时间 A
        $objectPHPExcel = $this->setdate($r, $objectPHPExcel, $startdate, $type);
        //获取渠道 B
        $objectPHPExcel = $this->setChannel($r, $objectPHPExcel, $type);
        //获取DNU C
        $objectPHPExcel = $this->setDNU($r, $objectPHPExcel, $startdate, $type);
        //获取DAU D
        $objectPHPExcel = $this->setDAU($r, $objectPHPExcel, $startdate, $type);
        //获取DRU E
        $objectPHPExcel = $this->setDRU($r, $objectPHPExcel, $startdate, $type);
        //pageview F
        $objectPHPExcel = $this->setPageview($r, $objectPHPExcel, $startdate, $type);
        //获取click G
        $objectPHPExcel = $this->setDlClick($r, $objectPHPExcel, $startdate, $type);
        //获取click H
        $objectPHPExcel = $this->setCTR($r, $objectPHPExcel, $startdate, $type);
        //获取install_finish I
        $objectPHPExcel = $this->setInstallFinish($r, $objectPHPExcel, $startdate, $type);
        //获取卸载 J
        $objectPHPExcel = $this->setUnInstall($r, $objectPHPExcel, $startdate, $type);
        //获取卸载率 K
        $objectPHPExcel = $this->setTodayUnInstall($r, $objectPHPExcel, $startdate, $type);
        //获取奔溃率 L
        $objectPHPExcel = $this->setDumpCountRate($r, $objectPHPExcel, $startdate, $type);
        //获取升级成功率 M
        $objectPHPExcel = $this->setUpSuccessRate($r, $objectPHPExcel, $startdate, $type);
        //获取升级成功率 N
        $objectPHPExcel = $this->setMemuRuntime($r, $objectPHPExcel, $startdate, $type);
        //以2016-06-20 开始的留存 O
        $objectPHPExcel = $this->setKeepDAU($r, $objectPHPExcel, $startdate, $date, $type);
        //以2016-06-20 开始的留存 P
        $objectPHPExcel = $this->setKeepDRU($r, $objectPHPExcel, $startdate, $date, $type);
        return $objectPHPExcel;
    }

    /**
     * 设置Facebook excel 报表
     * @param $row
     * @param $EN
     * @param $i
     * @param $day
     * @param $startdate
     * @param $date
     * @param $type
     * @param $r
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */
    public function setFbExcel($row)
    {
        $begindate = '2016-06-28';
        $startdate = date("Y-m-d", strtotime("-41 days")) >= $begindate ? date("Y-m-d", strtotime("-41 days")) : '2016-06-28';
        $date = date("Y-m-d", strtotime("-1 days"));
//        $date = '2016-06-22';
        $day = $this->diffBetweenTwoDays($startdate, $date);
        $EN = 'A';
        $i = 1;
        $r = 2;
        $type = 2;
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0);
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            $this->channel = ['fb2'];
            $num = 1;
            $objectPHPExcel = $this->handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type);
            $path = "./web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/fb_reporttotal" . $startdate . ".xls";
            $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
            $objWriter->save($filename);
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r++;
            $num++;
        }

    }

    /**
     *
     * 设置google search excel 报表
     * @param $row
     * @param $EN
     * @param $i
     * @param $day
     * @param $startdate
     * @param $date
     * @param $type
     * @param $r
     * @throws \PHPExcel_Exception
     * @throws \PHPExcel_Reader_Exception
     */
    public function setGgExcel($row, $EN, $i, $day, $startdate, $date, $type, $r)
    {
        $objectPHPExcel = new PHPExcel();
        $objectPHPExcel->setActiveSheetIndex(0);
        foreach ($row as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $EN++;
        }
        for ($j = 0; $j <= $day; $j++) {
            $this->channel = ['ggs'];
            $num = 1;
            $objectPHPExcel = $this->handleExcelRow($r, $objectPHPExcel, $startdate, $date, $type);
            $path = "./web/memu_report/" . $startdate;
            if (!file_exists($path)) {
                mkdir($path, 0777, true);
            }
            $filename = $path . "/gg_reporttotal" . $startdate . ".xls";
            $objWriter = \PHPExcel_IOFactory::createWriter($objectPHPExcel, 'Excel5');
            $objWriter->save($filename);
            $startdate = date('Y-m-d', strtotime("$startdate+1 day"));
            $r++;
            $num++;
        }

    }

    /**
     * 设置excel 日期
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setdate($r, $objectPHPExcel, $date, $type)
    {
        $channel = ['total'];
        $i = $r;
        $EN = 'A';
        foreach ($channel as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $date);
            $i++;
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 渠道
     * @param $objectPHPExcel
     * @param $type
     * @return mixed
     */
    private function setChannel($r, $objectPHPExcel, $type)
    {
        $channel = ['total'];
        $i = $r;
        $EN = 'B';
        foreach ($channel as $value) {
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $value);
            $i++;
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel DNU
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDNU($r, $objectPHPExcel, $date, $type)
    {
        $ta2 = Yii::$app->db->createCommand("SHOW TABLES LIKE 'install_finish" . $date . "'")->queryAll();
        if (!empty($ta2)) {
            $channel = ['total'];
            $cache = Yii::$app->cache;
            $i = $r;
            $EN = 'C';
            if ($date < '2016-07-01') {
                $quitesql = "select count(*) as DNU from (select * from `install_finish" . $date . "` where uuid!='' and channel in ('400br','201br','311br','fb1','Memu') and create_time like '%" . $date . "%' group by uuid) as table1";
                if ($cache->get('totaldnuQuite' . $date) !== false) {
                    $quiteDNU = $cache->get('totaldnuQuite' . $date);
                } else {
                    $quiteDNU = Yii::$app->db->createCommand($quitesql)->queryOne();
                    $cache->set('totaldnuQuite' . $date, $quiteDNU, 0);
                }
            }
            if ($date >= '2016-07-01') {
                $sql = "select count(*) as DNU from (select * from `memu_icon_visit_first" . $date . "` where uuid!='' and create_time like '%" . $date . "%' group by uuid) as table1";
            } else {
                $sql = "select count(*) as DNU from (select * from channel where status=1 and uuid!='' and create_time like '%" . $date . "%' group by uuid) as table1";
            }
            if ($cache->get('totaldnu' . $date) !== false) {
                $DNU = $cache->get('totaldnu' . $date);
            } else {
                $DNU = Yii::$app->db->createCommand($sql)->queryOne();
                $cache->set('totaldnu' . $date, $DNU, 0);
            }
            $totalDNU['DNU'] = ($quiteDNU['DNU'] + $DNU['DNU']);
            $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $totalDNU['DNU'] ? number_format($totalDNU['DNU']) : '');
            $i++;
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel DAU
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDAU($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'memu_heartbeat" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $channel = ['total'];
            $cache = Yii::$app->cache;
            $i = $r;
            $EN = 'D';
            foreach ($channel as $value) {
                $sql = "select count(*) as memu_heartbeat from (select * from `memu_heartbeat" . $date . "` where uuid!='' group by uuid) as table1";
                if ($cache->get('totalmemu_heartbeat' . $value . $date) !== false) {
                    $memu_heartbeat = $cache->get('totalmemu_heartbeat' . $value . $date);
                } else {
                    $memu_heartbeat = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totalmemu_heartbeat' . $value . $date, $memu_heartbeat, 0);
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $memu_heartbeat['memu_heartbeat'] ? number_format($memu_heartbeat['memu_heartbeat']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel DRU
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDRU($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'heartbeat" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $channel = ['total'];
            $cache = Yii::$app->cache;
            $i = $r;
            $EN = 'E';
            foreach ($channel as $value) {
                $sql = "select count(*) as `heartbeat` from (select * from `heartbeat" . $date . "`  group by uuid) as table1";
                if ($cache->get('totalheartbeat' . $value . $date) !== false) {
                    $heartbeat = $cache->get('totalheartbeat' . $value . $date);
                } else {
                    $heartbeat = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totalheartbeat' . $value . $date, $heartbeat, 0);
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $heartbeat['heartbeat'] ? number_format($heartbeat['heartbeat']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel pageview
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setPageview($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'landing_report" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $cache = Yii::$app->cache;
            $channel = ['total'];
            $i = $r;
            $EN = 'F';
            foreach ($channel as $value) {

                $sql = "select count(*) as Pageview from (select * from `landing_report" . $date . "` where name  like '%pageview%' group by uuid) as table1";

                if ($cache->get('totalpageview' . $value . $date) !== false) {
                    $Pageview = $cache->get('totalpageview' . $value . $date);
                } else {
                    $Pageview = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totalpageview' . $value . $date, $Pageview, 0);
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $Pageview['Pageview'] ? number_format($Pageview['Pageview']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 点击事件
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDlClick($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'landing_report" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $cache = Yii::$app->cache;
            $channel = ['total'];
            $i = $r;
            $EN = 'G';
            foreach ($channel as $value) {
                $sql = "select count(*) as dlclick from (select * from `landing_report" . $date . "` where name like '%dlclick%' group by uuid) as table1";

                if ($cache->get('totaldlclick' . $value . $date) !== false) {
                    $dlclick = $cache->get('totaldlclick' . $value . $date);
                } else {
                    $dlclick = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totaldlclick' . $value . $date, $dlclick, 0);
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $dlclick['dlclick'] ? number_format($dlclick['dlclick']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel CTR
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setCTR($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'landing_report" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $cache = Yii::$app->cache;
            $channel = ['total'];
            $i = $r;
            $EN = 'H';
            foreach ($channel as $value) {
                $sql = "select count(*) as dlclick from (select * from `landing_report" . $date . "` where name like '%dlclick%' group by uuid) as table1";
                if ($cache->get('totaldlclick' . $value . $date) !== false) {
                    $dlclick = $cache->get('totaldlclick' . $value . $date);
                } else {
                    $dlclick = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totaldlclick' . $value . $date, $dlclick, 0);
                }
                $sql = "select count(*) as Pageview from (select * from `landing_report" . $date . "` where name like '%pageview%' group by uuid) as table1";
                if ($cache->get('totalpageview' . $value . $date) !== false) {
                    $Pageview = $cache->get('totalpageview' . $value . $date);
                } else {
                    $Pageview = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totalpageview' . $value . $date, $Pageview, 0);
                }
                $CTR = ($dlclick['dlclick'] / $Pageview['Pageview'] * 100) ? sprintf('%.2f', round(($dlclick['dlclick'] / $Pageview['Pageview'] * 100), 2)) . '%' : 0;
                $objectPHPExcel->getActiveSheet()->getStyle("$EN$i")->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00);
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $CTR ? $CTR : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 安装完成
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setInstallFinish($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'install_finish" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $cache = Yii::$app->cache;
            $channel = ['total'];
            $i = $r;
            $EN = 'I';
            foreach ($channel as $value) {
                $sql = "select count(*) as install_finish from (select * from `install_finish" . $date . "` where uuid!='' group by uuid) as table1";
                if ($cache->get('totalinstall_finish' . $value . $date) !== false) {
                    $install_finish = $cache->get('totalinstall_finish' . $value . $date);
                } else {
                    $install_finish = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totalinstall_finish' . $value . $date, $install_finish, 0);
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $install_finish['install_finish'] ? number_format($install_finish['install_finish']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 卸载
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setUnInstall($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'uninstall" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $channel = ['total'];
            $cache = Yii::$app->cache;
            $i = $r;
            $EN = 'J';
            foreach ($channel as $value) {
                $sql = "select count(*) as uninstall from (select * from `uninstall" . $date . "` group by uuid) as table1";
                if ($cache->get('totaluninstall' . $value . $date) !== false) {
                    $uninstall = $cache->get('totaluninstall' . $value . $date);
                } else {
                    $uninstall = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totaluninstall' . $value . $date, $uninstall, 0);
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $uninstall['uninstall'] ? number_format($uninstall['uninstall']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 卸载率
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setTodayUnInstall($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'uninstall" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $channel = ['total'];
            $cache = Yii::$app->cache;
            $i = $r;
            $EN = 'K';
            foreach ($channel as $value) {
                $cache->set('totaluninstallList' . $value . $date, false, -1);
                $cache->set('totaldnulist' . $date, false, -1);
                $cache->set('totaldnuQuiteList' . $date, false, -1);
                $sql = "select uuid from (select uuid from `uninstall" . $date . "` where uuid!='' group by uuid) as table1";
                if ($cache->get('totaluninstallList' . $value . $date) !== false) {
                    $uninstallList = $cache->get('totaluninstallList' . $value . $date);
                } else {
                    $uninstallList = Yii::$app->db->createCommand($sql)->queryColumn();
                    $cache->set('totaluninstallList' . $value . $date, $uninstallList, 0);
                }
                $quiteDNU = [];
                if ($date < '2016-07-01') {
                    $quitesql = "select uuid from (select uuid from `install_finish" . $date . "` where uuid!='' and channel in ('400br','201br','311br','fb1','Memu') and create_time like '%" . $date . "%' group by uuid) as table1";
                    if ($cache->get('totaldnuQuiteList' . $date) !== false) {
                        $quiteDNU = $cache->get('totaldnuQuiteList' . $date);
                    } else {
                        $quiteDNU = Yii::$app->db->createCommand($quitesql)->queryColumn();
                        $cache->set('totaldnuQuiteList' . $date, $quiteDNU, 0);
                    }
                }
                if ($date >= '2016-07-01') {
                    $sql = "select uuid from (select uuid from `memu_icon_visit_first" . $date . "` where uuid!='' group by uuid) as table1";
                } else {
                    $sql = "select uuid from (select uuid from channel where status=1 and uuid!='' group by uuid) as table1";
                }
                $DNU = [];
                if ($cache->get('totaldnulist' . $date) !== false) {
                    $DNU = $cache->get('totaldnulist' . $date);
                } else {
                    $DNU = Yii::$app->db->createCommand($sql)->queryColumn();
                    $cache->set('totaldnulist' . $date, $DNU, 0);
                }
                $totalDNU = array_merge($DNU, $quiteDNU);
                $todayUserList = array_intersect($totalDNU, $uninstallList);
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", count($todayUserList) ? number_format(count($todayUserList)) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel dumpcount
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDumpCount($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'dumpcount" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $cache = Yii::$app->cache;
            $channel = ['total'];
            $i = $r;
            $EN = 'L';
            foreach ($channel as $value) {

                $sql = "select count(*) as dumpcount from `dumpcount" . $date . "` where uuid!=''";
                if ($cache->get('totaldumpcount' . $value . $date) !== false) {
                    $dumpcount = $cache->get('totaldumpcount' . $value . $date);
                } else {
                    $dumpcount = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totaldumpcount' . $value . $date, $dumpcount, 0);
                }
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $dumpcount['dumpcount'] ? number_format($dumpcount['dumpcount']) : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel dumpcount
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setDumpCountRate($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'dumpcount" . $date . "'")->queryAll();
        $ta2 = Yii::$app->db->createCommand("SHOW TABLES LIKE 'memu_heartbeat" . $date . "'")->queryAll();
        if (!empty($ta) && !empty($ta2)) {
            $cache = Yii::$app->cache;
            $channel = ['total'];
            $i = $r;
            $EN = 'L';
            foreach ($channel as $value) {

                $sql = "select count(*) as dumpcount from `dumpcount" . $date . "` where uuid!=''";
                if ($cache->get('totaldumpcount' . $value . $date) !== false) {
                    $dumpcount = $cache->get('totaldumpcount' . $value . $date);
                } else {
                    $dumpcount = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totaldumpcount' . $value . $date, $dumpcount, 0);
                }
                $sql = "select count(*) as memu_heartbeat from `memu_heartbeat" . $date . "` where uuid!=''";
                if ($cache->get('totalmemu_heartbeat' . $value . $date) !== false) {
                    $memu_heartbeat = $cache->get('totalmemu_heartbeat' . $value . $date);
                } else {
                    $memu_heartbeat = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totalmemu_heartbeat' . $value . $date, $memu_heartbeat, 0);
                }

                $dumpcountRate = ($dumpcount['dumpcount'] / $memu_heartbeat['memu_heartbeat'] * 100) ? sprintf('%.2f', round(($dumpcount['dumpcount'] / $memu_heartbeat['memu_heartbeat'] * 100), 2)) . '%' : 0;

                $objectPHPExcel->getActiveSheet()->getStyle("$EN$i")->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00);
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $dumpcountRate ? $dumpcountRate : 0);
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel dumpcount
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setUpSuccessRate($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'up_start" . $date . "'")->queryAll();
        $ta2 = Yii::$app->db->createCommand("SHOW TABLES LIKE 'up_finish" . $date . "'")->queryAll();
        if (!empty($ta) && !empty($ta2)) {
            $cache = Yii::$app->cache;
            $channel = ['total'];
            $i = $r;
            $EN = 'M';
            foreach ($channel as $value) {

                $sql = "select count(*) as up_start from `up_start" . $date . "` where uuid!=''";
                if ($cache->get('totalupstart' . $value . $date) !== false) {
                    $upstart = $cache->get('totalupstart' . $value . $date);
                } else {
                    $upstart = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totalupstart' . $value . $date, $upstart, 0);
                }
                $sql = "select count(*) as up_finish from `up_finish" . $date . "` where uuid!=''";
                if ($cache->get('totalupfinish' . $value . $date) !== false) {
                    $upfinish = $cache->get('totalupfinish' . $value . $date);
                } else {
                    $upfinish = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totalupfinish' . $value . $date, $upfinish, 0);
                }

                $upSuccessRate = ($upfinish['up_finish'] / $upstart['up_start'] * 100) ? sprintf('%.2f', round(($upfinish['up_finish'] / $upstart['up_start'] * 100), 2)) . '%' : 0;

                $objectPHPExcel->getActiveSheet()->getStyle("$EN$i")->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_PERCENTAGE_00);
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $upSuccessRate ? $upSuccessRate : 0);
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 平均运行时长
     * @param $objectPHPExcel
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setMemuRuntime($r, $objectPHPExcel, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'uninstall" . $date . "'")->queryAll();
        if (!empty($ta)) {
            $channel = ['total'];
            $cache = Yii::$app->cache;
            $i = $r;
            $EN = 'N';
            foreach ($channel as $value) {
                $data = file_get_contents('http://api.simcake.com/report/memu_run_time/' . $date . '/memu_run_time1.txt');
                $array = [];
                $dataArr = explode("\n", $data);
                foreach ($dataArr as $key => $val) {
                    $dArr = json_decode($val, true);
                    if($dArr['params']['runtime']<86400){
                        $array[$value][$dArr['uuid']] = $array[$value][$dArr['uuid']] + $dArr['params']['runtime'];
                    }
                }
                $sql = "select count(*) as memu_heartbeat from (select * from `memu_heartbeat" . $date . "` where uuid!='' group by uuid) as table1";
                if ($cache->get('totalmemu_heartbeat' . $value . $date) !== false) {
                    $memu_heartbeat = $cache->get('totalmemu_heartbeat' . $value . $date);
                } else {
                    $memu_heartbeat = Yii::$app->db->createCommand($sql)->queryOne();
                    $cache->set('totalmemu_heartbeat' . $value . $date, $memu_heartbeat, 0);
                }
                $runtimes = (array_sum($array[$value]) / 3600) / $memu_heartbeat['memu_heartbeat'];
                $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $runtimes ? $runtimes : '');
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 留存
     * @param $objectPHPExcel
     * @param $startdate
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setKeepDAU($r, $objectPHPExcel, $startdate, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'install_finish" . $startdate . "'")->queryAll();
        if (!empty($ta)) {
            $channel = ['total'];
            $cache = Yii::$app->cache;
            $i = $r;
            $d = 0;
            foreach ($channel as $value) {
                $EN = 'O';
                $day = $this->diffBetweenTwoDays($startdate, $date);
                for ($j = 1; $j <= $day + 1; $j++) {
                    if ($startdate < '2016-07-01') {
                        $quitesql = "select uuid as DNU from (select * from `install_finish" . $startdate . "` where uuid!='' and channel in ('400br','201br','311br','fb1','Memu') and create_time like '%" . $startdate . "%' group by uuid) as table1";
                        if ($cache->get('totalDAU' . $value . $startdate) !== false) {
                            $totalStartquiteDNU = $cache->get('totalDAU' . $value . $startdate);
                        } else {
                            $totalStartquiteDNU = Yii::$app->db->createCommand($quitesql)->queryColumn();
                            $cache->set('totalDAU' . $value . $startdate, $totalStartquiteDNU, 0);
                        }
                    }
                    if ($startdate >= '2016-07-01') {
                        $sql = "select uuid as DNU from (select * from `memu_icon_visit_first" . $startdate . "` where uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
                    } else {
                        $sql = "select uuid as DNU from (select * from channel where status=1 and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
                    }
                    if ($cache->get('totalstartDNU' . $value . $startdate) !== false) {
                        $totalstartDNU = $cache->get('totalstartDNU' . $value . $startdate);
                    } else {
                        $totalstartDNU = Yii::$app->db->createCommand($sql)->queryColumn();
                        $cache->set('totalstartDNU' . $value . $startdate, $totalstartDNU, 0);
                    }
                    if ($startdate < '2016-07-01') {
                        $StartDNU = array_unique(array_merge($totalStartquiteDNU, $totalstartDNU));
                    } else {
                        $StartDNU = $totalstartDNU;
                    }
                    //获取2016-06-20的新增用户
                    $secendday = date('Y-m-d', strtotime("$startdate   +" . $j . "   day"));
                    if ($secendday <= $date) {
                        //获取heartbeat 所有用户
                        $secendsSql = "select uuid from `memu_heartbeat" . $secendday . "` group by uuid";
                        if ($cache->get('totalmemu_heartbeatsecendsUser' . $secendday) !== false) {
                            $secendsUser = $cache->get('totalmemu_heartbeatsecendsUser' . $secendday);
                        } else {
                            $secendsUser = Yii::$app->db->createCommand($secendsSql)->queryColumn();
                            $cache->set('totalmemu_heartbeatsecendsUser' . $secendday, $secendsUser, 0);
                        }
                        $d = count(array_intersect($StartDNU, $secendsUser));
                        $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $d ? number_format($d) : 0);
                    }
                    $EN++;
                    $EN++;
                }
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    /**
     * 设置excel 留存
     * @param $objectPHPExcel
     * @param $startdate
     * @param $date
     * @param $type
     * @return mixed
     */
    private function setKeepDRU($r, $objectPHPExcel, $startdate, $date, $type)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE 'install_finish" . $startdate . "'")->queryAll();
        if (!empty($ta)) {
            $channel = ['total'];
            $cache = Yii::$app->cache;
            $i = $r;
            $d = 0;
            foreach ($channel as $value) {
                $EN = 'P';
                $day = $this->diffBetweenTwoDays($startdate, $date);
                for ($j = 1; $j <= $day + 1; $j++) {
                    if ($startdate < '2016-07-01') {
                        $quitesql = "select uuid as DNU from (select * from `install_finish" . $startdate . "` where uuid!='' and channel in ('400br','201br','311br','fb1','Memu') and create_time like '%" . $startdate . "%' group by uuid) as table1";
                        if ($cache->get('totalDAU' . $value . $startdate) !== false) {
                            $totalStartquiteDNU = $cache->get('totalDAU' . $value . $startdate);
                        } else {
                            $totalStartquiteDNU = Yii::$app->db->createCommand($quitesql)->queryColumn();
                            $cache->set('totalDAU' . $value . $startdate, $totalStartquiteDNU, 0);
                        }
                    }
                    if ($startdate >= '2016-07-01') {
                        $sql = "select uuid as DNU from (select * from `memu_icon_visit_first" . $startdate . "` where uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
                    } else {
                        $sql = "select uuid as DNU from (select * from channel where status=1 and uuid!='' and create_time like '%" . $startdate . "%' group by uuid) as table1";
                    }
                    if ($cache->get('totalstartDNU' . $value . $startdate) !== false) {
                        $totalstartDNU = $cache->get('totalstartDNU' . $value . $startdate);
                    } else {
                        $totalstartDNU = Yii::$app->db->createCommand($sql)->queryColumn();
                        $cache->set('totalstartDNU' . $value . $startdate, $totalstartDNU, 0);
                    }
                    if ($startdate < '2016-07-01') {
                        $StartDNU = array_unique(array_merge($totalStartquiteDNU, $totalstartDNU));
                    } else {
                        $StartDNU = $totalstartDNU;
                    }

                    //获取2016-06-20的新增用户
                    $secendday = date('Y-m-d', strtotime("$startdate   +" . $j . "   day"));
                    if ($secendday <= $date) {
                        //获取heartbeat 所有用户
                        $secendsSql = "select uuid from `heartbeat" . $secendday . "` group by uuid";
                        if ($cache->get('totalheartbeatsecendsUser' . $secendday) !== false) {
                            $secendsUser = $cache->get('totalheartbeatsecendsUser' . $secendday);
                        } else {
                            $secendsUser = Yii::$app->db->createCommand($secendsSql)->queryColumn();
                            $cache->set('totalheartbeatsecendsUser' . $secendday, $secendsUser, 0);
                        }
                        $d = count(array_intersect($StartDNU, $secendsUser));
                        $objectPHPExcel->setActiveSheetIndex(0)->setCellValue("$EN$i", $d ? number_format($d) : 0);
                    }
                    $EN++;
                    $EN++;
                }
                $i++;
            }
        }
        return $objectPHPExcel;
    }

    public function checkTable($event, $date)
    {
        $ta = Yii::$app->db->createCommand("SHOW TABLES LIKE '" . $event . $date . "'")->queryAll();
        if (empty($ta)) {
            return 0;
        }
        return 1;
    }

    /**
     *
     * @param $day1
     * @param $day2
     * @return float
     */
    function diffBetweenTwoDays($day1, $day2)
    {
        $second1 = strtotime($day1);
        $second2 = strtotime($day2);

        if ($second1 < $second2) {
            $tmp = $second2;
            $second2 = $second1;
            $second1 = $tmp;
        }
        return ceil(($second1 - $second2) / 86400);
    }


}