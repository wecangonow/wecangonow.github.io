Here are some quick links that will help you:

1. Theme documentation is available at http://magazine3.com/help/gamingzone/

2. To contact customer support team, please go to http://magazine3.com/helpdesk/ and create a new ticket.

3. To get a license key for the theme, go to http://magazine3.com/license-key/


For other queries, please go to http://magazine3.com/contact/